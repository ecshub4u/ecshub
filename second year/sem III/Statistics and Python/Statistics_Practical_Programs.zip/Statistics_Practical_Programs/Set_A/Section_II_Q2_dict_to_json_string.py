# Program Name: To convert dict to a JSON string

# Set A Section-II Q2) Write a program to convert dict to a JSON string.

import json

student = {
    "name": "Rohu",
    "age": 19,
    "course": "B.Sc. ECS",
    "marks": [78, 85, 90],
    "passed": True,
    "address": None
}

json_string = json.dumps(student)
print("JSON string :", json_string)
print("Type :", type(json_string))

# Formatted JSON string
print(json.dumps(student, indent=4, sort_keys=True))


# ---------------- Concept ----------------
# json.dumps() converts a Python dictionary into a JSON formatted string
# Python -> JSON : dict -> object , list -> array , str -> string , True -> true , None -> null
