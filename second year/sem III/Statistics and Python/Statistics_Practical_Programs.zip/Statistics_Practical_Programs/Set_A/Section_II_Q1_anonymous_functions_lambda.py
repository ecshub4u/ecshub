# Program Name: To demonstrate anonymous functions (lambda)

# Set A Section-II Q1) Write a program to demonstrate anonymous functions.

# A lambda function is a function without a name
square = lambda x: x ** 2
add = lambda a, b: a + b
is_even = lambda n: n % 2 == 0

print("Square of 5 =", square(5))
print("Sum of 10 and 20 =", add(10, 20))
print("Is 8 even? ", is_even(8))

# lambda with map(), filter() and sorted()
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print("Squares :", list(map(lambda x: x ** 2, numbers)))
print("Even numbers :", list(filter(lambda x: x % 2 == 0, numbers)))

students = [("Amit", 72), ("Sneha", 88), ("Rohit", 65)]
print("Sorted by marks :", sorted(students, key=lambda s: s[1]))


# ---------------- Concept ----------------
# Syntax : lambda arguments : expression
# Lambda can have any number of arguments but only one expression
# It is used where a small function is required for a short time (with map, filter, sorted)
