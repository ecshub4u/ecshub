# Program Name: SRSWOR sample of size 40 from a normal population (N = 400, mean = 30, sd = 6)
# (as per Assignment_01 : to draw SRSWOR)

# Set A Q1) Select a random sample of size 40 from a normal population of size 400 with mean 30
# and standard deviation 6 by using SRSWOR. Calculate the sample mean and standard deviation
# and compare them with the theoretical values.

import numpy as np
#define population
p1=np.random.normal(30,6,size=400) #population from N(30,6)

#to draw sample
s1=np.random.choice(p1,size=40,replace=False)

#display result
print("population :\n",p1)
print("SRSWOR :\n",s1)
print("population A.m=",np.mean(p1))
print("sample A.m=",np.mean(s1))
print("population S.D.=",np.std(p1))
print("sample S.D.=",np.std(s1))
print("Theoretical mean = 30 , Theoretical S.D. = 6")
print("Sample mean and S.D. are close to the theoretical values")


# ---------------- Formula used ----------------
# Population mean   : mu = (sum of X) / N
# Sample mean       : x_bar = (sum of x) / n
# SRSWOR : total possible samples = NCn = N! / (n! (N - n)!) , probability of selecting a unit = n/N
# Sample mean is an unbiased estimate of the population mean : E(x_bar) = mu
