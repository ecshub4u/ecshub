# Program Name: To form discrete frequency distribution and find A.M.
# (as per Assignment_02 : form discrete frequency distribution and Assignment_04 : np.repeat)

# Set A Q2) Form a discrete frequency distribution for the following data. Find A.M.
# 5, 6, 6, 6, 7, 7, 7, 8, 8, 9, 8, 8, 7, 7, 7, 6, 6, 5, 5, 9

import numpy as np
from collections import Counter
data = [5, 6, 6, 6, 7, 7, 7, 8, 8, 9, 8, 8, 7, 7, 7, 6, 6, 5, 5, 9]
N = len(data) # Total no of observation

# formation of distribution
dist = Counter(data)
dist_sort = dict(sorted(dist.items()))
f = list(dist_sort.values()) #list of frequencies
x = list(dist_sort.keys()) #list of unique elements

# Display result
print("x \t f")
for i in range(len(x)):
    print(x[i], "\t", f[i])

# A.M.
data1 = np.repeat(x, f)
am = np.mean(data1)
print("Arithmetic mean =", am)


# ---------------- Formula used ----------------
# Total frequency : N = sum of f
# Arithmetic mean : x_bar = (sum of f*x) / N
