# Program Name: Find ceiling values using np.ceil()

import numpy as np
x=7.23
print(np.ceil(x))

x1=8
print(np.ceil(x1))


x2=-7.23
print(np.ceil(x2))


arr=np.array([2.3,4.8,7.1,9.9])
print(np.ceil(arr))


# ---------------- Formula used ----------------
# Ceiling of x = smallest integer greater than or equal to x
# ceil(7.23) = 8 , ceil(8) = 8 , ceil(-7.23) = -7
