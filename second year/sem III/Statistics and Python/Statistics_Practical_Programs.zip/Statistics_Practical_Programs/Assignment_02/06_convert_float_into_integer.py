# Program Name: Convert a float into an integer using int()

x=12.85
print(int(x))


# ---------------- Formula used ----------------
# int(x) removes the decimal part (truncation towards zero) : int(12.85) = 12
