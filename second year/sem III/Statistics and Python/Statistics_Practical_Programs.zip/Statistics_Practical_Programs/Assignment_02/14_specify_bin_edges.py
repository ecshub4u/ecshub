# Program Name: Histogram with specified bin edges

import numpy as np
data=[5,8,12,14,16,18,20,25,27,30]
hist,bins=np.histogram(data,bins=[0,10,20,30])
print("frequency=",hist)
print("bin_edges=",bins)


# ---------------- Formula used ----------------
# Class width h = upper limit - lower limit
# Every class includes its lower limit and excludes its upper limit, except the last class which includes both
