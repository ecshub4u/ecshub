# Program Name: Cumulative sum of a list using np.cumsum()

import numpy as np
a = [ 1, 2 , 3 , 4 , 5 ] # list
result = np.cumsum(a)
print(result)


# ---------------- Formula used ----------------
# Cumulative sum : S_i = a_1 + a_2 + ... + a_i
# Less than cumulative frequency : LCF_i = f_1 + f_2 + ... + f_i
