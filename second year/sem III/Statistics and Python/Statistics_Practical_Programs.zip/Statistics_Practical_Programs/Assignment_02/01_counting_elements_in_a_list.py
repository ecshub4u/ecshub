# Program Name: Counting elements in a list using Counter()

from collections import Counter
data = [2,3,2,4,3,2,5]
count = Counter(data)
print(count)


# ---------------- Formula used ----------------
# Frequency (f) of a value = number of times the value is repeated in the data
# Total frequency N = sum of f
