# Program Name: To form continuous frequency distribution (with lcf, gcf and relative frequency)

import numpy as np

# Data definition
data = [49.2 , 48.1 , 10.2 , 32.3 ,38.7 , 45.2 , 43.3 , 13.6 , 17.8 , 32.1 , 36.5 , 19.2 , 43.8 , 47.5 ,
      28.9 , 33.6 , 34.7 , 27.4 , 29.1, 42.3 , 43.6 , 46.1 , 50.1 , 51.6 , 59.2 , 68.9 , 67.4 , 62.1 ,
      21.2 , 22.3 , 39.2 , 37.7 , 41.1 , 24.4 , 25.6 , 45.7 , 46.2 , 52.4 ,58.6 , 54.8 , 30.1 , 31.3 ,
      48.9 , 34.2 , 38.9 , 52.9 , 60.0 , 61.1 , 67.9 , 40.1 , 42.4 , 54.7 , 56.8 , 58.3 , 44.5 , 48.3 ,
      64.7 , 65.8 , 70.0 , 75.1 , 78.9]
# OR (random data from U(10, 100) with 2 decimal points)
# data = np.round(np.random.uniform(10, 100, size=150), 2)

N = len(data)  # size of data

# To find number of classes by Sturges' Rule
k = round(1 + 3.322 * np.log10(N))  # No. of classes

# Formation of class intervals
minima = int(min(data))
maxima = int(max(data))

range_value = maxima - minima
class_width = int(np.ceil(range_value / k))
bins = list(range(minima, maxima + class_width, class_width))

# Formation of distribution using np.histogram
freq, edges = np.histogram(data, bins=bins)

# To compute lcf (Less than Cumulative Frequency)
lcf = list(np.cumsum(freq))

# To compute gcf (Greater than Cumulative Frequency)
rev_freq = list(reversed(freq))          # list of frequency is reversed
lcf_rev_freq = list(np.cumsum(rev_freq))
gcf = list(reversed(lcf_rev_freq))

# To compute relative frequency
relative_freq = list(np.round(freq / N, 2))

# Display result
print("class \t\t freq \t lcf \t gcf \t relative_freq")
for i in range(len(freq)):
    print(f"{edges[i]} - {edges[i+1]} \t {freq[i]} \t {lcf[i]} \t {gcf[i]} \t {relative_freq[i]}")


# ---------------- Formula used ----------------
# Number of classes by Sturges' rule : k = 1 + 3.322 * log10(N)     (N = total number of observations)
# Range : R = maximum value - minimum value
# Class width : h = R / k   (rounded up to next integer using ceil)
# Less than cumulative frequency (l.c.f)    : LCF_i = f_1 + f_2 + ... + f_i
# Greater than cumulative frequency (g.c.f) : GCF_i = f_i + f_(i+1) + ... + f_k
# Relative frequency : r.f_i = f_i / N
