# Program Name: Useful Counter methods

from collections import Counter
data = [1,2,2,3,3,3,4]
count = Counter(data)
print(count)

#To_access_frequency_of_a_perticular_element
print(count[3])

#list of unique element
print(list(count.keys()))

#list of frequencies
print(list(count.values()))

# sum of frequencies
print(sum(count.values()))

# convert counter to dictionary
d=dict(count)
print(d)

# convert counter to list of tuple (element,freq)
print(list(count.items()))


# ---------------- Formula used ----------------
# Total frequency N = sum of f
# (N = number of observations in the data)
