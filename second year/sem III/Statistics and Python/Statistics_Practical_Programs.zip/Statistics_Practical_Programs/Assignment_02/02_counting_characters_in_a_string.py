# Program Name: Counting characters in a string using Counter()

from collections import Counter
text = "statistics"
count = Counter(text)
print(count)


# ---------------- Formula used ----------------
# Frequency (f) of a character = number of times the character occurs in the string
# Total frequency N = sum of f = number of characters in the string
