# Program Name: To form discrete frequency distribution and find g.c.f, l.c.f and relative frequency

import numpy as np
from collections import Counter
data = [14, 11, 13, 12, 11, 10, 13, 11, 10, 8, 12, 11, 9, 12, 10, 12, 11, 10, 12, 11, 9, 12, 10,
10, 11, 9, 13, 8, 11, 13, 9, 11, 10, 11, 12, 13, 12, 10, 11, 13, 10, 12, 12, 11, 8, 11,
9, 10, 11, 12, 10, 12, 10, 12, 10, 11, 12, 9, 14, 13, 11, 14, 12, 9, 12, 11, 13, 14, 11,
12, 11, 11, 15, 12, 11, 13, 14, 15, 12, 13 ]

# OR data = np.random.randint(10, 20, size=150)
N = len(data) # Total no of observation

# formation of distribution
dist = Counter(data)
dist_sort = dict(sorted(dist.items()))
f = list(dist_sort.values()) #list of frequencies
x = list(dist_sort.keys()) #list of unique elements

# To compute lcf
lcf = list(np.cumsum(f))

# To compute gcf
rev_f = list(reversed(f))
lcf_rev = list(np.cumsum(rev_f))
gcf = list(reversed(lcf_rev))

# To obtain relative frequency
f1 = np.array(f) # list is converted into numpy array because arithmetic operator does not work on list
relative_f = list(f1 / N)

# Display result
print("x \t f \t lcf \t gcf \t relative_freq")
for i in range(len(x)):
    print(x[i], "\t", f[i], "\t", lcf[i], "\t", gcf[i], "\t", relative_f[i])


# ---------------- Formula used ----------------
# Total frequency : N = sum of f
# Less than cumulative frequency (l.c.f)    : LCF_i = f_1 + f_2 + ... + f_i
# Greater than cumulative frequency (g.c.f) : GCF_i = f_i + f_(i+1) + ... + f_k
# Relative frequency : r.f_i = f_i / N
# Sum of relative frequencies = 1
