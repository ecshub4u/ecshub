# Program Name: Round a number using round()

x=25.67
print(round(x))


# ---------------- Formula used ----------------
# Rounding rule : decimal part >= 0.5 -> go to next integer, decimal part < 0.5 -> stay at same integer
# Python uses banker's rounding for exactly .5 : round(4.5) = 4 , round(5.5) = 6
