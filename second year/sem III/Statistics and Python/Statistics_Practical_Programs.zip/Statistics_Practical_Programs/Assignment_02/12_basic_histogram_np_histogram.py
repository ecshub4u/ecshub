# Program Name: Basic histogram using np.histogram()

import numpy as np
data=[10,12,15,18,20,22,25,28,30,35]
hist,bins=np.histogram(data)
print("frequency=",hist)
print("bin_edges=",bins)


# ---------------- Formula used ----------------
# Default number of bins = 10
# Class width h = (maximum - minimum) / number of bins
