# Program Name: Histogram with specified number of bins

import numpy as np
data=[12,15,18,20,22,25,28,30,35,40]
hist,bins=np.histogram(data,bins=5)
print("frequency=",hist)
print("bin_edges=",bins)


# ---------------- Formula used ----------------
# Class width h = (maximum - minimum) / number of bins
