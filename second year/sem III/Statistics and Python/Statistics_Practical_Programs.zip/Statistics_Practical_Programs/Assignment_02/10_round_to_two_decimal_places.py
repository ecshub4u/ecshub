# Program Name: Round a number to 2 decimal places

x=15.67718217
print(round(x,2))


# note:
#      python usages bankers rule rounding i.e
#      print(round(4.5))
#      output:4
#      print(round(5.5))
#      output:6


# ---------------- Formula used ----------------
# round(x, n) keeps n digits after the decimal point : round(15.67718217, 2) = 15.68
