# Program Name: Convert a negative float into an integer using int()

x=-7.95
print(int(x))


# ---------------- Formula used ----------------
# int(x) removes the decimal part (truncation towards zero) : int(-7.95) = -7
