# Program Name: Convert a numeric string into an integer using int()

x="125"

print(int(x))


# ---------------- Formula used ----------------
# No calculation formula is used in this program.
