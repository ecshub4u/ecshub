# Program Name: To parse a JSON string into a dictionary

# Set D Section-II Q1) Write a program to parse a JSON string into a dictionary.

import json

json_string = '{"name": "Rohu", "age": 19, "course": "B.Sc. ECS", "marks": [78, 85, 90], "passed": true, "address": null}'

data = json.loads(json_string)
print("Dictionary :", data)
print("Type :", type(data))
print("Name =", data["name"])
print("Marks =", data["marks"])
print("Passed =", data["passed"], "(true -> True)")
print("Address =", data["address"], "(null -> None)")


# ---------------- Concept ----------------
# json.loads() converts a JSON formatted string into a Python dictionary
# JSON -> Python : object -> dict , array -> list , string -> str , true -> True , null -> None
