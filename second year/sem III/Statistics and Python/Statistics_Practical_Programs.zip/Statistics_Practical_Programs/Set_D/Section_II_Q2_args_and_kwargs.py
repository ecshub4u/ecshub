# Program Name: To demonstrate the use of *args and **kwargs

# Set D Section-II Q2) Write a program to demonstrate the use of *args and **kwargs arguments.

# *args : any number of positional arguments (stored in a tuple)
def add_numbers(*args):
    print("args =", args)
    total = 0
    for n in args:
        total = total + n
    return total

print("Sum =", add_numbers(10, 20, 30))
print("Sum =", add_numbers(1, 2, 3, 4, 5))

# **kwargs : any number of keyword arguments (stored in a dictionary)
def student_info(**kwargs):
    print("kwargs =", kwargs)
    for key, value in kwargs.items():
        print(key, ":", value)

student_info(name="Rohu", age=19, course="B.Sc. ECS")

# using both together
def show(a, *args, **kwargs):
    print("a =", a, " args =", args, " kwargs =", kwargs)

show(1, 2, 3, x=10, y=20)


# ---------------- Concept ----------------
# *args   -> collects extra positional arguments into a tuple
# **kwargs -> collects extra keyword arguments into a dictionary
# Order of parameters : normal arguments, *args, **kwargs
