# Program Name: To find mean and median for discrete frequency distribution
# (as per Assignment_04 : measures of central tendency for discrete frequency distribution)

# Set D Q1) Find mean and median for the following data.
# x : 13  14  16  17  19
# f :  4   7   9   6   3

import numpy as np

x = np.array([13, 14, 16, 17, 19])
f = np.array([4, 7, 9, 6, 3])

data = np.repeat(x, f)
print("Data:", data)

am=np.mean(data)
print(" Arithmetic mean =",am)
Me=np.median(data)
print("Median =",Me)


# ---------------- Formula used ----------------
# Total frequency : N = sum of f
# Arithmetic mean : x_bar = (sum of f*x) / N
# Median          : value of the (N/2)th observation in the ordered data (cumulative frequency >= N/2)
