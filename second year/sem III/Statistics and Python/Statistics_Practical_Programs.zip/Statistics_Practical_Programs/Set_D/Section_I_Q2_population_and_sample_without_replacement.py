# Program Name: To draw SRSWOR from a normal population and compute population and sample mean
# (as per Assignment_01 : to draw SRSWOR)

# Set D Q2) Generate a population of size 150 from a normal distribution with parameters (10, 12)
# and draw a sample of size 15 without replacement. Compute the population and sample mean.

import numpy as np
#define population
p1=np.random.normal(10,12,size=150) #population from N(10,12)

#to draw sample
s1=np.random.choice(p1,size=15,replace=False)

#display result
print("population :\n",p1)
print("SRSWOR :\n",s1)
print("population A.m=",np.mean(p1))
print("sample A.m=",np.mean(s1))


# ---------------- Formula used ----------------
# Population mean   : mu = (sum of X) / N
# Sample mean       : x_bar = (sum of x) / n
# SRSWOR : total possible samples = NCn = N! / (n! (N - n)!) , probability of selecting a unit = n/N
