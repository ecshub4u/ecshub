# Program Name: To demonstrate higher-order functions

# Set E Section-II Q1) Write a program to demonstrate higher-order functions.

from functools import reduce

# A higher-order function takes a function as argument or returns a function

# 1) function taking another function as argument
def apply(func, value):
    return func(value)

def square(x):
    return x * x

print("apply(square, 6) =", apply(square, 6))

# 2) function returning another function
def multiplier(n):
    def multiply(x):
        return x * n
    return multiply

double = multiplier(2)
triple = multiplier(3)
print("double(7) =", double(7), " triple(7) =", triple(7))

# 3) built-in higher-order functions
numbers = [1, 2, 3, 4, 5, 6]
print("map    :", list(map(square, numbers)))
print("filter :", list(filter(lambda x: x % 2 == 0, numbers)))
print("reduce :", reduce(lambda a, b: a + b, numbers))
print("sorted :", sorted(["pear", "fig", "banana"], key=len))


# ---------------- Concept ----------------
# Higher-order function : a function that accepts a function as an argument and/or returns a function
# map(func, iterable) , filter(func, iterable) , reduce(func, iterable) , sorted(iterable, key=func)
