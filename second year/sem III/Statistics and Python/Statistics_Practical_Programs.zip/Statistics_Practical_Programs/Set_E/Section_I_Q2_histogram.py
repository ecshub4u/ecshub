# Program Name: To draw histogram for equal class width

# Set E Q2) Draw a histogram to represent the following data.
# Class   5-10  10-15  15-20  20-25  25-30  30-35
# Freq.    10     14     17     15     11      7

import matplotlib.pyplot as plt
limits = [5, 10, 15, 20, 25, 30, 35]   # class-limit
f = [10, 14, 17, 15, 11, 7]            # frequency
w = limits[1] - limits[0]              # class_width
print("Class width =", w)
plt.bar(limits[:-1], f, width=w, align='edge', color='red', edgecolor='black')
plt.title("histogram for equal class_width")
plt.xlabel("class_limit")
plt.ylabel("frequency")
plt.show()


# ---------------- Formula used ----------------
# Class width : w = upper limit - lower limit   (here 10 - 5 = 5)
# For equal class width, height of each bar = frequency (f)
# Area of each rectangle is proportional to the frequency
