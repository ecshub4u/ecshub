# Program Name: To draw Systematic Sample from a normal population
# (as per Assignment_01 : to draw systematic sample)

# Set E Q1) Draw a random sample of size 30 from a normal population of size 600 with mean 25
# and standard deviation 4 by using the systematic random sampling method.
# Calculate the sample mean and standard deviation.

import numpy as np
p = np.random.normal(25, 4, size=600)
print("Population:\n", p)
N = len(p)
print("Population size =", N)
n = 30 # sample size is given in the question  (n = int(input("Enter the sample size: ")))
K = N // n #No of item in each sequential group
print("No. of items in each sequential group =", K)
s1 = np.random.randint(0, K) # Selection of first item in first sequential group
systematic = p[s1::K] # slicing
print("Systematic sample:\n", systematic)
print("Population A.M. =", np.mean(p))
print("Systematic Sample A.M. =", np.mean(systematic))
print("Systematic Sample S.D. =", np.std(systematic))


# ---------------- Formula used ----------------
# Sampling interval : K = N / n    (N = population size, n = sample size)
# Random start      : r = a random number between 1 and K (here 0 to K-1 because index starts from 0)
# Selected units    : r, r + K, r + 2K, r + 3K, ...
# Sample mean       : x_bar = (sum of x) / n
# Sample S.D.       : s = sqrt( (sum of (x - x_bar)^2) / n )
