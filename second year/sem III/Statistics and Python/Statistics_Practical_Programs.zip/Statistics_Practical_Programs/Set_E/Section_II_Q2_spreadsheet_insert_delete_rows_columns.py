# Program Name: To create a simple spreadsheet and insert / delete rows and columns

# Set E Section-II Q2) Write a program to create a simple spreadsheet and do the following operations:
# a) Insert row  b) Delete row  c) Insert column  d) Delete column

from openpyxl import Workbook

def show(ws, message):
    print(message)
    for row in ws.iter_rows(values_only=True):
        print(row)
    print()

wb = Workbook()
ws = wb.active
ws.title = "Students"
ws.append(["Roll", "Name", "Marks"])
ws.append([1, "Amit", 70])
ws.append([2, "Sneha", 82])
ws.append([3, "Rohit", 55])
show(ws, "Original sheet :")

# a) Insert row (a new row is inserted at row number 3)
ws.insert_rows(3)
ws["A3"] = 99
ws["B3"] = "Neha"
ws["C3"] = 91
show(ws, "a) After inserting a row at position 3 :")

# b) Delete row (row number 3 is deleted)
ws.delete_rows(3)
show(ws, "b) After deleting row 3 :")

# c) Insert column (a new column is inserted at column number 3)
ws.insert_cols(3)
ws["C1"] = "City"
ws["C2"] = "Solapur"
ws["C3"] = "Pune"
ws["C4"] = "Mumbai"
show(ws, "c) After inserting a column at position 3 :")

# d) Delete column (column number 3 is deleted)
ws.delete_cols(3)
show(ws, "d) After deleting column 3 :")

wb.save("simple_spreadsheet_setE.xlsx")
print("File saved : simple_spreadsheet_setE.xlsx")


# ---------------- Concept ----------------
# ws.insert_rows(idx) , ws.delete_rows(idx) -> insert / delete a row
# ws.insert_cols(idx) , ws.delete_cols(idx) -> insert / delete a column
# idx is the row / column number (starting from 1)
