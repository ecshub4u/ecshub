# Program Name: To draw histogram for unequal class width

# draw histogram to represent following data (unequal class width)

# class            f
# 50-100          40
# 100-150         55
# 150-200         60
# 200-300         54
# 300-400         48
# 400-550         40
# 550-750         30
# 750-1000        20

import numpy as np
import matplotlib.pyplot as plt
L=[50,100,150,200,300,400,550,750,1000] #class limit
f=[40,55,60,54,48,40,30,20] #frequency

#comput class-width
w=np.diff(L)

# comput freq.density
density=f/w
plt.bar(L[:-1],density,width=w,align='edge',color='red',edgecolor='black')
plt.title("Histogram for unequal classes")
plt.xlabel("class_limits")
plt.ylabel("frequency density")
plt.show()


# ---------------- Formula used ----------------
# Class width : w_i = upper limit - lower limit
# Frequency density : f.d_i = f_i / w_i      (height of the bar for unequal class width)
# Area of rectangle = class width * frequency density = frequency
