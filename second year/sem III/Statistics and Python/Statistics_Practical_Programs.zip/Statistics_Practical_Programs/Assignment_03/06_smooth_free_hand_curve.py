# Program Name: To draw smooth free hand curve

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline

x = [10, 20, 30, 40, 50, 60]
y = [15, 25, 20, 35, 30, 45]

new_x = np.linspace(10, 60, 300)

spline = make_interp_spline(x, y, 3)
new_y = spline(new_x)

plt.plot(new_x, new_y, color='red')
plt.show()


# ---------------- Formula used ----------------
# Smooth curve is obtained by cubic spline interpolation (spline of degree 3)
# Each piece of the curve between two points is a cubic polynomial : y = a + b*x + c*x^2 + d*x^3
# np.linspace(10, 60, 300) gives 300 equally spaced points between 10 and 60
