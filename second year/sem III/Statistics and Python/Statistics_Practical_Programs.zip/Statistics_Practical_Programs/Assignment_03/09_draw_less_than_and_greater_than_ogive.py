# Program Name: To draw less than and greater than ogive

import numpy as np
import matplotlib.pyplot as plt

limits = [25,30,35,40,45,50,55,60,65,70]
F = [5,11,17,23,33,29,17,8,3]

# ---------------- Less Than Ogive ----------------

lcf = np.cumsum(F)
new_lcf = np.insert(lcf, 0, 0)

# ---------------- Greater Than Ogive ----------------

revF = list(reversed(F))
gcf_rev = np.cumsum(revF)
new_gcf = np.insert(gcf_rev, 0, 0)
gcf = list(reversed(new_gcf))

# ---------------- Plot ----------------

plt.plot(limits, new_lcf, color='blue',linestyle='--', marker='o', label='Less Than Ogive')

plt.plot(limits, gcf, color='red',linestyle='--', marker='1', label='Greater Than Ogive')

plt.xlabel("Class Limit")
plt.ylabel("Cumulative Frequency")
plt.title("Less Than and Greater Than Ogive")

plt.legend()
plt.grid()
plt.show()


# ---------------- Formula used ----------------
# Less than cumulative frequency    : LCF_i = f_1 + f_2 + ... + f_i
# Greater than cumulative frequency : GCF_i = f_i + f_(i+1) + ... + f_k
# The point where both ogives intersect, its x-coordinate gives the Median
