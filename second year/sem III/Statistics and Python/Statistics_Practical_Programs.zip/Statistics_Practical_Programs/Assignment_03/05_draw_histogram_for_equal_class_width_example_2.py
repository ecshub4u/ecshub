# Program Name: To draw and display histogram for equal class width (0-30)

# Class (x)    Frequency (f)
# 0-5          12
# 5-10         18
# 10-15        27
# 15-20        15
# 20-25        8
# 25-30        4

import matplotlib.pyplot as plt

# Define class limits and frequencies
limits = [0, 5, 10, 15, 20, 25, 30]
f = [12, 18, 27, 15, 8, 4]

# Calculate class width
w = limits[1] - limits[0]

# Draw the histogram using bar chart logic for equal class widths
plt.bar(limits[:-1], f, width=w, align='edge', color='red', edgecolor='black')

# Add labels and title
plt.title("Histogram for Equal Class Widths")
plt.xlabel("Class Limits")
plt.ylabel("Frequency")

# Display the plot
plt.show()


# ---------------- Formula used ----------------
# Class width : w = upper limit - lower limit   (here 5 - 0 = 5)
# For equal class width, height of each bar = frequency (f)
