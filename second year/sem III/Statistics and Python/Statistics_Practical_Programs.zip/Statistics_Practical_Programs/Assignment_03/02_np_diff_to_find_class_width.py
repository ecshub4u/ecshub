# Program Name: To find difference between consecutive elements using np.diff()

import numpy as np
a=np.array([10,15,23,30])
print(np.diff(a))


# ---------------- Formula used ----------------
# Difference : d_i = a_(i+1) - a_i
# Class width : w_i = L_(i+1) - L_i   (difference between consecutive class limits)
