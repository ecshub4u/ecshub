# Program Name: To draw less than ogive

# class       f
# 50-60       7
# 60-70       12
# 70-80       19
# 80-90       27
# 90-100      24
# 100-110     12
# 110-120     8
# 120-130     6

import numpy as np
import matplotlib.pyplot as plt
limits=[50,60,70,80,90,100,110,120,130]
f=[7,12,19,27,24,12,8,6]
lcf=np.cumsum(f) #to find lcf
new_lcf=np.insert(lcf,0,0)
plt.plot(limits,new_lcf,color='red',linestyle='-',marker='1')
plt.title("less than ogive")
plt.xlabel("class limits")
plt.ylabel("lcf")
plt.grid()
plt.show()


# ---------------- Formula used ----------------
# Less than cumulative frequency : LCF_i = f_1 + f_2 + ... + f_i
# Less than ogive is the graph of upper class limits (x) against LCF (y)
# Starting point of the ogive is (lower limit of first class, 0)
