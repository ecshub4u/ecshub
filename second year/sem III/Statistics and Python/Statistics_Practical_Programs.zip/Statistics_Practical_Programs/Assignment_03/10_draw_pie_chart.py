# Program Name: To draw Pie chart (Pie diagram)

# items                       cost of construction
# steel                      2000
# sand                       3000
# bricks                     1500
# timber                     1800
# cement                     2500
# labour charges             3500

import matplotlib.pyplot as plt
cost=[2000,3000,1500,1800,2500,3500]
explode = [0, 0, 0, 0, 0, 0.1]
items=["steel","sand","bricks","timber","cement","labour"]
plt.pie(cost,labels=items,autopct="%1.2f%%", explode=explode)
plt.title("Pie chart showing cost of construction")
plt.show()


# ---------------- Formula used ----------------
# Total = sum of all component values
# Angle of a sector = (value of the component / total) * 360 degrees
# Percentage of a component = (value of the component / total) * 100
