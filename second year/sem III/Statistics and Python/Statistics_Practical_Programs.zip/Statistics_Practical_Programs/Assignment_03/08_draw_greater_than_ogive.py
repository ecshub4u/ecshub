# Program Name: To draw greater than ogive

# class     f
# 25-30     5
# 30-35     11
# 35-40     17
# 40-45     23
# 45-50     33
# 50-55     29
# 55-60     17
# 60-65     8
# 65-70     3

import numpy as np
import matplotlib.pyplot as plt

limits = [25,30,35,40,45,50,55,60,65,70]
F = [5,11,17,23,33,29,17,8,3]

revF = list(reversed(F))       # Frequency is reversed
lcf_rev = np.cumsum(revF)     # Cumulative frequency of reversed frequency

new_lcf = np.insert(lcf_rev, 0, 0)   # Zero is inserted
gcf = list(reversed(new_lcf))        # To obtain GCF

plt.plot(limits, gcf, color='red', linestyle='--', marker='1')
plt.xlabel("Class Limit")
plt.ylabel("GCF")
plt.title("Greater Than Ogive")
plt.grid()
plt.show()


# ---------------- Formula used ----------------
# Greater than cumulative frequency : GCF_i = f_i + f_(i+1) + ... + f_k
# Greater than ogive is the graph of lower class limits (x) against GCF (y)
# Ending point of the ogive is (upper limit of last class, 0)
# Total frequency N = sum of f = GCF of the first class
