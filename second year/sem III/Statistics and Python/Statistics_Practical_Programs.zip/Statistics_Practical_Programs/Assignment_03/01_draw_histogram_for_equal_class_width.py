# Program Name: To draw histogram for equal class width

# e.g draw histogram to represent following data
#        class       f
#        10-30       7
#        30-50       14
#        50-70       20
#        70-90       27
#        90-110      22
#        110-130     11
#        130-150     9
#        150-170     5

import matplotlib.pyplot as plt
limits=[10,30,50,70,90,110,130,150,170] #class-limit
f=[7,14,20,27,22,11,9,5]  #frequency
w=limits[1]-limits[0] #class_width
plt.bar(limits[:-1],f, width=w,align='edge',color='red',edgecolor='black')
plt.title("histogram for equal class_width")
plt.xlabel("class_limit")
plt.ylabel("frequency")
plt.show()


# ---------------- Formula used ----------------
# Class width : w = upper limit - lower limit   (here 30 - 10 = 20)
# For equal class width, height of each bar = frequency (f)
# Area of each rectangle is proportional to the frequency
