# Program Name: Basic histogram using plt.hist()

import numpy as np
import matplotlib.pyplot as plt
data=np.random.randn(1000)
plt.hist(data,bins=25,color="red",edgecolor="black")
plt.title("histogram")
plt.xlabel("values")
plt.ylabel("freq")
plt.show()


# ---------------- Formula used ----------------
# Class width : h = (maximum - minimum) / number of bins
# Data is generated from the standard normal distribution N(0,1)
