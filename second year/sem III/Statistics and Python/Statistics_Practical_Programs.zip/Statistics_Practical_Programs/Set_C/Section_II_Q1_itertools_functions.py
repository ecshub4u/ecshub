# Program Name: To demonstrate three itertools functions

# Set C Section-II Q1) Write a program to demonstrate any three itertools functions.

import itertools

# 1) count() : infinite counter (stopped using break)
print("count() :")
for i in itertools.count(10, 5):
    if i > 30:
        break
    print(i, end=" ")
print()

# 2) permutations() : all possible arrangements
print("permutations() of [1, 2, 3] :")
for p in itertools.permutations([1, 2, 3]):
    print(p, end=" ")
print()

# 3) combinations() : all possible selections of given size
print("combinations() of [1, 2, 3, 4] taking 2 :")
for c in itertools.combinations([1, 2, 3, 4], 2):
    print(c, end=" ")
print()


# ---------------- Concept ----------------
# itertools.count(start, step)      -> infinite iterator
# itertools.permutations(data, r)   -> r length arrangements (order matters) , nPr
# itertools.combinations(data, r)   -> r length selections (order does not matter) , nCr
