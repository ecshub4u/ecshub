# Program Name: To draw Stratified Random Sample from a normal population
# (as per Assignment_01 : to draw stratified sample)

# Set C Q2) Draw a random sample of size 40 from a normal population of size 600 with mean 35
# and standard deviation 7 by using the stratified random sampling method.
# Calculate the sample mean and sample standard deviation.

import numpy as np
p=np.random.normal(35,7,size=600) # population from N(35,7)
p1=p[:180]      #stratum 1
p2=p[180:420]   #stratum 2
p3=p[420:]      #stratum 3
print("Population:\n",p)

#To draw sample from each stratum (proportional allocation n_i = n*N_i/N)
s1=np.random.choice(p1,size=12,replace=False)
s2=np.random.choice(p2,size=16,replace=False)
s3=np.random.choice(p3,size=12,replace=False)

#To form stratified sample
stratified=np.concatenate((s1,s2,s3))
print("stratified sample:\n",stratified)
print("population A.m =",np.mean(p))
print("sample mean of stratified =",np.mean(stratified))
print("sample standard deviation of stratified =",np.std(stratified))


# ---------------- Formula used ----------------
# Population size N = N1 + N2 + N3  (here 180 + 240 + 180 = 600)
# Sample size       n = n1 + n2 + n3  (here 12 + 16 + 12 = 40)
# Proportional allocation : n_i = n * N_i / N     (sample size of i-th stratum)
# Sample mean : x_bar = (sum of x) / n
# Sample S.D. : s = sqrt( (sum of (x - x_bar)^2) / n )
