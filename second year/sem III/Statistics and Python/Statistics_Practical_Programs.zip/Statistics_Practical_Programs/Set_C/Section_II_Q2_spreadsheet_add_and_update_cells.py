# Program Name: To create a simple spreadsheet and add / update cell values

# Set C Section-II Q2) Write a program to create a simple spreadsheet and do the following operations:
# a) Adding cell values  b) Updating cell values

from openpyxl import Workbook, load_workbook

wb = Workbook()
ws = wb.active
ws.title = "Marks"

# a) Adding cell values
ws["A1"] = "Name"
ws["B1"] = "Maths"
ws["C1"] = "Stats"
ws["A2"] = "Amit"
ws["B2"] = 70
ws["C2"] = 65
ws["A3"] = "Sneha"
ws["B3"] = 82
ws["C3"] = 90
ws.append(["Rohit", 55, 60])      # add a new row at the end
print("After adding values :")
for row in ws.iter_rows(values_only=True):
    print(row)

# a) Adding two cell values
ws["D1"] = "Total"
ws["D2"] = ws["B2"].value + ws["C2"].value
ws["D3"] = "=B3+C3"               # formula
print("D2 =", ws["D2"].value, " D3 =", ws["D3"].value)

# b) Updating cell values
ws["B2"] = 75                      # old value 70 is replaced by 75
ws["A4"] = "Rohit Patil"
ws["D2"] = ws["B2"].value + ws["C2"].value
print("After updating values :")
for row in ws.iter_rows(values_only=True):
    print(row)

wb.save("simple_spreadsheet_setC.xlsx")
print("File saved : simple_spreadsheet_setC.xlsx")
wb2 = load_workbook("simple_spreadsheet_setC.xlsx")
print("B2 after reopening =", wb2["Marks"]["B2"].value)


# ---------------- Concept ----------------
# openpyxl is used to read / write Excel (.xlsx) files
# Workbook() creates a new workbook , wb.active is the active sheet
# ws["A1"] = value adds / updates a cell value , ws.append(list) adds a row at the end
# wb.save("file.xlsx") saves the file
