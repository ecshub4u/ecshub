# Program Name: To draw less than ogive

# Set C Q1) Construct a less-than ogive curve from the following frequency distribution
# Classes   : 10-20, 20-30, 30-40, 40-50, 50-60, 60-70, 70-80, 80-90
# Frequency : 10, 15, 30, 45, 55, 40, 25, 8

import numpy as np
import matplotlib.pyplot as plt

limits = [10, 20, 30, 40, 50, 60, 70, 80, 90]
f = [10, 15, 30, 45, 55, 40, 25, 8]

lcf = np.cumsum(f)                  # to find lcf
new_lcf = np.insert(lcf, 0, 0)      # starting point (10, 0)

print("Upper limit \t LCF")
for i in range(len(f)):
    print(limits[i + 1], "\t\t", lcf[i])

plt.plot(limits, new_lcf, color='red', linestyle='-', marker='1')
plt.title("less than ogive")
plt.xlabel("class limits")
plt.ylabel("lcf")
plt.grid()
plt.show()


# ---------------- Formula used ----------------
# Less than cumulative frequency : LCF_i = f_1 + f_2 + ... + f_i
# Less than ogive is the graph of upper class limits (x) against LCF (y)
# Starting point of the ogive is (lower limit of first class, 0)
