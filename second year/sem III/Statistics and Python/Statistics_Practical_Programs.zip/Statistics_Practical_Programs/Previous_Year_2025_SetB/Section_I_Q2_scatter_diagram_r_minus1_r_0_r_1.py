# Program Name: To plot scatter diagram where r = -1, r = 0 and r = 1

import numpy as np
import matplotlib.pyplot as plt

# r = 1 (perfect positive correlation)
x1 = np.array([-2, -1, 0, 1, 2])
y1 = np.array([-2, -1, 0, 1, 2])

# r = 0 (zero correlation)
x2 = np.array([-2, -1, 0, 1, 2])
y2 = np.array([1, 0, -1, 0, 1])

# r = -1 (perfect negative correlation)
x3 = np.array([-2, -1, 0, 1, 2])
y3 = np.array([2, 1, 0, -1, -2])

print("r (first graph)  =", np.corrcoef(x1, y1)[0, 1])
print("r (second graph) =", np.corrcoef(x2, y2)[0, 1])
print("r (third graph)  =", np.corrcoef(x3, y3)[0, 1])

fig, axes = plt.subplots(1, 3, figsize=(15, 5))

axes[0].scatter(x1, y1, color='red')
axes[0].set_title("r = 1")
axes[0].set_xlabel("X")
axes[0].set_ylabel("Y")

axes[1].scatter(x2, y2, color='blue')
axes[1].set_title("r = 0")
axes[1].set_xlabel("X")
axes[1].set_ylabel("Y")

axes[2].scatter(x3, y3, color='green')
axes[2].set_title("r = -1")
axes[2].set_xlabel("X")
axes[2].set_ylabel("Y")

plt.tight_layout()
plt.show()


# ---------------- Formula used ----------------
# Karl Pearson's correlation coefficient : r = Cov(x, y) / (sigma_x * sigma_y)
# r = +1 : all points lie on a straight line rising from left to right (perfect positive correlation)
# r = -1 : all points lie on a straight line falling from left to right (perfect negative correlation)
# r = 0  : no linear relationship between x and y (no correlation)
