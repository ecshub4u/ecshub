# Program Name: To use count() to generate number sequence with break condition

# 2025 Set B Section-II Q1) Use count() to Generate Number Sequence with Break Condition

from itertools import count

# count(start, step) generates numbers endlessly, so break is used to stop it
for i in count(1, 2):
    if i > 21:
        break
    print(i, end=" ")
print()

# another example : multiples of 5 up to 50
for n in count(5, 5):
    if n > 50:
        break
    print(n, end=" ")
print()


# ---------------- Concept ----------------
# itertools.count(start, step) -> infinite iterator of numbers start, start+step, start+2*step, ...
# An infinite loop is stopped using a break condition
