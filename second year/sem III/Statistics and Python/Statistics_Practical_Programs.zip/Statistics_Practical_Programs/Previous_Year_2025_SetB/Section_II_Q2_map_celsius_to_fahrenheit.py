# Program Name: To convert a list of temperatures from Celsius to Fahrenheit using map()

# 2025 Set B Section-II Q2) Use map() to convert a list of temperatures from Celsius to Fahrenheit.

celsius = [0, 10, 20, 30, 37, 100]
fahrenheit = list(map(lambda c: (c * 9 / 5) + 32, celsius))

print("Celsius    :", celsius)
print("Fahrenheit :", fahrenheit)


# ---------------- Formula used ----------------
# F = (C * 9/5) + 32
# map(function, iterable) applies the function to every element of the list
