# Program Name: Generate a 2-D array (matrix) of random integers

import numpy as np
matrix=np.random.randint(1,100,size=(3,4))
print(matrix)
# generates 3x4 matrix with random integers between 1 and 99


# ---------------- Formula used ----------------
# Random integers from Discrete Uniform distribution on {low, low+1, ..., high-1}
# P(X = x) = 1 / (high - low)
# Mean = (low + high - 1) / 2
