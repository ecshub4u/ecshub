# Program Name: Concatenate two 2-D arrays column wise (axis=1)

import numpy as np
a=np.array([[1,2],
           [3,4]])
b=np.array([[5,6],
           [7,8]])
result=np.concatenate((a,b),axis=1)
print(result)


# ---------------- Formula used ----------------
# axis = 1 : columns are added, so (r x c1) and (r x c2) give (r x (c1 + c2))
