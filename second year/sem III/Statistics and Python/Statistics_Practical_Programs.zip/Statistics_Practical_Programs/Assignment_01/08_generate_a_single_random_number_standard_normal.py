# Program Name: Generate a single random number using np.random.randn()

import numpy as np
x=np.random.randn()
print(x)


# ---------------- Formula used ----------------
# Random numbers from Standard Normal distribution N(0,1)
# Probability density function : f(z) = (1 / sqrt(2*pi)) * e^(-z^2 / 2) ; -inf < z < inf
# Mean = 0 , Standard deviation = 1
