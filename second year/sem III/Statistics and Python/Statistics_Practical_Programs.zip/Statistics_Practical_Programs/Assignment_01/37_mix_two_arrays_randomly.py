# Program Name: Mix two arrays randomly

import numpy as np
a=np.array([1,2,3])
b=np.array([4,5,6])
result=np.concatenate((a,b))
np.random.shuffle(result)
print(result)


# ---------------- Formula used ----------------
# A list of n elements can be arranged in n! (n factorial) different orders.
# (here 6! = 720 possible arrangements)
