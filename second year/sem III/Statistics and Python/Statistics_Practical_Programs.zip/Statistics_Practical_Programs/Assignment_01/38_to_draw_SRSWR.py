# Program Name: To draw Simple Random Sample With Replacement (SRSWR)

import numpy as np
#define population
p1=np.random.rand(30) #population from u(0,1)
p2=np.random.randint(10,100,size=40) #population of integers
p3=np.random.randn(50) #population from N(0,1)
p4=np.random.normal(50,10,size=60) #population from N(50,10)
p5=np.random.uniform(5,20,size=70) #population from U (5,20)
p6=np.arange(20,40,step=0.5)

#to draw sample
s1=np.random.choice(p1,size=9,replace=True)
s2=np.random.choice(p2,size=12,replace=True)
s3=np.random.choice(p3,size=15,replace=True)
s4=np.random.choice(p4,size=18,replace=True)
s5=np.random.choice(p5,size=21,replace=True)
s6=np.random.choice(p6,size=14,replace=True)

#display result
populations=[p1,p2,p3,p4,p5,p6]
samples=[s1,s2,s3,s4,s5,s6]
for i in range(6):
    print("population",i+1,": \n",populations[i])
    print("SRSWR",i+1,": \n",samples[i])
    print("population",i+1,"A.m=",np.mean(populations[i]))
    print("sample",i+1,"A.m=",np.mean(samples[i]))


# ---------------- Formula used ----------------
# Population mean   : mu = (sum of X) / N
# Sample mean       : x_bar = (sum of x) / n
# SRSWR  : total possible samples = N^n      , probability of selecting a unit at each draw = 1/N
# SRSWOR : total possible samples = NCn = N! / (n! (N - n)!) , probability of selecting a unit = n/N
# Sample mean is an unbiased estimate of the population mean : E(x_bar) = mu
