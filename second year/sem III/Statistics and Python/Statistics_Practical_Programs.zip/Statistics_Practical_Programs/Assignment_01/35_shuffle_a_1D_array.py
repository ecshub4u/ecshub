# Program Name: Shuffle a 1-D array using np.random.shuffle()

import numpy as np
array=np.array([1,2,3,4,5])
np.random.shuffle(array)
print(array)


# ---------------- Formula used ----------------
# A list of n elements can be arranged in n! (n factorial) different orders.
# (here 5! = 120 possible arrangements)
