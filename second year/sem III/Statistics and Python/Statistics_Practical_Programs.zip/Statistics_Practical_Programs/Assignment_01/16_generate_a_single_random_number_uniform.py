# Program Name: Generate a single random number using np.random.uniform()

import numpy as np
x=np.random.uniform()
print(x)


# ---------------- Formula used ----------------
# Random numbers from Uniform distribution U(a,b)
# Probability density function : f(x) = 1 / (b - a) ; a <= x < b
# Mean = (a + b) / 2
# Variance = (b - a)^2 / 12
# Relation with U(0,1) : X = a + (b - a)*U
