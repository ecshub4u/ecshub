# Program Name: Generate a single random integer using np.random.randint()

import numpy as np
x=np.random.randint(10)
print(x)

# It generates a random integer between 0 and 9


# ---------------- Formula used ----------------
# Random integers from Discrete Uniform distribution on {low, low+1, ..., high-1}
# P(X = x) = 1 / (high - low)
# Mean = (low + high - 1) / 2
