# Program Name: To draw SRSWR and SRSWOR from the same population

import numpy as np
P = np.random.uniform(5, 45, size=100)
SRSWR = np.random.choice(P, size=15, replace=True)
SRSWOR = np.random.choice(P, size=15, replace=False)
print("Population : \n", P)
print("SRSWR : \n", SRSWR)
print("SRSWOR : \n", SRSWOR)
print("Population A.M = ", np.mean(P))
print("A.M of SRSWR = ", np.mean(SRSWR))
print("A.M of SRSWOR = ", np.mean(SRSWOR))


# ---------------- Formula used ----------------
# Population mean   : mu = (sum of X) / N
# Sample mean       : x_bar = (sum of x) / n
# SRSWR  : total possible samples = N^n      , probability of selecting a unit at each draw = 1/N
# SRSWOR : total possible samples = NCn = N! / (n! (N - n)!) , probability of selecting a unit = n/N
# Sample mean is an unbiased estimate of the population mean : E(x_bar) = mu
