# Program Name: Select random elements without replacement

import numpy as np
number=[1,2,3,4,5]
result=np.random.choice(number,size=3,replace=False)
print(result) #here each unit is selected only once


# ---------------- Formula used ----------------
# Probability of selecting one unit from N units (equal probability) = 1 / N
# With replacement (SRSWR)    : total possible samples = N^n
# Without replacement (SRSWOR): total possible samples = NCn = N! / (n! (N - n)!)
