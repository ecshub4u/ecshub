# Program Name: Create an array with floating point values using np.arange()

import numpy as np
arr=np.arange(1.0,5.0,0.5)
print(arr)


# ---------------- Formula used ----------------
# Number of elements in arange(start, stop, step) = ceil((stop - start) / step)
# Elements : start, start + step, start + 2*step, ... (last value < stop)
