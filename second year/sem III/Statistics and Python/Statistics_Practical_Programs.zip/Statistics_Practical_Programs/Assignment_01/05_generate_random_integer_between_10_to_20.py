# Program Name: Generate a random integer between 10 to 20

import numpy as np
x=np.random.randint(10,20)
print(x)
# generates a random integer between 10 and 19


# ---------------- Formula used ----------------
# Random integers from Discrete Uniform distribution on {low, low+1, ..., high-1}
# P(X = x) = 1 / (high - low)
# Mean = (low + high - 1) / 2
