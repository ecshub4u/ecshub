# Program Name: Select one random element using np.random.choice()

import numpy as np
x=np.random.choice([10,20,30,40,50])
print(x)


# ---------------- Formula used ----------------
# Probability of selecting one unit from N units (equal probability) = 1 / N
# With replacement (SRSWR)    : total possible samples = N^n
# Without replacement (SRSWOR): total possible samples = NCn = N! / (n! (N - n)!)
