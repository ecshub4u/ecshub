# Program Name: To draw Stratified Random Sample

import numpy as np
p1=np.random.rand(30) #stratum 1 from U (0,1)
p2=np.random.rand(40) #stratum 2 from U (0,1)
p3=np.random.uniform(10,20,50) #stratum 3 from U (10,20)
p4=np.arange(50,100,0.5) #stratum 4
hetro=np.concatenate((p1,p2,p3,p4)) # Heterogeneous population
np.random.shuffle(hetro)
print("Hetrogeneous population:\n",hetro)
srswor=np.random.choice(hetro,size=44,replace=False)
print("srswor: \n", srswor)

#To draw sample from each stratum
s1=np.random.choice(p1,size=6,replace=False)
s2=np.random.choice(p2,size=8,replace=False)
s3=np.random.choice(p3,size=10,replace=False)
s4=np.random.choice(p4,size=20,replace=False)

#To form stratified sample
stratified=np.concatenate((s1,s2,s3,s4))
print("stratified sample:\n",stratified)
print("population A.m =",np.mean(hetro))
print("A.m of srswor=",np.mean(srswor))
print("A.m of stratified=",np.mean(stratified))


# ---------------- Formula used ----------------
# Population size N = N1 + N2 + N3 + N4  (here 30 + 40 + 50 + 100 = 220)
# Sample size       n = n1 + n2 + n3 + n4  (here 6 + 8 + 10 + 20 = 44)
# Proportional allocation : n_i = n * N_i / N     (sample size of i-th stratum)
# Population mean : mu = (sum of X) / N
# Sample mean     : x_bar = (sum of x) / n
