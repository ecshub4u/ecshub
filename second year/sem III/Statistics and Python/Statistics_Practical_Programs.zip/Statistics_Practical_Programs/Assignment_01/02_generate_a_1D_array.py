# Program Name: Generate a 1-D array of random numbers using np.random.rand()

import numpy as np
arr=np.random.rand(5)
print(arr)


# ---------------- Formula used ----------------
# Random numbers from Uniform distribution U(0,1)
# Probability density function : f(x) = 1 ; 0 <= x < 1
# Mean = 1/2
# Variance = 1/12
