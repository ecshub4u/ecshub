# Program Name: Select 5 random numbers from 0 to 9

import numpy as np
x=np.random.choice(10,size=5)
print(x)


# ---------------- Formula used ----------------
# Probability of selecting one unit from N units (equal probability) = 1 / N
# With replacement (SRSWR)    : total possible samples = N^n
# Without replacement (SRSWOR): total possible samples = NCn = N! / (n! (N - n)!)
