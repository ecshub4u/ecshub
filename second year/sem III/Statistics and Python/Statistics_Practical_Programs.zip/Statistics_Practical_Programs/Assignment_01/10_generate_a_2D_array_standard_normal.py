# Program Name: Generate a 2-D array (matrix) using np.random.randn()

import numpy as np
matrix=np.random.randn(3,4)
print(matrix)


# ---------------- Formula used ----------------
# Random numbers from Standard Normal distribution N(0,1)
# Probability density function : f(z) = (1 / sqrt(2*pi)) * e^(-z^2 / 2) ; -inf < z < inf
# Mean = 0 , Standard deviation = 1
