# Program Name: Select random elements with given probabilities

import numpy as np
colors=["red","blue","green"]
result=np.random.choice(colors,size=5,p=[0.5,0.3,0.2])
print(result)


# ---------------- Formula used ----------------
# Probability of selecting one unit from N units (equal probability) = 1 / N
# With replacement (SRSWR)    : total possible samples = N^n
# Without replacement (SRSWOR): total possible samples = NCn = N! / (n! (N - n)!)
# Sum of all probabilities = 1  (here 0.5 + 0.3 + 0.2 = 1)
# P(X = x_i) = p_i
