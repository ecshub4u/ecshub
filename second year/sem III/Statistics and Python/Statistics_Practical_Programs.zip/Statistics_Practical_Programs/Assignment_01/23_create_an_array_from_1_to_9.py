# Program Name: Create an array from 1 to 9 using np.arange()

import numpy as np
arr=np.arange(1,10)
print(arr)


# ---------------- Formula used ----------------
# Number of elements in arange(start, stop, step) = ceil((stop - start) / step)
# Elements : start, start + step, start + 2*step, ... (last value < stop)
