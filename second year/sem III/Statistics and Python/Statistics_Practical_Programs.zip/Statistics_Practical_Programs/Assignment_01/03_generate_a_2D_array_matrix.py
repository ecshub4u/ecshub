# Program Name: Generate a 2-D array (matrix) of random numbers using np.random.rand()

import numpy as np
matrix=np.random.rand(3,4)
print(matrix)


# ---------------- Formula used ----------------
# Random numbers from Uniform distribution U(0,1)
# Probability density function : f(x) = 1 ; 0 <= x < 1
# Mean = 1/2
# Variance = 1/12
