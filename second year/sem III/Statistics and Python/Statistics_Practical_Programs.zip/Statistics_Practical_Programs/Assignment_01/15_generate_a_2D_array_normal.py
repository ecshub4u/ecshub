# Program Name: Generate a 2-D array from N(50,10)

import numpy as np
arr=np.random.normal(loc=50,scale=10,size=(3,4))
print(arr)


# ---------------- Formula used ----------------
# Random numbers from Normal distribution N(mu, sigma^2)
# Probability density function : f(x) = (1 / (sigma*sqrt(2*pi))) * e^(-(x - mu)^2 / (2*sigma^2))
# Mean = mu (loc) , Standard deviation = sigma (scale)
# Relation with standard normal variate : X = mu + sigma*Z   where Z ~ N(0,1)
# Standard normal variate : Z = (X - mu) / sigma
