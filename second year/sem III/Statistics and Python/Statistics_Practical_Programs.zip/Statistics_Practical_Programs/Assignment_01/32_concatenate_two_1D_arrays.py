# Program Name: Concatenate two 1-D arrays

import numpy as np
a=np.array([1,2,3])
b=np.array([4,5,6])
result=np.concatenate((a,b))
print(result)


# ---------------- Formula used ----------------
# Size of the new array = size of first array + size of second array
# (here 3 + 3 = 6)
