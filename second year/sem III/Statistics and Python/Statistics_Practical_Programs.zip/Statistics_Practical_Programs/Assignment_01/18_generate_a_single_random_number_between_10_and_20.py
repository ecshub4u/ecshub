# Program Name: Generate a single random number between 10 and 20

import numpy as np
x=np.random.uniform(10,20)
print(x)


# ---------------- Formula used ----------------
# Random numbers from Uniform distribution U(a,b)
# Probability density function : f(x) = 1 / (b - a) ; a <= x < b
# Mean = (a + b) / 2
# Variance = (b - a)^2 / 12
# Relation with U(0,1) : X = a + (b - a)*U
