# Program Name: Select random elements from a list of fruits

import numpy as np
fruits=["apple","orange","banana","mango"]
result=np.random.choice(fruits,size=3)
print(result)


# ---------------- Formula used ----------------
# Probability of selecting one unit from N units (equal probability) = 1 / N
# With replacement (SRSWR)    : total possible samples = N^n
# Without replacement (SRSWOR): total possible samples = NCn = N! / (n! (N - n)!)
