# Program Name: Shuffle a list using np.random.shuffle()

import numpy as np
numbers=[10,20,30,40,50,60]
np.random.shuffle(numbers)
print(numbers)


# ---------------- Formula used ----------------
# A list of n elements can be arranged in n! (n factorial) different orders.
# (here 6! = 720 possible arrangements)
