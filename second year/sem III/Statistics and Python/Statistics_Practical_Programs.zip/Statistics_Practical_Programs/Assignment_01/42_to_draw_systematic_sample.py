# Program Name: To draw Systematic Sample

import numpy as np
p = np.random.uniform(50, 60, size=150)
print("Population:\n", p)
N = len(p)
print("Population size =", N)
n = int(input("Enter the sample size: "))
K = N // n #No of item in each sequential group
print("No. of items in each sequential group =", K)
s1 = np.random.randint(0, K) # Selection of first item in first sequential group
systematic = p[s1::K] # slicing
print("Systematic sample:\n", systematic)
print("Population A.M. =", np.mean(p))
print("Systematic Sample A.M. =", np.mean(systematic))


# ---------------- Formula used ----------------
# Sampling interval : K = N / n    (N = population size, n = sample size)
# Random start      : r = a random number between 1 and K (here 0 to K-1 because index starts from 0)
# Selected units    : r, r + K, r + 2K, r + 3K, ...
# Population mean   : mu = (sum of X) / N
# Sample mean       : x_bar = (sum of x) / n
