# Program Name: Generate a 1-D array using np.random.randn()

import numpy as np
array=np.random.randn(5)
print(array)


# ---------------- Formula used ----------------
# Random numbers from Standard Normal distribution N(0,1)
# Probability density function : f(z) = (1 / sqrt(2*pi)) * e^(-z^2 / 2) ; -inf < z < inf
# Mean = 0 , Standard deviation = 1
