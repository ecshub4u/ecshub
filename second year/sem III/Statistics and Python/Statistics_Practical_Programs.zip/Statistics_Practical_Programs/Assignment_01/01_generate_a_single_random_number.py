# Program Name: Generate a single random number using np.random.rand()

import numpy as np
x=np.random.rand()
print(x)


# ---------------- Formula used ----------------
# Random numbers from Uniform distribution U(0,1)
# Probability density function : f(x) = 1 ; 0 <= x < 1
# Mean = 1/2
# Variance = 1/12
