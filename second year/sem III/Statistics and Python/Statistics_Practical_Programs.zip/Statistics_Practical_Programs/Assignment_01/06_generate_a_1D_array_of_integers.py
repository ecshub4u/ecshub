# Program Name: Generate a 1-D array of random integers

import numpy as np
arr=np.random.randint(1,10,size=5)
print(arr)
# generates 5 random integers between 1 and 9


# ---------------- Formula used ----------------
# Random integers from Discrete Uniform distribution on {low, low+1, ..., high-1}
# P(X = x) = 1 / (high - low)
# Mean = (low + high - 1) / 2
