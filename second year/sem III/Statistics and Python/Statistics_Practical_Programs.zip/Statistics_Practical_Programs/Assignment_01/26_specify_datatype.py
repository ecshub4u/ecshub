# Program Name: Create an array and specify the datatype using np.arange()

import numpy as np
arr=np.arange(1,6,dtype=float)
print(arr)


# ---------------- Formula used ----------------
# Number of elements in arange(start, stop, step) = ceil((stop - start) / step)
# Elements : start, start + step, start + 2*step, ... (last value < stop)
