# Program Name: Generate a 2-D array (matrix) using np.random.uniform()

import numpy as np
matrix=np.random.uniform(20,30,size=(3,4))
print(matrix)


# ---------------- Formula used ----------------
# Random numbers from Uniform distribution U(a,b)
# Probability density function : f(x) = 1 / (b - a) ; a <= x < b
# Mean = (a + b) / 2
# Variance = (b - a)^2 / 12
# Relation with U(0,1) : X = a + (b - a)*U
