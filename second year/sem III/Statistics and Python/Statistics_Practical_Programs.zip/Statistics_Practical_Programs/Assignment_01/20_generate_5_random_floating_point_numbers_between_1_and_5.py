# Program Name: Generate 5 random floating point numbers between 1 and 5

import numpy as np
arr=np.random.uniform(1,5,size=5)
print(arr)


# ---------------- Formula used ----------------
# Random numbers from Uniform distribution U(a,b)
# Probability density function : f(x) = 1 / (b - a) ; a <= x < b
# Mean = (a + b) / 2
# Variance = (b - a)^2 / 12
# Relation with U(0,1) : X = a + (b - a)*U
