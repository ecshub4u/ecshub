# Program Name: Concatenate two 2-D arrays row wise (axis=0)

import numpy as np
a=np.array([[1,2],
           [3,4]])
b=np.array([[5,6],
           [7,8]])
result=np.concatenate((a,b),axis=0)
print(result)


# ---------------- Formula used ----------------
# axis = 0 : rows are added, so (r1 x c) and (r2 x c) give ((r1 + r2) x c)
