# Program Name: Fitting a second degree curve y = a + bx + cx^2 and estimating y

# Fit second degree curve y = a + bx + cx^2 to the following data and hence estimate y for x = 50
# x: 10, 15, 20, 22, 27, 30, 34
# y: 46, 74, 112, 130, 182, 218, 258

import numpy as np

x = np.array([10, 15, 20, 22, 27, 30, 34]) # independent variable
y = np.array([46, 74, 112, 130, 182, 218, 258]) # dependent variable

coeff = np.polyfit(x, y, 2) #coefficients of second degree curve
c, b, a = np.round(coeff, 2)

print("c =", c, "b =", b, "a =", a)
print("Equation of second degree curve=")
print("y =", a, "+", b, "x ","+", c, "x^2")

x1 = float(input("Enter known value of x: "))
estimate_y = a +(b*x1) + (c*x1*x1)
# estimate_y = np.polyval(coeff, x1)
print("Estimated value of y for x =", x1, "is", estimate_y)


# ---------------- Formula used ----------------
# Second degree curve : y = a + b*x + c*x^2
# Normal equations (least squares method) :
#   sum(y)     = n*a + b*sum(x)   + c*sum(x^2)
#   sum(x*y)   = a*sum(x) + b*sum(x^2) + c*sum(x^3)
#   sum(x^2*y) = a*sum(x^2) + b*sum(x^3) + c*sum(x^4)
# Solving these three equations gives a, b and c
