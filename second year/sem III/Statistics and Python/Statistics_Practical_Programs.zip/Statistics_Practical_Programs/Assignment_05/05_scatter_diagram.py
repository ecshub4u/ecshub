# Program Name: To draw scatter diagram

# data:
# x: 12,23,34,45,56,67,78,89
# y: 23,32,43,54,65,76,87,98

import matplotlib.pyplot as plt

x = [12, 23, 34, 45, 56, 67, 78, 89]
y = [23, 32, 43, 54, 65, 76, 87, 98]

plt.scatter(x, y, color="red", s=100, marker="*")

plt.title("Scatter Diagram")
plt.xlabel("X - Coordinates")
plt.ylabel("Y - Coordinates")

plt.show()

# correlation: The scatter diagram shows a positive correlation between X and Y.


# ---------------- Formula used ----------------
# Scatter diagram is the graph of the pairs of observations (x_i, y_i)
# Points rising from left to right -> positive correlation (r > 0)
# Points falling from left to right -> negative correlation (r < 0)
# Points scattered randomly -> no correlation (r = 0)
