# Program Name: Fitting an exponential curve y = a * b^x and estimating y

# Fit exponential curve y = a * b^x to the following data and hence estimate y for x = 7
# x: 2  3  4  5  6
# y: 225 338 506 760 1140

import numpy as np

x = np.array([2, 3, 4, 5, 6])             #independent variable
y = np.array([225, 338, 506, 760, 1140])  #dependent variable

u = np.log10(y)

coeff = np.polyfit(x, u, 1)

B, A = coeff

print("B =", B, "A =", A)

a = 10 ** A  # a= antilog of A
b = 10 ** B  # b= antilog of B

print("b =", b, "a =", a)

print("Equation of exponential curve=")
print("y =", a, "*", b, "^x")

x1 = float(input("Enter known value of x:"))

estimate_y = a * (b ** x1)

print("Estimated value of y for x =", x1, "is", estimate_y)


# ---------------- Formula used ----------------
# Exponential curve : y = a * b^x
# Taking log on both sides : log y = log a + x * log b
# Put u = log y , A = log a , B = log b   ->   u = A + B*x   (line of regression u on x)
# Normal equations :
#   sum(u)   = n*A + B*sum(x)
#   sum(x*u) = A*sum(x) + B*sum(x^2)
# a = antilog(A) = 10^A
# b = antilog(B) = 10^B
