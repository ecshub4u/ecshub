# Program Name: To find Karl Pearson correlation coefficient

# Find the Karl Pearson correlation coefficient between the height and weight (x, y) of 5 students.
# Height (cm) [x]: 165, 155, 157, 171, 160
# Weight (kg) [y]: 60, 62, 58, 72, 57

import numpy as np

x = [165, 155, 157, 171, 160]
y = [60, 62, 58, 72, 57]
r = np.corrcoef(x, y)[0, 1]
print("Correlation coefficient =", r)

if r < 0:
    print("There is negative correlation between x & y")
else:
    print("There is positive correlation between x & y")


# ---------------- Formula used ----------------
# Karl Pearson's correlation coefficient :
#   r = Cov(x, y) / (sigma_x * sigma_y)
#   Cov(x, y) = (sum of x*y) / n - (x_bar * y_bar)
#   r = (n*sum(xy) - sum(x)*sum(y)) / ( sqrt(n*sum(x^2) - (sum(x))^2) * sqrt(n*sum(y^2) - (sum(y))^2) )
# Value of r lies between -1 and +1
#   r = +1 -> perfect positive correlation , r = -1 -> perfect negative correlation , r = 0 -> no correlation
