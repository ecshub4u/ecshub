# Program Name: Fitting a line of regression y on x (y = a + bx) and estimating y

# Fit a line of regression y on x (y = a + bx, x = independent variable, y = dependent variable)
# for the following data and hence estimate y for x = 60
# x: 30, 34, 25, 29, 52, 44, 47, 38
# y: 46, 49, 42, 45, 63, 57, 59, 52

import numpy as np

x = np.array([30, 34, 25, 29, 52, 44, 47, 38]) # independent variable
y = np.array([46, 49, 42, 45, 63, 57, 59, 52]) # dependent variable

coeff = np.polyfit(x, y, 1)
b, a = np.round(coeff, 2)

print("b =", b, "a =", a)
print("Equation of line of regression y on x:")
print("y =", a, "+", b, "x")

x1 = float(input("Enter known value of x: "))
estimate_y = a+b*x1
# estimate_y = np.polyval(coeff, x1)

print("Estimated value of y for x =", x1, "is", estimate_y)

# Note:
#       To fit equation of line of regression x on y
#       x=a+by (here y is independent variable and x is dependent variable)
#       replace x by y and y by x in above program.


# ---------------- Formula used ----------------
# Line of regression y on x : y = a + b*x
# Normal equations :
#   sum(y)   = n*a + b*sum(x)
#   sum(x*y) = a*sum(x) + b*sum(x^2)
# Regression coefficient : b = (n*sum(xy) - sum(x)*sum(y)) / (n*sum(x^2) - (sum(x))^2) = Cov(x,y) / Var(x)
# Constant               : a = y_bar - b*x_bar
# Line of regression x on y : x = a + b*y , b = (n*sum(xy) - sum(x)*sum(y)) / (n*sum(y^2) - (sum(y))^2)
