# Program Name: To find Karl Pearson correlation coefficient and interpret the result
# (as per Assignment_05 : Karl Pearson correlation coefficient)

# Set B Q2) Find Karl Pearson's correlation coefficient between income and expenditure
# from the following data and interpret the result.
# income      : 1000, 2000, 2500, 2700, 3000, 3300, 4100
# expenditure :  800, 1300, 1800, 1900, 2100, 2340, 2450

import numpy as np

x = [1000, 2000, 2500, 2700, 3000, 3300, 4100]
y = [800, 1300, 1800, 1900, 2100, 2340, 2450]
r = np.corrcoef(x, y)[0, 1]
print("Correlation coefficient =", r)

if r < 0:
    print("There is negative correlation between income & expenditure")
else:
    print("There is positive correlation between income & expenditure")


# ---------------- Formula used ----------------
# Karl Pearson's correlation coefficient :
#   r = Cov(x, y) / (sigma_x * sigma_y)
#   Cov(x, y) = (sum of x*y) / n - (x_bar * y_bar)
#   r = (n*sum(xy) - sum(x)*sum(y)) / ( sqrt(n*sum(x^2) - (sum(x))^2) * sqrt(n*sum(y^2) - (sum(y))^2) )
# Value of r lies between -1 and +1
#   r = +1 -> perfect positive correlation , r = -1 -> perfect negative correlation , r = 0 -> no correlation
# Interpretation : r is close to +1, so income and expenditure have a very strong positive correlation
