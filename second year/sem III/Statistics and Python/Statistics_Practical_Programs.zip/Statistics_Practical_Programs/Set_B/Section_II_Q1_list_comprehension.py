# Program Name: To demonstrate list comprehension

# Set B Section-II Q1) Write a program to demonstrate list comprehension.

# Syntax : [expression for item in iterable if condition]
squares = [x ** 2 for x in range(1, 11)]
print("Squares of 1 to 10 :", squares)

even = [x for x in range(1, 21) if x % 2 == 0]
print("Even numbers from 1 to 20 :", even)

words = ["python", "numpy", "pandas"]
upper = [w.upper() for w in words]
print("Uppercase :", upper)

lengths = [len(w) for w in words]
print("Length of words :", lengths)

# if-else inside list comprehension
result = ["even" if x % 2 == 0 else "odd" for x in range(1, 6)]
print("Even / odd :", result)

# nested list comprehension (multiplication table matrix)
table = [[i * j for j in range(1, 4)] for i in range(1, 4)]
print("Matrix :", table)


# ---------------- Concept ----------------
# List comprehension is a short way to create a new list from an iterable
# It replaces a for loop + append() in a single line
