# Program Name: To demonstrate findall, sub, split and search functions of regular expressions

# Set B Section-II Q2) Write a program to demonstrate findall, sub, split, and search functions in
# regular expressions.

import re

text = "My phone number is 9876543210 and my friend's number is 9123456789"

# findall() : returns a list of all matches
numbers = re.findall(r"\d{10}", text)
print("findall :", numbers)

# search() : returns the first match (match object) or None
m = re.search(r"number", text)
print("search :", m)
print("Matched text =", m.group(), " Start =", m.start(), " End =", m.end())

# sub() : replaces matches with a new string
new_text = re.sub(r"\d{10}", "XXXXXXXXXX", text)
print("sub :", new_text)

# split() : splits the string at every match
parts = re.split(r"\s", "Python is easy to learn")
print("split :", parts)
print("split on comma/semicolon :", re.split(r"[,;]", "a,b;c,d"))


# ---------------- Concept ----------------
# re.findall(pattern, string)          -> list of all matches
# re.search(pattern, string)           -> first match object (None if not found)
# re.sub(pattern, replacement, string) -> string after replacement
# re.split(pattern, string)            -> list of strings split at the matches
# \d = digit , \s = white space , {10} = exactly 10 times
