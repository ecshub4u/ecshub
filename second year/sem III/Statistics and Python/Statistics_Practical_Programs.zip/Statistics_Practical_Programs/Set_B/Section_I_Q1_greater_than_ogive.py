# Program Name: To draw greater than ogive

# Set B Q1) Draw a greater-than ogive to represent the following data.
# Class   7-14  14-21  21-28  28-35  35-42  42-49
# Freq     11     15     17     12      9      5

import numpy as np
import matplotlib.pyplot as plt

limits = [7, 14, 21, 28, 35, 42, 49]
F = [11, 15, 17, 12, 9, 5]

revF = list(reversed(F))             # Frequency is reversed
lcf_rev = np.cumsum(revF)            # Cumulative frequency of reversed frequency
new_lcf = np.insert(lcf_rev, 0, 0)   # Zero is inserted
gcf = list(reversed(new_lcf))        # To obtain GCF

print("Lower limit \t GCF")
for i in range(len(gcf)):
    print(limits[i], "\t\t", gcf[i])

plt.plot(limits, gcf, color='red', linestyle='--', marker='1')
plt.xlabel("Class Limit")
plt.ylabel("GCF")
plt.title("Greater Than Ogive")
plt.grid()
plt.show()


# ---------------- Formula used ----------------
# Greater than cumulative frequency : GCF_i = f_i + f_(i+1) + ... + f_k
# Greater than ogive is the graph of lower class limits (x) against GCF (y)
# Ending point of the ogive is (upper limit of last class, 0)
# Total frequency N = sum of f = GCF of the first class
