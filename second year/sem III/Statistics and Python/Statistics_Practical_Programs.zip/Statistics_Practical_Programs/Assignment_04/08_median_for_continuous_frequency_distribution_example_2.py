# Program Name: To find median for continuous frequency distribution (example 2)

import numpy as np

# Data
L = np.array([0, 10, 20])   # Lower limit
U = np.array([10, 20, 30])  # Upper limit
F = np.array([50, 20, 30])  # Frequency

N = np.sum(F)               # Sum of frequency
LCF = np.cumsum(F)          # To find LCF

i = np.where(LCF >= N/2)[0][0]   # To find index of median class

print("Median class index =", i)
print("Median class =", L[i], "-", U[i])

l = L[i]                    # Lower limit of median class
CF = LCF[i-1] if i > 0 else 0    # LCF of pre-median class (0 if median class is the first class)
f1 = F[i]                   # Frequency of median class
h = U[i] - L[i]             # Width of median class

Me = l + ((N/2 - CF) / f1) * h

print("Pre-median CF =", CF)
print("Median =", Me)


# ---------------- Formula used ----------------
# Median class = class having LCF >= N/2
# Median : Me = L + ((N/2 - CF) / f) * h
# where,
#   L  = lower limit of median class
#   CF = LCF of the pre-median class (class just before the median class)
#   f  = frequency of median class
#   h  = width of median class
#   N  = total frequency (sum of f)
# Less than cumulative frequency : LCF_i = f_1 + f_2 + ... + f_i
