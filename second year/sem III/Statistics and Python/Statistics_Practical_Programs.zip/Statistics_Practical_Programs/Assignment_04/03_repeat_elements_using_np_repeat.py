# Program Name: To repeat elements according to frequency using np.repeat()

import numpy as np
x=[5,6,7,8]
f=[2,3,4,2]
data=np.repeat(x,f)
print(data)


# ---------------- Formula used ----------------
# Each value x_i is repeated f_i times, so total number of observations N = sum of f
