# Program Name: To calculate range and coefficient of range

# Data: 20, 18, 25, 27, 35, 16, 22, 37

import numpy as np

# Define the input data
data = np.array([20, 18, 25, 27, 35, 16, 22, 37])

# Find the largest (l) and smallest (s) values
l = np.max(data)
s = np.min(data)

# Calculate Range
R = l - s

# Calculate Coefficient of Range
coeff_R = (l - s) / (l + s)

# Display the results
print("Data:", data)
print("Largest value (l) =", l)
print("Smallest value (s) =", s)
print("Range =", R)
print("Coefficient of Range =", coeff_R)


# ---------------- Formula used ----------------
# Range                : R = L - S        (L = largest value, S = smallest value)
# Coefficient of range : (L - S) / (L + S)
