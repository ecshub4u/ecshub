# Program Name: To find mode for continuous frequency distribution (grouped data)

# Class	Frequency
# 14-24	15
# 24-34	28
# 34-44	34
# 44-54	40
# 54-64	37
# 64-74	25
# 74-84	12

import numpy as np

L = np.array([14, 24, 34, 44, 54, 64, 74])    # Lower limit
U = np.array([24, 34, 44, 54, 64, 74, 84])    # Upper limit
F = np.array([15, 28, 34, 40, 37, 25, 12])    # Frequency

i = np.argmax(F)                              # Index of modal class

print("Modal class index =", i)

l = L[i]                                      # Lower limit of modal class
f1 = F[i]                                     # Frequency of modal class
f0 = F[i-1]                                   # Frequency of pre-modal class
f2 = F[i+1]                                   # Frequency of post-modal class
h = U[i] - L[i]                               # Width of modal class

Mo = l + ((f1 - f0) / (2 * f1 - f0 - f2)) * h

print("Mode =", Mo)


# ---------------- Formula used ----------------
# Modal class = class having maximum frequency
# Mode : Mo = l + ((f1 - f0) / (2*f1 - f0 - f2)) * h
# where,
#   l  = lower limit of modal class
#   f1 = frequency of modal class
#   f0 = frequency of pre-modal class (class just before the modal class)
#   f2 = frequency of post-modal class (class just after the modal class)
#   h  = width of modal class
