# Program Name: Measures of central tendency and dispersion for individual (raw) data

# TO find Arithmetic mean, median, Quartiles, mode, range, Coefficient of range, SD, variance, and C.V
# for the data given below.
# data = 24,27,42,30,37,45,48,42,23,32

import numpy as np
from scipy import stats

data = np.array([24,27,42,30,37,45,48,42,23,32])

am=np.mean(data)
print(" Arithmetic mean =",am)

Me=np.median(data)
print("Median =",Me)

Mo=stats.mode(data)
print("Mode =",Mo.mode ,"freq of model value=",Mo.count)

Q1=np.percentile(data,25)
print("Q1=",Q1)

Q2=np.percentile(data,50)
print("Q2=",Q2)

Q3=np.percentile(data,75)
print("Q3=",Q3)

l=np.max(data)
s=np.min(data)
R=(l-s)
coeff_r=(l-s)/(l+s)
print("Range=",R,"Coefficient of Range=",coeff_r)

sd=np.std(data)
print("Standard Deviation =", sd)

var=np.var(data)
print("Variance =", var)

cv=sd/abs(am)*100
print("Coefficient of Variation =", cv)


# ---------------- Formula used ----------------
# Arithmetic mean : x_bar = (sum of x) / n
# Median          : n odd  -> middle value of ordered data ; n even -> average of the two middle values
# Mode            : value having maximum frequency
# Quartiles       : Q1 = value of ((n+1)/4)th item , Q2 = value of ((n+1)/2)th item , Q3 = value of (3(n+1)/4)th item
#                   (np.percentile uses linear interpolation : position = (n-1)*p/100)
# Range                     : R = L - S           (L = largest value, S = smallest value)
# Coefficient of range      : (L - S) / (L + S)
# Variance                  : sigma^2 = (sum of (x - x_bar)^2) / n
# Standard deviation (S.D.) : sigma = sqrt(variance)
# Coefficient of variation  : C.V. = (sigma / |x_bar|) * 100
