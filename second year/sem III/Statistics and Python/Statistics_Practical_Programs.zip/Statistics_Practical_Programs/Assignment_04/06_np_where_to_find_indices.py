# Program Name: To find indices of elements satisfying a condition using np.where()

import numpy as np
a = np.array([10, 20, 30, 40, 50, 60])
result = np.where(a > 30)
print(result)

# output:(array([3, 4, 5]),)

# here 40,50,60 elements are greater than 30 their indices are 3,4,5.


# ---------------- Formula used ----------------
# No calculation formula is used in this program.
