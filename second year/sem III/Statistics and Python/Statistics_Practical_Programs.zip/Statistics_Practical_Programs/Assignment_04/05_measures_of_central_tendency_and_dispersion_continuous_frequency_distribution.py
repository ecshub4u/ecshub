# Program Name: Arithmetic mean, variance, S.D., C.V., range and coefficient of range for continuous frequency distribution

# class                    f
# 15-20                    5
# 20-25                    9
# 25-30                   11
# 30-35                   17
# 35-40                   14
# 40-45                   10
# 45-50                    7
# 50-55                    5
# 55-60                    3

import numpy as np
L =np.array ([15, 20, 25, 30, 35, 40, 45, 50, 55]) #lower limit
U =np.array ([20, 25, 30, 35, 40, 45, 50, 55, 60]) #upper limit
f =np.array ([5, 9, 11, 17, 14, 10, 7, 5, 3]) #frequency
N=np.sum(f) #To prove sum of f or to prove sum of frequency
M = (L + U)/2 #To find midpoint
S1=np.sum(f*M) #To find sum of f*M
S2=np.sum(f*M*M) #To find sum of f*M*M
mean = S1/N
var = S2/N - (mean * mean)
sd = np.sqrt(var)
print("Arithmetic Mean=",mean)
print("variance=",var,"\nstandard deviation=",sd)
cv=sd/abs(mean) * 100
print("coefficient of variation=",cv)
l=np.max(U)
s=np.min(L)
R=(l-s)
coeff_R = (l-s) / (l+s)
print("Range=",R,"\ncoefficiant of range=",coeff_R)


# ---------------- Formula used ----------------
# Total frequency : N = sum of f
# Mid point of class : m = (lower limit + upper limit) / 2
# Arithmetic mean    : x_bar = (sum of f*m) / N
# Variance           : sigma^2 = (sum of f*m^2) / N - (x_bar)^2
# Standard deviation : sigma = sqrt(variance)
# Coefficient of variation : C.V. = (sigma / |x_bar|) * 100
# Range              : R = L - S   (L = upper limit of last class, S = lower limit of first class)
# Coefficient of range : (L - S) / (L + S)
