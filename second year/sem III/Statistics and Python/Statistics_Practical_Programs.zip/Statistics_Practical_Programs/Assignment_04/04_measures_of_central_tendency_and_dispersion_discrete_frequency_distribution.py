# Program Name: Measures of central tendency and dispersion for discrete frequency distribution

# compute A.M, median, mode, Quartile, sd, variance, c.v, range and Coefficient of Range.
#
# x : 14   16   17   19   20   22   24   27
# f :  3    7    9   14   10    8    6    4

import numpy as np
from scipy import stats

x = np.array([14, 16, 17, 19, 20, 22, 24, 27])
f = np.array([3, 7, 9, 14, 10, 8, 6, 4])

data = np.repeat(x, f)
print("Data:", data)

am=np.mean(data)
print(" Arithmetic mean =",am)
Me=np.median(data)
print("Median =",Me)
MO=stats.mode(data)
print("Mode =",MO.mode ,"freq of model value=",MO.count)
Q1=np.percentile(data,25)
print("Q1=",Q1)
Q2=np.percentile(data,50)
print("Q2=",Q2)
Q3=np.percentile(data,75)
print("Q3=",Q3)
l=np.max(data)
s=min(data)
R=l-s
coeff_r=(l-s)/(l+s)
print("Range=",R,"Coefficient of Range=",coeff_r)
sd=np.std(data)
var=np.var(data)
print("Standard Deviation =", sd,"Variance =", var)
cv=sd/abs(am)*100
print("Coefficient of Variation =", cv)


# ---------------- Formula used ----------------
# Total frequency : N = sum of f
# Arithmetic mean : x_bar = (sum of f*x) / N
# Median          : value of the (N/2)th observation in the ordered data (cumulative frequency >= N/2)
# Mode            : value of x having maximum frequency
# Quartiles       : Q1 = value of (N+1)/4 th item , Q2 = value of (N+1)/2 th item , Q3 = value of 3(N+1)/4 th item
#                   (np.percentile uses linear interpolation : position = (N-1)*p/100)
# Range                     : R = L - S
# Coefficient of range      : (L - S) / (L + S)
# Variance                  : sigma^2 = (sum of f*x^2) / N - (x_bar)^2
# Standard deviation (S.D.) : sigma = sqrt(variance)
# Coefficient of variation  : C.V. = (sigma / |x_bar|) * 100
