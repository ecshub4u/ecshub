# Program Name: To find index of maximum element using np.argmax()

import numpy as np
a = np.array([10, 25, 15, 40, 20, 17])
result = np.argmax(a)
print(result)


# ---------------- Formula used ----------------
# No calculation formula is used in this program.
