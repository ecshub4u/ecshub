# Program Name: To find mode using stats.mode()

from scipy import stats
data = [10, 20, 20, 20, 30, 30, 40]
result = stats.mode(data)
print(result.mode)
print(result.count)
print(result)


# ---------------- Formula used ----------------
# Mode = the value which occurs maximum number of times (value having highest frequency)
# (here mode = 20 with frequency 3)
