# Program Name: To calculate coefficient of variation (C.V.) for discrete frequency distribution

# x(value): 10,20,30,40,50
# F(frequency): 5, 8 , 15, 16, 6

import numpy as np
x = np.array([10, 20, 30, 40, 50])
f = np.array([5, 8, 15, 16, 6])

data = np.repeat(x, f)

# Calculate Arithmetic Mean
am = np.mean(data)

# Calculate Standard Deviation
sd = np.std(data)

# Calculate Coefficient of Variation (C.V)
cv = (sd / abs(am)) * 100

# Display results
print("Arithmetic mean =", am)
print("Standard Deviation =", sd)
print("Coefficient of Variation (C.V) =", cv)


# ---------------- Formula used ----------------
# Arithmetic mean : x_bar = (sum of f*x) / N      (N = sum of f)
# Variance           : sigma^2 = (sum of f*x^2) / N - (x_bar)^2
# Standard deviation : sigma = sqrt(variance)
# Coefficient of variation : C.V. = (sigma / |x_bar|) * 100
