# Program Name: To find median for continuous frequency distribution (grouped data)

# find median for the data given below (continuous frequency distribution)
#
#  Class       Frequency
#
#  15-25          14
#  25-35          20
#  35-45          24
#  45-55          29
#  55-65          18
#  65-75          12
#  75-85          10
#  85-95           8

import numpy as np

L = np.array([15, 25, 35, 45, 55, 65, 75, 85])   # Lower limit
U = np.array([25, 35, 45, 55, 65, 75, 85, 95])   # Upper limit
F = np.array([14, 20, 24, 29, 18, 12, 10, 8])    # Frequency

N = np.sum(F)                    # Sum of frequency
LCF = np.cumsum(F)               # To find LCF

i = np.where(LCF >= N/2)[0][0]   # To find index of median class
# [0][0] is the first element of the array of indices which satisfy the condition LCF >= N/2

print("Median class index =", i)
print("Median class =", L[i], "-", U[i])

l = L[i]                         # Lower limit of median class
CF = LCF[i-1] if i > 0 else 0    # LCF of pre-median class
f1 = F[i]                        # Frequency of median class
h = U[i] - L[i]                  # Width of median class

Me = l + ((N/2 - CF) / f1) * h

print("Median =", Me)


# ---------------- Formula used ----------------
# Median class = class having LCF >= N/2
# Median : Me = L + ((N/2 - CF) / f) * h
# where,
#   L  = lower limit of median class
#   CF = LCF of the pre-median class (class just before the median class)
#   f  = frequency of median class
#   h  = width of median class
#   N  = total frequency (sum of f)
# Less than cumulative frequency : LCF_i = f_1 + f_2 + ... + f_i
# (here N = 135 , N/2 = 67.5 , median class = 45-55)
