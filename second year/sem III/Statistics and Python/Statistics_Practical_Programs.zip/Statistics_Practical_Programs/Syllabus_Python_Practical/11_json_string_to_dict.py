# Program Name: To demonstrate parsing JSON string to dict
import json

s = '{"name": "Rohu", "age": 19, "marks": [78, 85, 90], "passed": true, "address": null}'
d = json.loads(s)
print(d)
print(type(d))
print("Name =", d["name"], " Marks =", d["marks"])

# ---------------- Concept ----------------
# json.loads(string) -> dict
