# Program Name: To demonstrate functions of match object
import re

text = "Rohu scored 85 marks in Statistics"
m = re.search(r"(\w+) scored (\d+) marks", text)

print("Match object :", m)
print("group()      :", m.group())
print("group(1)     :", m.group(1))
print("group(2)     :", m.group(2))
print("groups()     :", m.groups())
print("start()      :", m.start())
print("end()        :", m.end())
print("span()       :", m.span())
print("string       :", m.string)
print("re           :", m.re)

m2 = re.search(r"(?P<name>\w+) scored (?P<marks>\d+)", text)
print("groupdict()  :", m2.groupdict())

# ---------------- Concept ----------------
# group() , groups() , start() , end() , span() , groupdict() are the functions of a match object
