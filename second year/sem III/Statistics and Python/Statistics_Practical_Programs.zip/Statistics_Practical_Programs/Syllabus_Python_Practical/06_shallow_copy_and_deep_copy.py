# Program Name: To demonstrate difference between shallow copy and deep copy
import copy

original = [[1, 2, 3], [4, 5, 6]]
shallow = copy.copy(original)
deep = copy.deepcopy(original)

original[0][0] = 100          # change in the inner list
original.append([7, 8, 9])    # change in the outer list

print("Original     :", original)
print("Shallow copy :", shallow, " (inner list is shared, so 100 appears)")
print("Deep copy    :", deep, " (completely independent)")
print("original[0] is shallow[0] ->", original[0] is shallow[0])
print("original[0] is deep[0]    ->", original[0] is deep[0])

# ---------------- Concept ----------------
# Shallow copy : new outer object, but inner objects are shared with the original
# Deep copy    : new outer object and copies of all inner objects
