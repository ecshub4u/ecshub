# Program Name: To demonstrate higher order functions
from functools import reduce

def apply(func, value):          # takes a function as argument
    return func(value)

def make_power(n):               # returns a function
    def power(x):
        return x ** n
    return power

cube = make_power(3)
print("apply(len, 'python') =", apply(len, "python"))
print("cube(4) =", cube(4))
nums = [1, 2, 3, 4, 5, 6]
print("map    :", list(map(lambda x: x * 10, nums)))
print("filter :", list(filter(lambda x: x > 3, nums)))
print("reduce :", reduce(lambda a, b: a * b, nums))

# ---------------- Concept ----------------
# A higher-order function takes a function as an argument or returns a function
