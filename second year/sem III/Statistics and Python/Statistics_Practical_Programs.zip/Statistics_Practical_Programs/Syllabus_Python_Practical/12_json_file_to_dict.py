# Program Name: To demonstrate parsing JSON file to dict
import json

# creating a sample file first
with open("data.json", "w") as f:
    json.dump({"city": "Solapur", "pincode": 413001, "places": ["Siddheshwar", "Bhuikot Fort"]}, f)

with open("data.json", "r") as f:
    d = json.load(f)
print(d)
print(type(d))
print("City =", d["city"])

# ---------------- Concept ----------------
# json.load(file) -> reads a JSON file and converts it into a dict
