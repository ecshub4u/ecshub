# Program Name: To demonstrate parsing dict to JSON file
import json

student = {"name": "Rohu", "age": 19, "marks": [78, 85, 90], "passed": True}
with open("student.json", "w") as f:
    json.dump(student, f, indent=4)
print("student.json file is created")
print(open("student.json").read())

# ---------------- Concept ----------------
# json.dump(dict, file) -> writes the dictionary into a JSON file
