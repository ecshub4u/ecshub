# Program Name: To demonstrate the use of *args and **kwargs

def total(*args):
    print("args =", args)
    return sum(args)

def details(**kwargs):
    for k, v in kwargs.items():
        print(k, "=", v)

def show(a, *args, **kwargs):
    print("a =", a, " args =", args, " kwargs =", kwargs)

print("Total =", total(1, 2, 3, 4))
details(name="Rohu", course="B.Sc. ECS", year=2)
show(10, 20, 30, city="Solapur", country="India")

# ---------------- Concept ----------------
# *args -> variable number of positional arguments (tuple) , **kwargs -> keyword arguments (dict)
