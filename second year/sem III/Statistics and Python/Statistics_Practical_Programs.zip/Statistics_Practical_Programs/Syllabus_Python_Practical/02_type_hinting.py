# Program Name: To demonstrate type hinting
from typing import List, Dict, Optional

def add(a: int, b: int) -> int:
    return a + b

def average(numbers: List[float]) -> float:
    return sum(numbers) / len(numbers)

def greet(name: str, age: Optional[int] = None) -> str:
    if age is None:
        return "Hello " + name
    return "Hello " + name + ", age " + str(age)

def count_words(words: List[str]) -> Dict[str, int]:
    d: Dict[str, int] = {}
    for w in words:
        d[w] = d.get(w, 0) + 1
    return d

print(add(5, 7))
print(average([10.5, 20.5, 30.0]))
print(greet("Rohu"), "|", greet("Rohu", 19))
print(count_words(["a", "b", "a", "c", "a"]))
print("Annotations of add :", add.__annotations__)

# ---------------- Concept ----------------
# Type hints (name: type -> return_type) show the expected types. Python does not enforce them at run time.
