# Program Name: To manage a sheet : freezing panes, filter, formulas, styles, images and bar chart
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, Reference
from openpyxl.drawing.image import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

wb = Workbook()
ws = wb.active
ws.title = "Sales"
ws.append(["Month", "Shop A", "Shop B"])
data = [["Jan", 120, 100], ["Feb", 150, 130], ["Mar", 170, 160], ["Apr", 140, 180], ["May", 200, 170]]
for row in data:
    ws.append(row)

# a) Freezing rows and columns
ws.freeze_panes = "B2"
print("a) Freeze panes =", ws.freeze_panes)

# b) Adding filter
ws.auto_filter.ref = "A1:C6"
print("b) Filter range =", ws.auto_filter.ref)

# c) Adding formulae
ws["A7"] = "Total"
ws["B7"] = "=SUM(B2:B6)"
ws["C7"] = "=SUM(C2:C6)"
ws["A8"] = "Average"
ws["B8"] = "=AVERAGE(B2:B6)"
ws["C8"] = "=AVERAGE(C2:C6)"
print("c) Formulae :", ws["B7"].value, ws["C7"].value, ws["B8"].value, ws["C8"].value)

# d) Adding styles
thin = Side(style="thin")
for cell in ws[1]:
    cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor="1F3A5F")
    cell.alignment = Alignment(horizontal="center")
for row in ws["A1:C8"]:
    for cell in row:
        cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
print("d) Header style added (bold, white font, blue fill, borders)")

# e) Adding image (a picture is created using matplotlib and inserted)
plt.figure(figsize=(3, 2))
plt.plot([1, 2, 3, 4, 5], [120, 150, 170, 140, 200])
plt.title("Shop A")
plt.savefig("sales_logo.png", dpi=70)
img = Image("sales_logo.png")
ws.add_image(img, "E2")
print("e) Image added at E2")

# f) Adding bar chart
chart = BarChart()
chart.title = "Monthly Sales"
chart.x_axis.title = "Month"
chart.y_axis.title = "Sales"
values = Reference(ws, min_col=2, min_row=1, max_col=3, max_row=6)
cats = Reference(ws, min_col=1, min_row=2, max_row=6)
chart.add_data(values, titles_from_data=True)
chart.set_categories(cats)
ws.add_chart(chart, "E16")
print("f) Bar chart added at E16")

wb.save("sheet_management.xlsx")
print("sheet_management.xlsx is saved")

# ---------------- Concept ----------------
# ws.freeze_panes , ws.auto_filter.ref , formula strings ("=SUM(B2:B6)") , Font / PatternFill / Border ,
# openpyxl.drawing.image.Image , openpyxl.chart.BarChart
