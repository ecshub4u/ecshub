# Program Name: To read CSV file to dict
import csv

# creating a sample csv file first
with open("students.csv", "w", newline="") as f:
    f.write("roll,name,marks\n1,Amit,70\n2,Sneha,82\n3,Rohit,55\n")

with open("students.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(dict(row))

# ---------------- Concept ----------------
# csv.DictReader(file) reads each row of a CSV file as a dictionary (header row gives the keys)
