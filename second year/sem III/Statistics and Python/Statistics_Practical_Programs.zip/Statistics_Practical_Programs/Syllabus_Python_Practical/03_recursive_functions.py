# Program Name: To demonstrate recursive functions

def factorial(n):
    if n == 0 or n == 1:        # base condition
        return 1
    return n * factorial(n - 1)

def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

def sum_digits(n):
    if n == 0:
        return 0
    return n % 10 + sum_digits(n // 10)

print("Factorial of 6 =", factorial(6))
print("Fibonacci series :", [fibonacci(i) for i in range(10)])
print("Sum of digits of 4528 =", sum_digits(4528))

# ---------------- Concept ----------------
# A recursive function calls itself. It must have a base condition to stop the calls.
