# Program Name: To demonstrate iterators and generators

# Iterator : uses iter() and next()
fruits = ["apple", "banana", "cherry"]
it = iter(fruits)
print(next(it))
print(next(it))
print(next(it))

# Class based iterator
class Counter:
    def __init__(self, limit):
        self.limit = limit
        self.n = 0
    def __iter__(self):
        return self
    def __next__(self):
        if self.n >= self.limit:
            raise StopIteration
        self.n += 1
        return self.n

print("Counter iterator :", [i for i in Counter(5)])

# Generator : uses yield
def even_numbers(limit):
    for i in range(0, limit + 1, 2):
        yield i

print("Generator :", list(even_numbers(12)))
gen = (x * x for x in range(1, 6))      # generator expression
print("Generator expression :", list(gen))

# ---------------- Concept ----------------
# Iterator : object with __iter__() and __next__() methods
# Generator : function using yield, it produces values one at a time (saves memory)
