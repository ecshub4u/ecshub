# Program Name: To create a simple spreadsheet and do add, update, insert row, delete row, insert column, delete column
from openpyxl import Workbook

def show(ws, msg):
    print(msg)
    for row in ws.iter_rows(values_only=True):
        print(row)
    print()

wb = Workbook()
ws = wb.active
ws.title = "Data"

# a) Adding cell values
ws["A1"] = "Roll"
ws["B1"] = "Name"
ws["C1"] = "Marks"
ws.append([1, "Amit", 70])
ws.append([2, "Sneha", 82])
ws.append([3, "Rohit", 55])
show(ws, "a) Adding cell values :")

# b) Updating cell values
ws["C2"] = 75
show(ws, "b) Updating cell values (C2 = 75) :")

# c) Insert row
ws.insert_rows(3)
ws["A3"], ws["B3"], ws["C3"] = 9, "Neha", 91
show(ws, "c) Insert row at 3 :")

# d) Delete row
ws.delete_rows(3)
show(ws, "d) Delete row 3 :")

# e) Insert column
ws.insert_cols(3)
ws["C1"] = "City"
show(ws, "e) Insert column at 3 :")

# f) Delete column
ws.delete_cols(3)
show(ws, "f) Delete column 3 :")

wb.save("operations.xlsx")
print("operations.xlsx is saved")

# ---------------- Concept ----------------
# ws["A1"] = value , ws.append() , ws.insert_rows() , ws.delete_rows() , ws.insert_cols() , ws.delete_cols()
