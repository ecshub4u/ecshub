# Program Name: To write CSV file from dict
import csv

students = [
    {"roll": 1, "name": "Amit", "marks": 70},
    {"roll": 2, "name": "Sneha", "marks": 82},
    {"roll": 3, "name": "Rohit", "marks": 55},
]
with open("students_out.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["roll", "name", "marks"])
    writer.writeheader()
    writer.writerows(students)
print("students_out.csv file is created")
print(open("students_out.csv").read())

# ---------------- Concept ----------------
# csv.DictWriter(file, fieldnames) , writeheader() , writerows(list of dict)
