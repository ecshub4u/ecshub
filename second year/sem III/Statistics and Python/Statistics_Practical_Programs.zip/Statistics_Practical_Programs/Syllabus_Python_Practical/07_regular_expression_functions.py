# Program Name: To demonstrate various functions of RegEx
import re

text = "Contact: rohu@example.com, amit@test.org on 12-10-2026 or 25-12-2026"

print("findall  :", re.findall(r"\w+@\w+\.\w+", text))
print("search   :", re.search(r"\d{2}-\d{2}-\d{4}", text).group())
print("match    :", re.match(r"Contact", text))
print("fullmatch:", re.fullmatch(r"\d+", "12345"))
print("sub      :", re.sub(r"\d{2}-\d{2}-\d{4}", "<date>", text))
print("split    :", re.split(r",\s*", "a, b,c,   d"))
print("finditer :", [m.span() for m in re.finditer(r"\d{4}", text)])
pattern = re.compile(r"[A-Z][a-z]+")
print("compile  :", pattern.findall("Hello World From Python"))

# ---------------- Concept ----------------
# findall, search, match, fullmatch, sub, split, finditer, compile are the main functions of the re module
