# Program Name: To demonstrate parsing dict to JSON string
import json

student = {"name": "Rohu", "age": 19, "marks": [78, 85, 90], "passed": True, "address": None}
s = json.dumps(student)
print(s)
print(type(s))
print(json.dumps(student, indent=4, sort_keys=True))

# ---------------- Concept ----------------
# json.dumps(dict) -> JSON string
