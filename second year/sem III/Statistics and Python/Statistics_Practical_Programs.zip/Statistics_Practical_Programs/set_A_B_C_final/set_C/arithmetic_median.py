# Set C - Q2
# Question: Write a Python program to calculate the Arithmetic Median for the following data.
#           X: 5, 10, 15, 20, 25
#           F: 4,  6,  8,  7,  5

import numpy as np

x = np.array([5, 10, 15, 20, 25])
f = np.array([4, 6, 8, 7, 5])

N = f.sum()                 # total frequency = 30
cf = np.cumsum(f)           # cumulative frequency = 4, 10, 18, 25, 30
half = N / 2                # N/2 = 15

# Median = first value of X whose cumulative frequency is >= N/2
median = x[cf >= half][0]

print("N =", N)
print("Cumulative frequency =", cf)
print("N/2 =", half)
print("Median =", median)    # 15

# ---------------- FORMULA USED (Viva) ----------------
# Median for a discrete frequency distribution:
#   Step 1: Find N = Sum(f)  and cumulative frequency (cf)
#   Step 2: Find N/2
#   Step 3: Median = the value of X whose cf is just greater than or equal to N/2
# Here: N = 30, N/2 = 15, first cf >= 15 is 18, so Median = 15
# (For raw data: if n is odd -> middle value = ((n+1)/2)th item;
#                if n is even -> average of (n/2)th and (n/2 + 1)th items)
# Functions used: np.cumsum(), boolean indexing
