# Set C - Q3
# Question: Write a Python program to fit a Quadratic Curve for the following data.
#           X: 1, 2,  3,  4,  5
#           Y: 5, 9, 15, 23, 33

import numpy as np

x = np.array([1, 2, 3, 4, 5])
y = np.array([5, 9, 15, 23, 33])

# Fit Y = a + bX + cX^2 by least squares (degree 2 polynomial)
c, b, a = np.polyfit(x, y, 2)      # polyfit returns highest power first

print("a =", round(a, 4))          # 3
print("b =", round(b, 4))          # 1
print("c =", round(c, 4))          # 1
print("Quadratic curve: Y = %.2f + %.2f X + %.2f X^2" % (a, b, c))   # Y = 3 + X + X^2

# ---------------- FORMULA USED (Viva) ----------------
# Quadratic (second degree parabola):  Y = a + bX + cX^2
# Method of Least Squares -> Normal equations:
#   Sum(Y)    = n*a      + b*Sum(X)   + c*Sum(X^2)
#   Sum(XY)   = a*Sum(X) + b*Sum(X^2) + c*Sum(X^3)
#   Sum(X^2Y) = a*Sum(X^2) + b*Sum(X^3) + c*Sum(X^4)
# Solving these 3 equations gives a, b, c.
# Here: a = 3, b = 1, c = 1  ->  Y = 3 + X + X^2
# Function used: np.polyfit(x, y, 2)
