# Set C - Q1
# Question: Develop a Python program to calculate coefficient of correlation from the
#           following data. Interpret your result.
#           X: 54, 58, 65, 72, 78, 81, 87
#           Y: 58, 63, 67, 77, 80, 83, 91

import numpy as np

X = np.array([54, 58, 65, 72, 78, 81, 87])
Y = np.array([58, 63, 67, 77, 80, 83, 91])

# Karl Pearson's coefficient of correlation
r = np.corrcoef(X, Y)[0, 1]
print("Correlation coefficient r = %.4f" % r)       # about 0.994

# Interpretation
if r > 0:
    kind = "positive"
elif r < 0:
    kind = "negative"
else:
    kind = "no"
if abs(r) >= 0.7:
    strength = "strong"
elif abs(r) >= 0.4:
    strength = "moderate"
else:
    strength = "weak"
print("Interpretation: There is a %s %s correlation between X and Y." % (strength, kind))
print("As X increases, Y also increases (almost perfectly linear relationship).")

# ---------------- FORMULA USED (Viva) ----------------
# Karl Pearson's Coefficient of Correlation:
#   r = Cov(X, Y) / (SD_x * SD_y)
#   r = [ n*SumXY - SumX*SumY ] / sqrt( [n*SumX^2 - (SumX)^2] * [n*SumY^2 - (SumY)^2] )
# Range: -1 <= r <= +1
#   r = +1 perfect positive, r = -1 perfect negative, r = 0 no linear correlation
# Function used: np.corrcoef()
