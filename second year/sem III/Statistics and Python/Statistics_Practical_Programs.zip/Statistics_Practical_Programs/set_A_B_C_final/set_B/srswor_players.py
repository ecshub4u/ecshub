# Set B - Q3
# Question: Write a Python program to select 4 players randomly from a team of 11 players
#           numbered from 1 to 11 using the SRSWOR method.

import numpy as np

team = np.arange(1, 12)        # players numbered 1 to 11  (12 is excluded)

selected = np.random.choice(team, size=4, replace=False)   # replace=False -> WITHOUT replacement
print("Team players     =", team)
print("Selected players =", selected)

# ---------------- FORMULA USED (Viva) ----------------
# SRSWOR = Simple Random Sampling Without Replacement
# Once a player is selected he is NOT put back, so no player is repeated.
# Total possible samples = N C n = 11 C 4 = 11! / (4! * 7!) = 330
# Probability of selecting any one sample = 1 / (N C n) = 1/330
# Probability of a particular player being selected = n / N = 4/11
# Functions used: np.arange(), np.random.choice(..., replace=False)
