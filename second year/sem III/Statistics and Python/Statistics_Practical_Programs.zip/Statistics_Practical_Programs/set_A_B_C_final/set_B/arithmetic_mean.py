# Set B - Q2
# Question: Write a Python program to calculate the Arithmetic Mean for the following observations:
#           X: 5, 10, 15, 20, 25, 30, 35

import numpy as np

X = np.array([5, 10, 15, 20, 25, 30, 35])

print("Arithmetic mean =", np.mean(X))      # 20.0

# ---------------- FORMULA USED (Viva) ----------------
# Arithmetic Mean (X bar) = (Sum of all observations) / (Number of observations)
#                         = Sum(X) / n
# Here: Sum(X) = 140, n = 7  ->  140 / 7 = 20
# Function used: np.mean() from NumPy library
