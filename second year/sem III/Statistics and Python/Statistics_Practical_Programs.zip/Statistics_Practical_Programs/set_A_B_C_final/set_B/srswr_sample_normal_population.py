# Set B - Q1
# Question: Write a Python program to select a random sample of size 40 from a normal
#           population of size 400 with mean 30 and standard deviation 6 by using the
#           simple random sample without replacement (SRSWR) method.

import numpy as np

N = 400          # population size
n = 40           # sample size
mu = 30          # population mean
sigma = 6        # population standard deviation

# Step 1: generate normal population of size 400
population = np.random.normal(mu, sigma, N)

# Step 2: draw sample of size 40 from it using SRS
sample = np.random.choice(population, size=n, replace=True)   # replace=True -> WITH replacement (SRSWR)
# NOTE: the paper writes "without replacement (SRSWR)". If your teacher wants WITHOUT
# replacement (SRSWOR), just change to replace=False.

print("Sample =", sample)
print("Sample size =", len(sample))
print("Sample mean =", sample.mean())
print("Sample SD   =", sample.std(ddof=1))

# ---------------- FORMULA USED (Viva) ----------------
# Normal distribution N(mu, sigma^2) with mu = 30, sigma = 6  -> np.random.normal(mu, sigma, N)
# SRSWR  : each unit has equal probability 1/N on every draw; unit is put back after selection.
#          Total possible samples = N^n = 400^40
# SRSWOR : unit is not put back.  Total possible samples = NCn = 400C40
# Probability of selecting a unit: SRSWR -> 1/N each draw ; SRSWOR -> n/N overall
# Sample mean = Sum(x) / n
# Functions used: np.random.normal(), np.random.choice()
