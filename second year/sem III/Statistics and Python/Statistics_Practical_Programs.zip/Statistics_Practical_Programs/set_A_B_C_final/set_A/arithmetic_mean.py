 # Set A - Q1
# Question: Write a Python program to calculate the Arithmetic Mean for the following data:
#           X: 12, 18, 24, 30, 36, 42

import numpy as np

X = [12, 18, 24, 30, 36, 42]

mean = np.mean(X)
print("Data =", X)
print("Arithmetic Mean =", mean)      # 27.0

# ---------------- FORMULA USED (Viva) ----------------
# Arithmetic Mean (X bar) = (Sum of all observations) / (Number of observations)
#                         = (X1 + X2 + ... + Xn) / n  =  sum(X) / n
# Here: sum(X) = 162, n = 6  ->  162 / 6 = 27
# Function used: np.mean() from NumPy library
