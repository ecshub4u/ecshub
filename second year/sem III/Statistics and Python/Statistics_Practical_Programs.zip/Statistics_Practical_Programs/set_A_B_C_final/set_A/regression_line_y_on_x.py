# Set A - Q2
# Question: Write a Python program to fit the regression line of Y on X for the following data.
#           X: 2, 4, 6, 8, 10
#           Y: 5, 8, 9, 12, 15

import numpy as np

x = np.array([2, 4, 6, 8, 10])
y = np.array([5, 8, 9, 12, 15])

x_bar = x.mean()
y_bar = y.mean()

# slope (regression coefficient of Y on X)
b = np.sum((x - x_bar) * (y - y_bar)) / np.sum((x - x_bar) ** 2)
# intercept
a = y_bar - b * x_bar

print("a (intercept) =", a)           # 2.6
print("b (slope)     =", b)           # 1.2
print("Regression line of Y on X:  Y = %.2f + %.2f X" % (a, b))   # Y = 2.6 + 1.2X

# ---------------- FORMULA USED (Viva) ----------------
# Regression line of Y on X :  Y = a + bX     (or  Y - Y_bar = b_yx (X - X_bar))
# Slope  b_yx = Sum[(X - X_bar)(Y - Y_bar)] / Sum[(X - X_bar)^2]
#             = (n*SumXY - SumX*SumY) / (n*SumX^2 - (SumX)^2)
# Intercept  a = Y_bar - b * X_bar
# Method used: Least Squares Method (minimises sum of squared errors)
# Here: X_bar = 6, Y_bar = 9.8, b = 48/40 = 1.2, a = 9.8 - 1.2*6 = 2.6
