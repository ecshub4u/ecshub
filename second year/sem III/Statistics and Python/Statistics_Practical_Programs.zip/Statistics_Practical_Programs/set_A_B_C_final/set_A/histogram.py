# Set A - Q3
# Question: Write a Python program to draw and display a histogram for the following data.
#           Class Interval (X): 0-10, 10-20, 20-30, 30-40, 40-50
#           Frequency (F)     : 10,   20,    35,    25,    15

import matplotlib.pyplot as plt

classes = [0, 10, 20, 30, 40, 50]         # class boundaries (bins)
midpoints = [5, 15, 25, 35, 45]           # mid value of each class
freq = [10, 20, 35, 25, 15]               # frequencies

# weights = frequency, so each bar height = class frequency
plt.hist(midpoints, bins=classes, weights=freq, edgecolor="black", color="skyblue")
plt.xlabel("Class Interval (X)")
plt.ylabel("Frequency (F)")
plt.title("Histogram")
# plt.xticks(classes)
plt.show()

# ---------------- FORMULA / CONCEPT USED (Viva) ----------------
# Histogram = graph of a continuous (grouped) frequency distribution.
# X-axis -> class intervals, Y-axis -> frequencies; bars are drawn adjacent (no gap)
# Height of each bar (equal class width) is proportional to the class frequency.
# Class width = Upper limit - Lower limit = 10 ; Mid value = (Lower + Upper) / 2
# Function used: plt.hist() from matplotlib.pyplot
