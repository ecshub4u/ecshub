# Extra (Set D) - Q2
# Question: Calculate Mean, Variance, SD and CV for the data: 10, 20, 30, 40, 50, 60

import numpy as np

X = np.array([10, 20, 30, 40, 50, 60])

print("Mean     =", X.mean())                 # 35.0
print("Variance =", X.var())                  # 291.67
print("SD       =", X.std())                  # 17.08
print("CV       =", X.std() / X.mean() * 100) # 48.8 %

# ---------------- FORMULA USED (Viva) ----------------
# Mean     = Sum(X) / n
# Variance = Sum(X - X_bar)^2 / n          (population variance, np.var default)
# SD       = sqrt(Variance)
# CV (Coefficient of Variation) = (SD / Mean) * 100  %
# Functions used: np.mean(), np.var(), np.std()
