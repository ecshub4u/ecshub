# Program Name: Python function to calculate and classify correlation (positive, negative and zero)
# (as per Assignment_05 : Karl Pearson correlation coefficient and scatter diagram for r = -1, 0, 1)

import numpy as np

def classify(x, y):
    r = np.corrcoef(x, y)[0, 1]
    if r < 0:
        print("r =", r, ": There is negative correlation between x & y")
    elif r > 0:
        print("r =", r, ": There is positive correlation between x & y")
    else:
        print("r =", r, ": There is zero correlation between x & y")

# r = 1 (perfect positive correlation)
x1 = np.array([-2, -1, 0, 1, 2])
y1 = np.array([-2, -1, 0, 1, 2])
# r = 0 (zero correlation)
x2 = np.array([-2, -1, 0, 1, 2])
y2 = np.array([1, 0, -1, 0, 1])
# r = -1 (perfect negative correlation)
x3 = np.array([-2, -1, 0, 1, 2])
y3 = np.array([2, 1, 0, -1, -2])

classify(x1, y1)
classify(x2, y2)
classify(x3, y3)


# ---------------- Formula used ----------------
# Karl Pearson's correlation coefficient : r = Cov(x, y) / (sigma_x * sigma_y)
# r > 0 : positive correlation , r < 0 : negative correlation , r = 0 : zero correlation (-1 <= r <= 1)
