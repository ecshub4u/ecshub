# Program Name: Simple linear regression model to predict student scores from study hours
# (as per Assignment_05 : fit line of regression y on x and scatter diagram)

# Study hours (x) : 1, 2, 3, 4, 5, 6, 7, 8, 9
# Score (y)       : 35, 41, 49, 54, 61, 66, 74, 79, 88

import numpy as np
import matplotlib.pyplot as plt

x = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9]) # independent variable (study hours)
y = np.array([35, 41, 49, 54, 61, 66, 74, 79, 88]) # dependent variable (score)

coeff = np.polyfit(x, y, 1)
b, a = np.round(coeff, 2)

print("b =", b, "a =", a)
print("Regression model :")
print("Score =", a, "+", b, "* Hours")

x1 = 7.5   # known value of x   (x1 = float(input("Enter study hours: ")))
estimate_y = a+b*x1
print("Predicted score for", x1, "study hours is", estimate_y)

plt.scatter(x, y, color="red", s=100, marker="*")
plt.plot(x, a + b*x, color="blue")
plt.title("Study hours and score")
plt.xlabel("Study hours")
plt.ylabel("Score")
plt.show()


# ---------------- Formula used ----------------
# Line of regression y on x : y = a + b*x
# Regression coefficient : b = (n*sum(xy) - sum(x)*sum(y)) / (n*sum(x^2) - (sum(x))^2)
# Constant               : a = y_bar - b*x_bar
