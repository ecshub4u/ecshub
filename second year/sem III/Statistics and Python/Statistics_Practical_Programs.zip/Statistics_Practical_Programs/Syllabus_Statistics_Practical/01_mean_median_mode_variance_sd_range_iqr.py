# Program Name: To calculate mean, median, mode, variance, standard deviation, range and IQR
# (as per Assignment_04 : measures of central tendency and dispersion for raw data)

# data = 12, 15, 11, 18, 15, 20, 22, 15, 17, 25

import numpy as np
from scipy import stats

data = np.array([12, 15, 11, 18, 15, 20, 22, 15, 17, 25])

am=np.mean(data)
print(" Arithmetic mean =",am)

Me=np.median(data)
print("Median =",Me)

Mo=stats.mode(data)
print("Mode =",Mo.mode ,"freq of model value=",Mo.count)

var=np.var(data)
print("Variance =", var)

sd=np.std(data)
print("Standard Deviation =", sd)

l=np.max(data)
s=np.min(data)
R=(l-s)
print("Range=",R)

Q1=np.percentile(data,25)
print("Q1=",Q1)

Q3=np.percentile(data,75)
print("Q3=",Q3)

IQR=Q3-Q1
print("Inter Quartile Range (IQR) =",IQR)


# ---------------- Formula used ----------------
# Arithmetic mean : x_bar = (sum of x) / n          Median : middle value of ordered data
# Mode            : most frequent value             Variance : sigma^2 = (sum of x^2) / n - (x_bar)^2
# S.D.            : sigma = sqrt(variance)          Range : R = L - S
# IQR             : Q3 - Q1
