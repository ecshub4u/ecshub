# Program Name: To verify the assumptions of correlation coefficient (linearity and non-linearity)
# (as per Assignment_05 : Karl Pearson correlation coefficient and scatter diagram)

import numpy as np
import matplotlib.pyplot as plt

# Linear relationship : y = 3x + 2
x1 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
y1 = 3 * x1 + 2

# Non-linear relationship : y = x^2
x2 = np.array([-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5])
y2 = x2 ** 2

# Linear relationship with an outlier
x3 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
y3 = np.array([2, 4, 5, 4, 5, 7, 8, 9, 40])

r1 = np.corrcoef(x1, y1)[0, 1]
r2 = np.corrcoef(x2, y2)[0, 1]
r3 = np.corrcoef(x3, y3)[0, 1]
print("Linear data         : r =", r1, "-> relation is linear, r is suitable")
print("Non-linear data     : r =", r2, "-> relation is non-linear, r is not suitable")
print("Data with outlier   : r =", r3, "-> r is affected by the extreme value")

fig, axes = plt.subplots(1, 3, figsize=(15, 5))

axes[0].scatter(x1, y1, color='red')
axes[0].set_title("Linear : r = 1")
axes[0].set_xlabel("X")
axes[0].set_ylabel("Y")

axes[1].scatter(x2, y2, color='blue')
axes[1].set_title("Non-linear : r = 0")
axes[1].set_xlabel("X")
axes[1].set_ylabel("Y")

axes[2].scatter(x3, y3, color='green')
axes[2].set_title("With outlier")
axes[2].set_xlabel("X")
axes[2].set_ylabel("Y")

plt.tight_layout()
plt.show()


# ---------------- Formula used ----------------
# Karl Pearson's correlation coefficient : r = Cov(x, y) / (sigma_x * sigma_y)
# Assumption : relationship between x and y is linear and there are no extreme values
# r measures only linear relationship. r = 0 does not mean x and y are unrelated (e.g. y = x^2).
