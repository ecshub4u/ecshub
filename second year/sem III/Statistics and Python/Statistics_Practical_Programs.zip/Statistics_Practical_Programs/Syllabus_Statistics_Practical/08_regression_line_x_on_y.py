# Program Name: Fitting a line of regression x on y (x = a + by) and estimating x
# (as per Assignment_05 : fit line of regression ; x and y are interchanged)

# x: 30, 34, 25, 29, 52, 44, 47, 38
# y: 46, 49, 42, 45, 63, 57, 59, 52

import numpy as np

x = np.array([30, 34, 25, 29, 52, 44, 47, 38]) # dependent variable
y = np.array([46, 49, 42, 45, 63, 57, 59, 52]) # independent variable

coeff = np.polyfit(y, x, 1)
b, a = np.round(coeff, 2)

print("b =", b, "a =", a)
print("Equation of line of regression x on y:")
print("x =", a, "+", b, "y")

y1 = 60   # known value of y   (y1 = float(input("Enter known value of y: ")))
estimate_x = a+b*y1
# estimate_x = np.polyval(coeff, y1)

print("Estimated value of x for y =", y1, "is", estimate_x)


# ---------------- Formula used ----------------
# Line of regression x on y : x = a + b*y
# Normal equations :
#   sum(x)   = n*a + b*sum(y)
#   sum(x*y) = a*sum(y) + b*sum(y^2)
# Regression coefficient : b = (n*sum(xy) - sum(x)*sum(y)) / (n*sum(y^2) - (sum(y))^2)
# Constant               : a = x_bar - b*y_bar
