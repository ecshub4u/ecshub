# Program Name: To visualize data using histogram and scatter plot
# (as per Assignment_03 : histogram using plt.hist and Assignment_05 : scatter diagram)

import matplotlib.pyplot as plt

# Histogram
marks = [35, 42, 45, 48, 50, 52, 55, 55, 58, 60, 62, 65, 65, 68, 70, 72, 75, 78, 82, 90]
plt.hist(marks,bins=[30,40,50,60,70,80,90,100],color="red",edgecolor="black")
plt.title("histogram")
plt.xlabel("marks")
plt.ylabel("freq")
plt.show()

# Scatter plot
x = [1, 2, 3, 4, 5, 6, 7, 8]
y = [35, 42, 50, 55, 62, 70, 78, 85]
plt.scatter(x, y, color="red", s=100, marker="*")
plt.title("Scatter Diagram")
plt.xlabel("X - Coordinates")
plt.ylabel("Y - Coordinates")
plt.show()

# correlation: The scatter diagram shows a positive correlation between X and Y.


# ---------------- Formula used ----------------
# Histogram : bars of height = frequency, no gap between bars (continuous data)
# Scatter diagram : plots pairs (x, y) as points, shows the type of correlation
