# Program Name: Python functions to compute range, variance, S.D. and C.V. for ungrouped and grouped data
# (logic as per Assignment_04 : raw data, continuous frequency distribution and C.V. programs)

import numpy as np

# Range for ungrouped data
def range_ungrouped(data):
    l=np.max(data)
    s=np.min(data)
    return (l-s), (l-s)/(l+s)

# Variance and S.D. for ungrouped data
def var_sd_ungrouped(data):
    return np.var(data), np.std(data)

# Range for grouped data
def range_grouped(L, U):
    l=np.max(U)
    s=np.min(L)
    return (l-s), (l-s)/(l+s)

# Variance and S.D. for grouped data
def var_sd_grouped(L, U, f):
    N=np.sum(f)
    M = (L + U)/2
    S1=np.sum(f*M)
    S2=np.sum(f*M*M)
    mean = S1/N
    var = S2/N - (mean * mean)
    sd = np.sqrt(var)
    return mean, var, sd

# Coefficient of variation
def cv(sd, mean):
    return sd/abs(mean) * 100

# ungrouped data
data1 = np.array([10, 20, 30, 40, 50])
data2 = np.array([28, 30, 32, 29, 31])
print("Range and Coefficient of range (data1) =", range_ungrouped(data1))
var1, sd1 = var_sd_ungrouped(data1)
var2, sd2 = var_sd_ungrouped(data2)
print("data1 : variance =", var1, "S.D. =", sd1, "C.V. =", cv(sd1, np.mean(data1)))
print("data2 : variance =", var2, "S.D. =", sd2, "C.V. =", cv(sd2, np.mean(data2)))
if cv(sd1, np.mean(data1)) < cv(sd2, np.mean(data2)):
    print("data1 is more consistent")
else:
    print("data2 is more consistent")

# grouped data
L = np.array([15, 20, 25, 30, 35, 40, 45, 50, 55])
U = np.array([20, 25, 30, 35, 40, 45, 50, 55, 60])
f = np.array([5, 9, 11, 17, 14, 10, 7, 5, 3])
print("Range and Coefficient of range (grouped) =", range_grouped(L, U))
mean, var, sd = var_sd_grouped(L, U, f)
print("Grouped data : mean =", mean, "variance =", var, "S.D. =", sd, "C.V. =", cv(sd, mean))


# ---------------- Formula used ----------------
# Range : R = L - S , Coefficient of range = (L - S) / (L + S)   (grouped : L = upper limit of last class, S = lower limit of first class)
# Variance (ungrouped) : sigma^2 = (sum of x^2) / n - (x_bar)^2   Variance (grouped) : sigma^2 = (sum of f*M^2) / N - (mean)^2
# S.D. : sigma = sqrt(variance)        C.V. = (sigma / |mean|) * 100
