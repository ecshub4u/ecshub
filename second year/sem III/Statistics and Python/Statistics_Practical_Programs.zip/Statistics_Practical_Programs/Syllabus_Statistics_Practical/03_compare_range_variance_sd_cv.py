# Program Name: To compute and compare range, variance, S.D. and C.V. of two datasets
# (as per Assignment_04 : measures of dispersion for raw data and coefficient of variation)

# Daily sales (in thousands) of two shops
# Shop A : 45, 50, 52, 48, 55, 60, 47
# Shop B : 30, 70, 20, 80, 45, 90, 25

import numpy as np

data1 = np.array([45, 50, 52, 48, 55, 60, 47])
data2 = np.array([30, 70, 20, 80, 45, 90, 25])

# Shop A
am1=np.mean(data1)
R1=np.max(data1)-np.min(data1)
var1=np.var(data1)
sd1=np.std(data1)
cv1=sd1/abs(am1)*100
print("Shop A : Mean =",am1,"Range =",R1,"Variance =",var1,"S.D. =",sd1,"C.V. =",cv1)

# Shop B
am2=np.mean(data2)
R2=np.max(data2)-np.min(data2)
var2=np.var(data2)
sd2=np.std(data2)
cv2=sd2/abs(am2)*100
print("Shop B : Mean =",am2,"Range =",R2,"Variance =",var2,"S.D. =",sd2,"C.V. =",cv2)

if cv1 < cv2:
    print("C.V. of Shop A is less, so sales of Shop A are more consistent")
else:
    print("C.V. of Shop B is less, so sales of Shop B are more consistent")


# ---------------- Formula used ----------------
# Range : R = L - S                 Variance : sigma^2 = (sum of x^2) / n - (x_bar)^2
# S.D. : sigma = sqrt(variance)     C.V. = (sigma / |x_bar|) * 100
# Data set having smaller C.V. is more consistent (less variable)
