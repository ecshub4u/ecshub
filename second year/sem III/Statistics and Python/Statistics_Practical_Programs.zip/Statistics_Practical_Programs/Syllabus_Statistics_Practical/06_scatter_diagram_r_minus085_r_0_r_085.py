# Program Name: To plot scatter diagram where r = -0.85, r = 0 and r = 0.85
# (as per Assignment_05 : scatter diagram for r = -1, r = 0 and r = 1)

import numpy as np
import matplotlib.pyplot as plt

# r = 0.85 (high positive correlation)
x1 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
y1 = np.array([3, 1, 7, 14, 2, 20, 10, 26, 21, 29])

# r = 0 (zero correlation)
x2 = np.array([-2, -1, 0, 1, 2])
y2 = np.array([1, 0, -1, 0, 1])

# r = -0.85 (high negative correlation)
x3 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
y3 = np.array([27, 29, 23, 16, 28, 10, 20, 4, 9, 1])

print("r (first graph)  =", np.corrcoef(x1, y1)[0, 1])
print("r (second graph) =", np.corrcoef(x2, y2)[0, 1])
print("r (third graph)  =", np.corrcoef(x3, y3)[0, 1])

fig, axes = plt.subplots(1, 3, figsize=(15, 5))

axes[0].scatter(x1, y1, color='red')
axes[0].set_title("r = 0.85")
axes[0].set_xlabel("X")
axes[0].set_ylabel("Y")

axes[1].scatter(x2, y2, color='blue')
axes[1].set_title("r = 0")
axes[1].set_xlabel("X")
axes[1].set_ylabel("Y")

axes[2].scatter(x3, y3, color='green')
axes[2].set_title("r = -0.85")
axes[2].set_xlabel("X")
axes[2].set_ylabel("Y")

plt.tight_layout()
plt.show()


# ---------------- Formula used ----------------
# Karl Pearson's correlation coefficient : r = Cov(x, y) / (sigma_x * sigma_y)
# r = 0.85  : points rise from left to right but are scattered (strong positive correlation)
# r = -0.85 : points fall from left to right but are scattered (strong negative correlation)
# r = 0     : no linear relationship between x and y (no correlation)
