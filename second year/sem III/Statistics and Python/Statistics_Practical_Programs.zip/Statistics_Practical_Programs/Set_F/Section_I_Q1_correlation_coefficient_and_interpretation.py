# Program Name: To find correlation coefficient and interpret the result
# (as per Assignment_05 : Karl Pearson correlation coefficient)

# Set F Q1) Develop a Python program to calculate the coefficient of correlation from the following data.
# Interpret your result.
# X: 54, 58, 65, 72, 78, 81, 87
# Y: 58, 63, 67, 77, 80, 83, 91

import numpy as np

x = [54, 58, 65, 72, 78, 81, 87]
y = [58, 63, 67, 77, 80, 83, 91]
r = np.corrcoef(x, y)[0, 1]
print("Correlation coefficient =", r)

if r < 0:
    print("There is negative correlation between x & y")
else:
    print("There is positive correlation between x & y")


# ---------------- Formula used ----------------
# Karl Pearson's correlation coefficient :
#   r = Cov(x, y) / (sigma_x * sigma_y)
#   r = (n*sum(xy) - sum(x)*sum(y)) / ( sqrt(n*sum(x^2) - (sum(x))^2) * sqrt(n*sum(y^2) - (sum(y))^2) )
# Value of r lies between -1 and +1
# Interpretation : r is close to +1, so x and y have a very strong positive correlation
