# Program Name: To create a simple spreadsheet and add / update cell values

# Set F Section-II Q2) Write a program to create a simple spreadsheet and do the following operations:
# a) Adding cell values  b) Updating cell values

from openpyxl import Workbook, load_workbook

wb = Workbook()
ws = wb.active
ws.title = "Items"

# a) Adding cell values
ws["A1"] = "Item"
ws["B1"] = "Price"
ws["C1"] = "Quantity"
ws["A2"] = "Pen"
ws["B2"] = 10
ws["C2"] = 5
ws["A3"] = "Notebook"
ws["B3"] = 45
ws["C3"] = 3
ws.append(["Pencil", 5, 10])      # add a new row at the end
print("After adding values :")
for row in ws.iter_rows(values_only=True):
    print(row)

# a) Adding cell values (price * quantity)
ws["D1"] = "Amount"
for r in range(2, 5):
    ws["D" + str(r)] = ws["B" + str(r)].value * ws["C" + str(r)].value
print("Amount column :", ws["D2"].value, ws["D3"].value, ws["D4"].value)

# b) Updating cell values
ws["B3"] = 50                      # price of notebook is changed from 45 to 50
ws["D3"] = ws["B3"].value * ws["C3"].value
ws["A4"] = "Pencil (HB)"
print("After updating values :")
for row in ws.iter_rows(values_only=True):
    print(row)

wb.save("simple_spreadsheet_setF.xlsx")
print("File saved : simple_spreadsheet_setF.xlsx")
wb2 = load_workbook("simple_spreadsheet_setF.xlsx")
print("B3 after reopening =", wb2["Items"]["B3"].value)


# ---------------- Concept ----------------
# openpyxl is used to read / write Excel (.xlsx) files
# ws["A1"] = value adds / updates a cell value , ws.append(list) adds a row at the end
# wb.save("file.xlsx") saves the file , load_workbook("file.xlsx") opens an existing file
