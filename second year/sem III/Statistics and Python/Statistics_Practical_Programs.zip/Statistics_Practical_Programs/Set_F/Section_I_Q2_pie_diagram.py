# Program Name: To draw Pie chart (Pie diagram)
# (as per Assignment_03 : to draw pie chart)

# Set F Q2) The following data shows the % cost of different items in the construction of a house.
# Draw a pie diagram to represent it.
# Item     Steel  Sand  Bricks  Cement  Timber  Labor
# % cost    16     20     12      14      10     28

import matplotlib.pyplot as plt
cost=[16,20,12,14,10,28]
explode = [0, 0, 0, 0, 0, 0.1]
items=["Steel","Sand","Bricks","Cement","Timber","Labor"]
plt.pie(cost,labels=items,autopct="%1.2f%%", explode=explode)
plt.title("Pie chart showing % cost of construction of a house")
plt.show()


# ---------------- Formula used ----------------
# Total = sum of all component values
# Angle of a sector = (value of the component / total) * 360 degrees
# Percentage of a component = (value of the component / total) * 100
