# Program Name: To create a list of all odd numbers between 1 and 30 using list comprehension

# Set F Section-II Q1) Write a Python program to create a list of all odd numbers between 1 and 30
# using list comprehension.

odd_numbers = [x for x in range(1, 31) if x % 2 != 0]
print("Odd numbers between 1 and 30 :", odd_numbers)
print("Total odd numbers =", len(odd_numbers))

# Another way
odd2 = [x for x in range(1, 31, 2)]
print("Using step 2 :", odd2)


# ---------------- Concept ----------------
# [expression for item in iterable if condition]
# A number is odd if (number % 2) is not equal to 0
