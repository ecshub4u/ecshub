# Program Name: Population and Sample Statistics
import random
import statistics

population = [12, 15, 18, 20, 22, 25, 28, 30, 32, 35]
sample = random.sample(population, 5)

print("Population:", population)
print("Sample:", sample)
print("\nPopulation parameters:")
print("Mean:", statistics.mean(population))
print("Median:", statistics.median(population))
print("Variance:", statistics.pvariance(population))
print("\nSample statistics:")
print("Mean:", statistics.mean(sample))
print("Median:", statistics.median(sample))
print("Sample variance:", statistics.variance(sample))
try:
    print("Mode:", statistics.mode(sample))
except statistics.StatisticsError:
    print("Mode: no unique mode")

# Formulae used:
# Population mean: μ = Σx / N
# Sample mean: x̄ = Σx / n
# Population variance: σ² = Σ(x − μ)² / N
# Sample variance: s² = Σ(x − x̄)² / (n − 1)
# Median: middle value after sorting (or mean of two middle values).
