# Program Name: Simple Linear Regression Analysis
import statistics

x = [1, 2, 3, 4, 5, 6]
y = [2, 4, 5, 4, 5, 7]

mean_x = statistics.mean(x)
mean_y = statistics.mean(y)
numerator = sum((a - mean_x) * (b - mean_y) for a, b in zip(x, y))
denominator = sum((a - mean_x) ** 2 for a in x)
slope = numerator / denominator
intercept = mean_y - slope * mean_x
predicted = [intercept + slope * value for value in x]
ss_res = sum((actual - estimate) ** 2 for actual, estimate in zip(y, predicted))
ss_tot = sum((actual - mean_y) ** 2 for actual in y)
r_squared = 1 - ss_res / ss_tot if ss_tot else float("nan")

print("X:", x)
print("Y:", y)
print(f"Regression equation: y = {intercept:.3f} + {slope:.3f}x")
print("Predicted Y values:", [round(value, 3) for value in predicted])
print(f"Coefficient of determination (R²): {r_squared:.3f}")
print("Interpretation: the slope estimates the change in Y for each one-unit increase in X.")

# Formulae used:
# Regression line: ŷ = a + bx.
# Slope: b = Σ[(x − x̄)(y − ȳ)] / Σ(x − x̄)².
# Intercept: a = ȳ − b x̄.
# R² = 1 − (Σ(y − ŷ)² / Σ(y − ȳ)²).
