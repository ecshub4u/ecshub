# Program Name: Simulation of Different Sampling Methods
import random
import statistics

population = list(range(1, 101))
sample_size = 10
random.seed(10)

simple_random = random.sample(population, sample_size)
systematic_step = len(population) // sample_size
start = random.randrange(systematic_step)
systematic = population[start::systematic_step][:sample_size]
strata = [population[i:i + 20] for i in range(0, len(population), 20)]
stratified = [random.choice(group) for group in strata]
clusters = [population[i:i + 10] for i in range(0, len(population), 10)]
cluster = random.choice(clusters)

def report(name, sample):
    print(f"{name}: {sample}")
    print(f"  Sample mean = {statistics.mean(sample):.2f}")
    print(f"  Population mean difference = {abs(statistics.mean(sample) - statistics.mean(population)):.2f}")

print("Population mean:", statistics.mean(population))
report("Simple random sample", simple_random)
report("Systematic sample", systematic)
report("Stratified sample (one from each stratum)", stratified)
report("Cluster sample (one cluster)", cluster)

# Formulae used:
# Sample mean: x̄ = Σx / n
# Absolute estimation error: |x̄ − μ|
# Sampling fraction: n / N
