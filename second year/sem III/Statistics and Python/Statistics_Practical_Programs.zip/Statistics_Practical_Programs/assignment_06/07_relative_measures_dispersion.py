# Program Name: Coefficient of Range and Coefficient of Variation
import statistics

datasets = {
    "Original data": [10, 20, 30, 40, 50],
    "Scale changed (multiply by 10)": [100, 200, 300, 400, 500],
    "Origin changed (add 100)": [110, 120, 130, 140, 150],
}

def coefficient_of_range(data):
    largest, smallest = max(data), min(data)
    return (largest - smallest) / (largest + smallest)

def coefficient_of_variation(data):
    mean = statistics.mean(data)
    sd = statistics.pstdev(data)
    return (sd / abs(mean)) * 100 if mean != 0 else float("nan")

for name, data in datasets.items():
    print(f"\n{name}: {data}")
    print("Coefficient of range:", round(coefficient_of_range(data), 4))
    print("Coefficient of variation (%):", round(coefficient_of_variation(data), 2))

print("\nInterpretation:")
print("Multiplying all observations by a positive constant leaves both coefficients unchanged.")
print("Adding a constant generally changes both coefficients because the mean and extremes change.")

# Formulae used:
# Coefficient of Range = (L − S) / (L + S), where L=max and S=min.
# Coefficient of Variation (CV) = (Population SD / |Mean|) × 100%.
# Population SD = √[Σ(x − μ)² / N].
