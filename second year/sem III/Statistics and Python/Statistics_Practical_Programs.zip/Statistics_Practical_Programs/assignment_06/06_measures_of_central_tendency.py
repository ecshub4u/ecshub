# Program Name: Arithmetic Mean, Median and Mode
from collections import Counter
import statistics

data = [10, 12, 12, 14, 15, 15, 15, 18, 20]
print("Ungrouped data:", data)
print("Arithmetic mean:", statistics.mean(data))
print("Median:", statistics.median(data))
freq = Counter(data)
max_frequency = max(freq.values())
modes = sorted(value for value, count in freq.items() if count == max_frequency)
print("Mode(s):", modes)

# Grouped data example: class midpoint and frequency
midpoints = [5, 15, 25, 35, 45]
frequencies = [3, 7, 12, 8, 5]
N = sum(frequencies)
grouped_mean = sum(m * f for m, f in zip(midpoints, frequencies)) / N
print("\nGrouped midpoints:", midpoints)
print("Grouped frequencies:", frequencies)
print("Grouped arithmetic mean:", grouped_mean)

# Approximate grouped median and mode using class intervals
classes = [(0, 10), (10, 20), (20, 30), (30, 40), (40, 50)]
cf = []
running = 0
for f in frequencies:
    running += f
    cf.append(running)
median_index = next(i for i, value in enumerate(cf) if value >= N / 2)
L = classes[median_index][0]
CF_before = cf[median_index - 1] if median_index > 0 else 0
f_med = frequencies[median_index]
h = classes[median_index][1] - classes[median_index][0]
grouped_median = L + ((N / 2 - CF_before) / f_med) * h
modal_index = frequencies.index(max(frequencies))
L_mode = classes[modal_index][0]
f1 = frequencies[modal_index]
f0 = frequencies[modal_index - 1] if modal_index > 0 else 0
f2 = frequencies[modal_index + 1] if modal_index + 1 < len(frequencies) else 0
denominator = 2 * f1 - f0 - f2
grouped_mode = L_mode + ((f1 - f0) / denominator) * h if denominator else float("nan")
print("Grouped median (formula):", grouped_median)
print("Grouped mode (formula):", grouped_mode)

# Formulae used:
# Ungrouped mean: x̄ = Σx / n.
# Grouped mean: x̄ = Σ(fm) / Σf, where m is the class midpoint.
# Grouped median: Median = L + [(N/2 − CF) / f] × h.
# Grouped mode: Mode = L + [(f₁ − f₀) / (2f₁ − f₀ − f₂)] × h.
