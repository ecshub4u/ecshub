# Program Name: Data Condensation and Frequency Distributions
from collections import Counter
import math

data = [12, 15, 12, 18, 20, 15, 22, 18, 18, 25, 27, 20, 22, 30, 15]
counts = Counter(data)
print("Raw data:", data)
print("\nUngrouped frequency distribution:")
print("Value\tFrequency\tCumulative frequency")
cumulative = 0
for value in sorted(counts):
    cumulative += counts[value]
    print(f"{value}\t{counts[value]}\t\t{cumulative}")

minimum, maximum = min(data), max(data)
number_of_classes = 4
width = math.ceil((maximum - minimum + 1) / number_of_classes)
classes = []
start = minimum
while start <= maximum:
    end = start + width - 1
    freq = sum(start <= x <= end for x in data)
    classes.append((start, end, freq))
    start = end + 1

print("\nGrouped frequency distribution:")
print("Class interval\tFrequency\tCumulative frequency")
cumulative = 0
for lo, hi, freq in classes:
    cumulative += freq
    print(f"{lo}-{hi}\t\t{freq}\t\t{cumulative}")

# Formulae used:
# Frequency fᵢ = number of observations in a value/class.
# Cumulative frequency CFᵢ = f₁ + f₂ + ... + fᵢ.
# Class midpoint m = (lower limit + upper limit) / 2.
