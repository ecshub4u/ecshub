# Program Name: Frequency Distribution, Histogram and Ogive
import matplotlib.pyplot as plt

data = [12, 15, 12, 18, 20, 15, 22, 18, 18, 25, 27, 20, 22, 30, 15]
bins = [10, 15, 20, 25, 30, 35]
frequencies = []
for left, right in zip(bins[:-1], bins[1:]):
    frequencies.append(sum(left <= x < right for x in data))
cumulative = []
running = 0
for f in frequencies:
    running += f
    cumulative.append(running)

print("Class intervals:", list(zip(bins[:-1], bins[1:])))
print("Frequencies:", frequencies)
print("Cumulative frequencies:", cumulative)

fig, axes = plt.subplots(1, 2, figsize=(11, 4))
axes[0].hist(data, bins=bins, edgecolor="black")
axes[0].set_title("Histogram")
axes[0].set_xlabel("Class interval")
axes[0].set_ylabel("Frequency")
axes[1].plot(bins[1:], cumulative, marker="o")
axes[1].set_title("Less-than Ogive")
axes[1].set_xlabel("Upper class boundary")
axes[1].set_ylabel("Cumulative frequency")
axes[1].grid(True)
plt.tight_layout()
plt.show()

# Formulae used:
# Class frequency = count of observations in the class interval.
# Cumulative frequency CFᵢ = Σⱼ₌₁ⁱ fⱼ.
# Histogram: class intervals on x-axis, frequencies on y-axis.
# Less-than ogive: upper class boundaries plotted against cumulative frequencies.
