# Program Name: Numerical Data Condensation and Histogram
import matplotlib.pyplot as plt
from collections import Counter

marks = [34, 45, 56, 67, 45, 78, 89, 56, 67, 72, 45, 81, 90, 56, 63, 74, 68, 52, 47, 85]
classes = [(30, 39), (40, 49), (50, 59), (60, 69), (70, 79), (80, 89), (90, 99)]
frequencies = [sum(lo <= mark <= hi for mark in marks) for lo, hi in classes]
cumulative = []
total = 0
for frequency in frequencies:
    total += frequency
    cumulative.append(total)

print("Marks:", marks)
print("Class\tFrequency\tCumulative frequency")
for (lo, hi), frequency, cf in zip(classes, frequencies, cumulative):
    print(f"{lo}-{hi}\t{frequency}\t\t{cf}")

plt.hist(marks, bins=[29.5, 39.5, 49.5, 59.5, 69.5, 79.5, 89.5, 99.5], edgecolor="black")
plt.title("Histogram of Marks")
plt.xlabel("Marks")
plt.ylabel("Frequency")
plt.show()

# Formulae used:
# Frequency = number of observations within a class interval.
# Cumulative frequency = running sum of frequencies.
# Relative frequency = f / N; percentage frequency = (f / N) × 100.
