# Program Name: Karl Pearson's Coefficient of Correlation
import math
import statistics

def pearson_correlation(x, y):
    if len(x) != len(y) or len(x) < 2:
        raise ValueError("x and y must have equal lengths and at least two observations.")
    mean_x = statistics.mean(x)
    mean_y = statistics.mean(y)
    numerator = sum((a - mean_x) * (b - mean_y) for a, b in zip(x, y))
    denominator = math.sqrt(
        sum((a - mean_x) ** 2 for a in x) *
        sum((b - mean_y) ** 2 for b in y)
    )
    if denominator == 0:
        raise ValueError("Correlation is undefined when either variable has zero variance.")
    return numerator / denominator

x = [10, 20, 30, 40, 50]
y = [15, 25, 35, 45, 55]
r = pearson_correlation(x, y)
print("X:", x)
print("Y:", y)
print("Karl Pearson correlation coefficient (r):", round(r, 4))
print("Within theoretical limits:", -1 <= r <= 1)

# Formula used:
# r = Σ[(x − x̄)(y − ȳ)] / √{Σ(x − x̄)² × Σ(y − ȳ)²}.
# Theoretical limit: −1 ≤ r ≤ +1.
