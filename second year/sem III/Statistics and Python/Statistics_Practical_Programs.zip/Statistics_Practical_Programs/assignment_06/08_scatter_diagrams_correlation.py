# Program Name: Scatter Diagrams for r = -1, r = 0 and r = +1
import matplotlib.pyplot as plt

x = list(range(1, 11))
y_positive = [2 * value + 1 for value in x]
y_negative = [-2 * value + 25 for value in x]
y_zero = [5, 12, 7, 15, 9, 4, 13, 6, 11, 8]

fig, axes = plt.subplots(1, 3, figsize=(12, 4))
axes[0].scatter(x, y_negative)
axes[0].set_title("Perfect negative correlation (r = -1)")
axes[1].scatter(x, y_zero)
axes[1].set_title("Approximately no correlation (r ≈ 0)")
axes[2].scatter(x, y_positive)
axes[2].set_title("Perfect positive correlation (r = +1)")
for ax in axes:
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.grid(True)
plt.tight_layout()
plt.show()

# Formula used:
# Pearson's r = Σ[(x − x̄)(y − ȳ)] / √{Σ(x − x̄)² Σ(y − ȳ)²}.
# r = +1: perfect positive linear relationship; r = −1: perfect negative linear relationship;
# r ≈ 0: no linear relationship (this plot uses illustrative data).
