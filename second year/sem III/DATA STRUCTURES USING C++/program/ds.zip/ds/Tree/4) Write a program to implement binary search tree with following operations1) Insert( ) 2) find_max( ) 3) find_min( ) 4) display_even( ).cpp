// 4) Write a program to implement binary search tree with operations:
// 1) Insert() 2) find_max() 3) find_min() 4) display_even() 5) display_odd() 6) find_level()
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *left, *right;
public:
    node* create();
    void insert(int);
    void find_max(node*);
    void find_min(node*);
    void display_even(node*);
    void display_odd(node*);
    void find_level(node*, int, int);
}*root;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::insert(int x)
{
    node *n, *temp;
    n = create();
    n->left = NULL;
    n->info = x;
    n->right = NULL;
    if(root == NULL)
    {
        root = n;
        cout<<"\nNode inserted...";
    }
    else
    {
        temp = root;
        while(temp != NULL)
        {
            if(n->info < temp->info)
            {
                if(temp->left == NULL)
                {
                    temp->left = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->left;
                }
            }
            else if(n->info > temp->info)
            {
                if(temp->right == NULL)
                {
                    temp->right = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->right;
                }
            }
            else
            {
                cout<<"\nNode should not repeated...";
                break;
            }
        }
    }
}

void node::find_max(node *p)
{
    if(p == NULL)
    {
        cout<<"\nTree is empty!";
        return;
    }
    node *temp = p;
    while(temp->right != NULL)
    {
        temp = temp->right;
    }
    cout<<"\nMaximum value in BST = "<<temp->info;
}

void node::find_min(node *p)
{
    if(p == NULL)
    {
        cout<<"\nTree is empty!";
        return;
    }
    node *temp = p;
    while(temp->left != NULL)
    {
        temp = temp->left;
    }
    cout<<"\nMinimum value in BST = "<<temp->info;
}

void node::display_even(node *p)
{
    if(p != NULL)
    {
        display_even(p->left);
        if(p->info % 2 == 0)
        {
            cout<<"\t"<<p->info;
        }
        display_even(p->right);
    }
}

void node::display_odd(node *p)
{
    if(p != NULL)
    {
        display_odd(p->left);
        if(p->info % 2 != 0)
        {
            cout<<"\t"<<p->info;
        }
        display_odd(p->right);
    }
}

void node::find_level(node *p, int srch, int lev)
{
    if(p == NULL)
    {
        return;
    }
    if(p->info == srch)
    {
        cout<<"\nNode "<<srch<<" is found at Level = "<<lev;
        return;
    }
    if(srch < p->info)
    {
        find_level(p->left, srch, lev + 1);
    }
    else
    {
        find_level(p->right, srch, lev + 1);
    }
}

void main()
{
    clrscr();
    node obj;
    int ch, n;
    do
    {
        cout<<"\n\n--- BST OPERATIONS MENU ---";
        cout<<"\n1:Insert\n2:Find Max\n3:Find Min\n4:Display Even\n5:Display Odd\n6:Find Level\n7:Exit";
        cout<<"\nEnter your choice = ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert = ";
                cin>>n;
                obj.insert(n);
                break;
            case 2:
                obj.find_max(root);
                break;
            case 3:
                obj.find_min(root);
                break;
            case 4:
                cout<<"\nEven nodes (Inorder): ";
                obj.display_even(root);
                break;
            case 5:
                cout<<"\nOdd nodes (Inorder): ";
                obj.display_odd(root);
                break;
            case 6:
                cout<<"\nEnter node to find level = ";
                cin>>n;
                obj.find_level(root, n, 0);
                break;
            case 7:
                exit(1);
        }
    }while(ch != 7);
    getch();
}