// 2) Write a program that check entered node is leaf or having one child or having two children.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *left, *right;
public:
    node* create();
    void insert(int);
    void check(int);
}*root;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::insert(int x)
{
    node *n, *temp;
    n = create();
    n->left = NULL;
    n->info = x;
    n->right = NULL;
    if(root == NULL)
    {
        root = n;
        cout<<"\nNode inserted...";
    }
    else
    {
        temp = root;
        while(temp != NULL)
        {
            if(n->info < temp->info)
            {
                if(temp->left == NULL)
                {
                    temp->left = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->left;
                }
            }
            else if(n->info > temp->info)
            {
                if(temp->right == NULL)
                {
                    temp->right = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->right;
                }
            }
            else
            {
                cout<<"\nNode should not repeated...";
                break;
            }
        }
    }
}

void node::check(int srch)
{
    int t = 0;
    node *p;
    p = root;

    while(p != NULL)
    {
        if(srch == p->info)
        {
            t = 1;
            break;
        }
        else if(srch < p->info)
        {
            p = p->left;
        }
        else if(srch > p->info)
        {
            p = p->right;
        }
    }

    if(t == 1)
    {
        if(p->left == NULL && p->right == NULL)
        {
            cout<<"\nEntered node is a Leaf node";
        }
        else if(p->left != NULL && p->right != NULL)
        {
            cout<<"\nEntered node is having two children";
        }
        else
        {
            cout<<"\nEntered node is having one child";
        }
    }
    else
    {
        cout<<"\nNode is NOT found ";
    }
}

void main()
{
    clrscr();
    node obj;
    int ch, n;
    do
    {
        cout<<"\nEnter your choice= ";
        cout<<"\n1:Insert\n2:Check Node\n3:Exit..";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\n Enter val to insert=";
                cin>>n;
                obj.insert(n); //call
                break;
            case 2:
                cout<<"\nEnter node to check= ";
                cin>>n;
                obj.check(n); //call
                break;
            case 3:
                exit(1);
        }
    }while(ch != 3);
    getch();
}