// 5) Write a menu driven program that deletes node from binary search tree.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *left, *right;
public:
    node* create();
    void insert(int);
    void inorder(node*);
    void del_leaf(node*, node*);
    void del_one(node*, node*);
    void del_two(node*);
    void deletenode(int);
}*root;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::insert(int x)
{
    node *n, *temp;
    n = create();
    n->left = NULL;
    n->info = x;
    n->right = NULL;
    if(root == NULL)
    {
        root = n;
        cout<<"\nNode inserted...";
    }
    else
    {
        temp = root;
        while(temp != NULL)
        {
            if(n->info < temp->info)
            {
                if(temp->left == NULL)
                {
                    temp->left = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->left;
                }
            }
            else if(n->info > temp->info)
            {
                if(temp->right == NULL)
                {
                    temp->right = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->right;
                }
            }
            else
            {
                cout<<"\nNode should not repeated...";
                break;
            }
        }
    }
}

void node::inorder(node *p)
{
    if(p != NULL)
    {
        inorder(p->left);
        cout<<"\t"<<p->info;
        inorder(p->right);
    }
}

void node::del_leaf(node *parent, node *child)
{
    if(child == parent->right)
    {
        parent->right = NULL;
    }
    else if(child == parent->left)
    {
        parent->left = NULL;
    }
    delete child;
    cout<<"\nNode is deleted.....";
}

void node::del_one(node *parent, node *child)
{
    if(child == parent->right)
    {
        if(child->right != NULL)
        {
            parent->right = child->right;
        }
        else
        {
            parent->right = child->left;
        }
    }
    else if(child == parent->left)
    {
        if(child->left != NULL)
        {
            parent->left = child->left;
        }
        else
        {
            parent->left = child->right;
        }
    }
    delete child;
    cout<<"\nNode is deleted...........";
}

void node::del_two(node *child)
{
    node *parent = NULL;
    node *lft = child->left;
    while(lft->right != NULL)
    {
        parent = lft;
        lft = lft->right;
    }
    child->info = lft->info;
    if(parent == NULL)
    {
        parent = child;
    }
    if(lft->left == NULL && lft->right == NULL)
    {
        del_leaf(parent, lft);
    }
    else
    {
        del_one(parent, lft);
    }
}

void node::deletenode(int key)
{
    node *parent = NULL;
    node *curr = root;
    int found = 0;

    while(curr != NULL)
    {
        if(key == curr->info)
        {
            found = 1;
            break;
        }
        parent = curr;
        if(key < curr->info)
        {
            curr = curr->left;
        }
        else
        {
            curr = curr->right;
        }
    }

    if(found == 0)
    {
        cout<<"\nNode not found in BST!";
        return;
    }

    // Case 1: Deleting Root node when tree has only root
    if(curr == root && root->left == NULL && root->right == NULL)
    {
        delete root;
        root = NULL;
        cout<<"\nRoot node is deleted.....";
        return;
    }

    // Case I: Deleting Leaf Node
    if(curr->left == NULL && curr->right == NULL)
    {
        del_leaf(parent, curr);
    }
    // Case III: Deleting Node having two children
    else if(curr->left != NULL && curr->right != NULL)
    {
        del_two(curr);
    }
    // Case II: Deleting Node having one child
    else
    {
        // Special case if root has one child
        if(curr == root)
        {
            if(root->left != NULL)
                root = root->left;
            else
                root = root->right;
            delete curr;
            cout<<"\nRoot node with one child is deleted.....";
            return;
        }
        del_one(parent, curr);
    }
}

void main()
{
    clrscr();
    node obj;
    int ch, n;
    do
    {
        cout<<"\n--- MENU ---";
        cout<<"\n1: Insert\n2) Inorder\n3) Delete\n4) Exit";
        cout<<"\nEnter your choice = ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert = ";
                cin>>n;
                obj.insert(n);
                break;
            case 2:
                cout<<"\nInorder Traversal: ";
                obj.inorder(root);
                break;
            case 3:
                cout<<"\nEnter value to delete = ";
                cin>>n;
                obj.deletenode(n);
                break;
            case 4:
                exit(1);
        }
    }while(ch != 4);
    getch();
}