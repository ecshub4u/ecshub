// 7) Write a program to implement Binary search method.
#include<iostream.h>
#include<conio.h>

void binary()
{
    int x[100], srch, i, j, k, f = 0, down, up, mid, n;
    cout<<"\nHow many element you want? ";
    cin>>n;
    cout<<"Enter these numbers: ";
    for(i = 0; i <= n - 1; i++)
    {
        cin>>x[i];
    }
    cout<<"\nEnter search element: ";
    cin>>srch;
    
    // bubble sort logic
    for(i = 0; i <= n - 1; i++) // total number of elements
    {
        for(j = 0; j <= n - 2; j++) // total passes
        {
            if(x[j] > x[j + 1])
            {
                k = x[j];
                x[j] = x[j + 1];
                x[j + 1] = k;
            }
        }
    }
    
    cout<<"Sorted array= ";
    for(i = 0; i <= n - 1; i++)
    {
        cout<<"\t"<<x[i];
    }
    
    down = 0;
    up = n - 1;
    while(down <= up) // logic for binary search
    {
        mid = (down + up) / 2;
        if(x[mid] == srch)
        {
            f = 1;
            break;
        }
        else if(srch > x[mid])
        {
            down = mid + 1;
        }
        else if(srch < x[mid])
        {
            up = mid - 1;
        }
    }
    
    if(f == 1)
    {
        cout<<"\nElement is found at position= "<<mid;
    }
    else
    {
        cout<<"\nElement is not found";
    }
}

void main()
{
    clrscr();
    binary();
    getch();
}