// 1) Write a program to implement bubble sort method.
#include<iostream.h>
#include<conio.h>

void bubble()
{
    int x[100], n, i, j, k;
    cout<<"\nHow many number you want to sort? ";
    cin>>n;
    cout<<"\nEnter these elements : ";
    for(i = 0; i <= n - 1; i++)
    {
        cin>>x[i];
    }
    for(i = 0; i <= n - 1; i++) // total number of elements
    {
        for(j = 0; j <= n - 2; j++) // total passes
        {
            if(x[j] > x[j + 1])
            {
                k = x[j];
                x[j] = x[j + 1];
                x[j + 1] = k;
            }
        }
    }
    cout<<"\nSorted array= ";
    for(i = 0; i <= n - 1; i++)
    {
        cout<<"\t"<<x[i];
    }
}

void main()
{
    clrscr();
    bubble();
    getch();
}