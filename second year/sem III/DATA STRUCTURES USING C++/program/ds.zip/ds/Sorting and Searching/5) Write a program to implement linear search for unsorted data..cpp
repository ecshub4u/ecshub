// 5) Write a program to implement linear search for unsorted data.
#include<iostream.h>
#include<conio.h>

void linear_unsorted()
{
    int x[100], srch, i, f = 0, n;
    cout<<"\nHow many element you want? ";
    cin>>n;
    cout<<"Enter these numbers: ";
    for(i = 0; i <= n - 1; i++)
    {
        cin>>x[i];
    }
    cout<<"\nEnter search element: ";
    cin>>srch;
    for(i = 0; i <= n - 1; i++) // logic for linear search
    {
        if(srch == x[i])
        {
            f = 1;
            break;
        }
    }
    if(f == 1)
    {
        cout<<"\nElement is found at position= "<<i;
    }
    else
    {
        cout<<"\nElement is not found";
    }
}

void main()
{
    clrscr();
    linear_unsorted();
    getch();
}