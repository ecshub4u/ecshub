// Write a program to insert an element at a specified position in an array.
#include<iostream.h>
#include<conio.h>

int item[20];
int cnt = 0;

void create();
void insert_pos(int, int);
void traverse();

void main()
{
    int x, pos;
    clrscr();

    create();

    cout<<"\nEnter position (0 to "<<cnt<<") at which element is to be inserted= ";
    cin>>pos;
    cout<<"\nEnter element to insert= ";
    cin>>x;

    insert_pos(pos, x);

    cout<<"\nArray Elements: ";
    traverse();
    getch();
}

void create()
{
    int i;
    cout<<"Enter total number of elements (max 19): ";
    cin>>cnt;
    cout<<"\nEnter "<<cnt<<" elements:\n";
    for(i = 0; i < cnt; i++)
    {
        cin>>item[i];
    }
}

void insert_pos(int pos, int x)
{
    int i;
    if(cnt >= 20)
    {
        cout<<"\nArray is Full";
    }
    else if(pos < 0 || pos > cnt)
    {
        cout<<"\nInsert operation not performed";
    }
    else
    {
        for(i = cnt - 1; i >= pos; i--)
        {
            item[i + 1] = item[i];
        }
        item[pos] = x;
        cnt++;
        cout<<"\nElement is Inserted...";
    }
}

void traverse()
{
    int i;
    for(i = 0; i <= cnt - 1; i++)
    {
        cout<<"\t"<<item[i];
    }
}
