// Write a program to insert, count and display the nodes of a singly linked list.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *next;
public:
    node* create();
    void ins_beg(int);
    void ins_end(int);
    void display();
    void count();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::count()
{
    int cnt = 0;
    node *p = list;
    while(p != NULL)
    {
        cnt = cnt + 1;
        p = p->next;
    }
    cout<<"\nTotal Number of Nodes in Linked list ="<<cnt;
}

void node::ins_beg(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        list = p;
    }
    else
    {
        q = create();
        q->info = x;
        q->next = p;
        list = q;
    }
    cout<<"\nNode is inserted..";
}

void node::ins_end(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        list = p;
    }
    else
    {
        while(p->next != NULL)
        {
            p = p->next;
        }
        q = create();
        q->info = x;
        q->next = NULL;
        p->next = q;
    }
    cout<<"\nNode is inserted..";
}

void node::display()
{
    node *p;
    p = list;
    while(p != NULL)
    {
        cout<<"\t"<<p->info;
        p = p->next;
    }
}

void main()
{
    int n, ch, z;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice :";
        cout<<"\n1:Insert Beg\n2:Insert End\n3:Count\n4:Display\n5:Exit    ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_beg(n);
                break;
            case 2:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_end(n);
                break;
            case 3:
                obj.count();
                break;
            case 4:
                obj.display();
                break;
            case 5:
                exit(2);
                break;
        }
    }while(ch != 5);
    getch();
}
