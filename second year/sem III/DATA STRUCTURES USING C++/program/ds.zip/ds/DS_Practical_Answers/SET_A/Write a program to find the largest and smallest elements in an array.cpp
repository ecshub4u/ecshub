// Write a program to find the largest and smallest elements in an array.
#include<iostream.h>
#include<conio.h>

void main()
{
    int a[20], n, i, max, min;
    clrscr();

    cout << "Enter total number of elements: ";
    cin >> n;

    cout << "\nEnter " << n << " elements:\n";
    for(i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    max = a[0];
    min = a[0];

    for(i = 1; i < n; i++)
    {
        if(a[i] > max)
        {
            max = a[i];
        }
        if(a[i] < min)
        {
            min = a[i];
        }
    }

    cout << "\nMaximum number in the array = " << max;
    cout << "\nMinimum number in the array = " << min;

    getch();
}
