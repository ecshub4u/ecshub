// Write a program to convert an infix expression into a postfix expression using a stack.
#include<iostream.h>
#include<conio.h>
#define max 50

class stack
{
public:
    int item[max], top;
    void create(stack*);
    void push(stack*, int);
    int pop(stack*);
};

void stack::create(stack *p)
{
    p->top = -1;
}

void stack::push(stack *p, int x)
{
    if(p->top == max - 1)
    {
        cout<<"\nStack overflows..";
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}

int stack::pop(stack *p)
{
    if(p->top == -1)
    {
        cout<<"\nStack underflows..";
        return(0);
    }
    else
    {
        return(p->item[p->top--]);
    }
}

void main()
{
    char infix[50], post[50], ch;
    int i = 0, j = 0;
    clrscr();
    stack obj;
    stack *p, q;
    p = &q;          // Ini. of ptr
    obj.create(p);   // stack create
    
    cout<<"\nEnter infix exp: ";
    cin>>infix;
    
    while(infix[i] != '\0')
    {
        if(infix[i]=='(' || infix[i]=='+' || infix[i]=='-' || 
           infix[i]=='*' || infix[i]=='/' || infix[i]=='$' || infix[i]=='^')
        {
            obj.push(p, infix[i]);
        }
        else if(infix[i] == ')')
        {
            while(p->item[p->top] != '(')
            {
                ch = obj.pop(p);
                if(ch != '(')
                {
                    post[j] = ch;
                    j++;
                }
            }
            obj.pop(p);
        }
        else
        {
            post[j] = infix[i];
            j++;
        }
        i++;
    }

    if(p->top != -1)
    {
        while(p->top != -1)
        {
            ch = obj.pop(p);
            if(ch != '(')
            {
                post[j] = ch;
                j++;
            }
        }
    }

    post[j] = '\0'; // Manual end
    cout<<"\nPostfix Exp= "<<post;
    getch();
}
