// Write a program to implement singly linked list with Insert_begin, Remove_last and Display.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *next;
public:
    node* create();
    void ins_beg(int);
    int rem_end();
    void display();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::ins_beg(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        list = p;
    }
    else
    {
        q = create();
        q->info = x;
        q->next = p;
        list = q;
    }
    cout<<"\nNode is inserted..";
}

int node::rem_end()
{
    int n;
    node *p, *temp;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty ....";
        return(0);
    }
    else if(p->next == NULL)
    {
        n = p->info;
        delete p;
        list = NULL;
        return(n);
    }
    else
    {
        while(p->next->next != NULL)
        {
            p = p->next;
        }
        temp = p->next;
        n = temp->info;
        p->next = NULL;
        delete temp;
        return(n);
    }
}

void node::display()
{
    node *p;
    p = list;
    while(p != NULL)
    {
        cout<<"\t"<<p->info;
        p = p->next;
    }
}

void main()
{
    int n, ch, z;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice :";
        cout<<"\n1:Insert Begin\n2:Remove Last\n3:Display\n4:Exit    ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_beg(n);
                break;
            case 2:
                z = obj.rem_end();
                cout<<"\nRemoved node= "<<z;
                break;
            case 3:
                obj.display();
                break;
            case 4:
                exit(2);
                break;
        }
    }while(ch != 4);
    getch();
}
