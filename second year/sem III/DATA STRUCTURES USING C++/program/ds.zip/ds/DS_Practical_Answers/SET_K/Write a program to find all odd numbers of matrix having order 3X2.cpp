// Write a program to find all odd numbers of matrix having order 3X2.
#include<iostream.h>
#include<conio.h>

void main()
{
    int a[3][2];
    int i, j;
    clrscr();

    cout << "Enter elements of 3 X 2 Matrix:\n";
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 2; j++)
        {
            cin >> a[i][j];
        }
    }

    cout << "\nMatrix is:\n";
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 2; j++)
        {
            cout << "\t" << a[i][j];
        }
        cout << "\n";
    }

    cout << "\nOdd numbers in the matrix are: ";
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 2; j++)
        {
            if(a[i][j] % 2 != 0)
            {
                cout << "\t" << a[i][j];
            }
        }
    }

    getch();
}
