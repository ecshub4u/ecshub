// Write a program to implement doubly linear linked list with Insert_last, Remove_first, Count and Display.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *next, *prev;
public:
    node* create();
    void ins_end(int);
    int rem_beg();
    void display();
    void count();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::count()
{
    int cnt = 0;
    node *p = list;
    while(p != NULL)
    {
        cnt = cnt + 1;
        p = p->next;
    }
    cout<<"\nTotal Number of Nodes in Linked list ="<<cnt;
}

void node::ins_end(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        p->prev = NULL;
        list = p;
    }
    else
    {
        while(p->next != NULL)
        {
            p = p->next;
        }
        q = create();
        q->info = x;
        q->next = NULL;
        q->prev = p;
        p->next = q;
    }
    cout<<"\nNode is inserted..";
}

int node::rem_beg()
{
    int n;
    node *p;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty ....";
        return(0);
    }
    else if(p->next == NULL && p->prev == NULL)
    {
        n = p->info;
        delete p;
        list = NULL;
        return(n);
    }
    else
    {
        n = p->info;
        p->next->prev = NULL;
        list = p->next;
        delete p;
        return(n);
    }
}

void node::display()
{
    node *p;
    p = list;
    while(p != NULL)
    {
        cout<<"\t"<<p->info;
        p = p->next;
    }
}

void main()
{
    int n, ch, z;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice :";
        cout<<"\n1:Insert Last\n2:Remove First\n3:Count\n4:Display\n5:Exit    ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_end(n);
                break;
            case 2:
                z = obj.rem_beg();
                cout<<"\nRemoved node= "<<z;
                break;
            case 3:
                obj.count();
                break;
            case 4:
                obj.display();
                break;
            case 5:
                exit(2);
                break;
        }
    }while(ch != 5);
    getch();
}
