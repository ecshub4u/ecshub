// Write a program to implement insert first, remove last and display operations of singly circular linked list.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *next;
public:
    node* create();
    void ins_beg(int);
    int rem_end();
    void display();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::ins_beg(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = p;
        list = p;
    }
    else
    {
        while(p->next != list)
        {
            p = p->next;
        }
        q = create();
        q->info = x;
        q->next = p->next;
        p->next = q;
        list = q;
    }
    cout<<"\nNode is inserted..";
}

int node::rem_end()
{
    node *p, *temp;
    int n;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty...";
        return(0);
    }
    else if(p->next == p)
    {
        n = p->info;
        delete p;
        list = NULL;
        return(n);
    }
    else
    {
        while(p->next->next != list)
        {
            p = p->next;
        }
        temp = p->next;
        n = temp->info;
        p->next = temp->next;
        delete temp;
        return(n);
    }
}

void node::display()
{
    node *p;
    p = list;
    if(list != NULL)
    {
        do
        {
            cout<<"\t"<<p->info;
            p = p->next;
        } while(p != list);
    }
}

void main()
{
    int n, ch, z;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice :";
        cout<<"\n1:Insert First\n2:Remove Last\n3:Display\n4:Exit    ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_beg(n);
                break;
            case 2:
                z = obj.rem_end();
                cout<<"\nRemoved node= "<<z;
                break;
            case 3:
                obj.display();
                break;
            case 4:
                exit(2);
                break;
        }
    }while(ch != 4);
    getch();
}
