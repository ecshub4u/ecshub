// Write a program to perform insert, isempty and isfull operations of circular queue.
#include<iostream.h>
#include<conio.h>
#include<process.h>
#define max 5

class queue
{
    int item[max], front, rear;
public:
    void create(queue*);
    void isempty(queue*);
    void isfull(queue*);
    void insert(queue*, int);
    void display(queue*);
};

void queue::create(queue *p)
{
    p->front = -1;
    p->rear = -1;
    cout<<"\nCircular Queue is Created....";
}

void queue::isempty(queue *p)
{
    if(p->front == -1)
    {
        cout<<"\nQueue is empty";
    }
    else
    {
        cout<<"\nQueue is NOT empty";
    }
}

void queue::isfull(queue *p)
{
    if((p->front == 0 && p->rear == max - 1) || (p->front == p->rear + 1))
    {
        cout<<"\nQueue is Full";
    }
    else
    {
        cout<<"\nQueue is NOT Full";
    }
}

void queue::insert(queue *p, int x)
{
    if((p->front == 0 && p->rear == max - 1) || (p->front == p->rear + 1))
    {
        cout<<"\nQueue overflows...";
        return;
    }
    else
    {
        if(p->front == -1)
        {
            p->front = p->rear = 0;
        }
        else
        {
            p->rear = (p->rear + 1) % max;
        }
        p->item[p->rear] = x;
        cout<<"\nElement is inserted.....";
    }
}

void queue::display(queue *p)
{
    int i;
    if(p->front == -1)
    {
        cout<<"\nQueue is empty";
        return;
    }
    for(i = p->front; i != p->rear; i = (i + 1) % max)
    {
        cout<<"\t"<<p->item[i];
    }
    cout<<"\t"<<p->item[p->rear];
}

void main()
{
    queue *q, p, obj;
    q = &p; // Initialization of pointer
    int n, ch;
    clrscr();
    do
    {
        cout<<"\nEnter Your choice:";
        cout<<"\n1:Create\n2:Isempty\n3:Isfull\n4:Insert\n5:Display\n6:Exit ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                obj.create(q);
                break;
            case 2:
                obj.isempty(q);
                break;
            case 3:
                obj.isfull(q);
                break;
            case 4:
                cout<<"\nEnter any element: ";
                cin>>n;
                obj.insert(q, n);
                break;
            case 5:
                obj.display(q);
                break;
            case 6:
                exit(0);
        }
    }while(ch != 6);
    getch();
}
