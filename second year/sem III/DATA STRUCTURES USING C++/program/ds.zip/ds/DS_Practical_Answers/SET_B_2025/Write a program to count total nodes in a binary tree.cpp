// Write a program to count total nodes in a binary tree.
// 1) Insert() 2) Count_leaf() 3) Count_total() 4) Search()
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *left, *right;
public:
    node* create();
    void insert(int);
    void inorder(node*);
    int count_total(node*);
}*root;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::insert(int x)
{
    node *n, *temp;
    n = create();
    n->left = NULL;
    n->info = x;
    n->right = NULL;
    if(root == NULL)
    {
        root = n;
        cout<<"\nNode inserted...";
    }
    else
    {
        temp = root;
        while(temp != NULL)
        {
            if(n->info < temp->info)
            {
                if(temp->left == NULL)
                {
                    temp->left = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->left;
                }
            }
            else if(n->info > temp->info)
            {
                if(temp->right == NULL)
                {
                    temp->right = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->right;
                }
            }
            else
            {
                cout<<"\nNode should not repeated...";
                break;
            }
        }
    }
}

int node::count_total(node *p)
{
    if(p == NULL)
    {
        return(0);
    }
    else if(p->left == NULL && p->right == NULL)
    {
        return(1);
    }
    else
    {
        return(count_total(p->left) + count_total(p->right) + 1);
    }
}

void node::inorder(node *p)
{
    if(p != NULL)
    {
        inorder(p->left);
        cout<<"\t"<<p->info;
        inorder(p->right);
    }
}

void main()
{
    clrscr();
    node obj;
    int ch, n, z;
    do
    {
        cout<<"\nEnter your choice= ";
        cout<<"\n1:Insert\n2:Display (Inorder)\n3:Count Total Nodes\n4:Exit..";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\n Enter val to insert=";
                cin>>n;
                obj.insert(n); //call
                break;
            case 2:
                obj.inorder(root);
                break;
            case 3:
                z = obj.count_total(root);
                cout<<"\nTotal nodes="<<z;
                break;
            case 4:
                exit(1);
        }
    }while(ch != 4);
    getch();
}
