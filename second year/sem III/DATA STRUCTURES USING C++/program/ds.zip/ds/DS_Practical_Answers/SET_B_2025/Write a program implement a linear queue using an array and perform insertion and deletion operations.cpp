// Write a program implement a linear queue using an array and perform insertion and deletion operations.
#include<iostream.h>
#include<conio.h>
#include<process.h>
#define max 5

class queue
{
    int item[max], front, rear;
public:
    void create(queue*);
    void isempty(queue*);
    void isfull(queue*);
    void insert(queue*, int);
    int remove(queue*);
    void status(queue*);
};

void queue::create(queue *p)
{
    p->front = -1;
    p->rear = -1;
    cout<<"\nQueue is Created....";
}

void queue::isempty(queue *p)
{
    if(p->front == p->rear)
    {
        cout<<"\nQueue is empty";
    }
    else
    {
        cout<<"\nQueue is NOT empty";
    }
}

void queue::isfull(queue *p)
{
    if(p->rear == max - 1)
    {
        cout<<"\nQueue is Full";
    }
    else
    {
        cout<<"\nQueue is NOT Full";
    }
}

void queue::insert(queue *p, int x)
{
    if(p->rear == max - 1)
    {
        cout<<"\nQueue Overflows..";
    }
    else
    {
        ++p->rear;
        p->item[p->rear] = x;
        cout<<"\nElement is Inserted...";
    }
}

int queue::remove(queue *p)
{
    if(p->front == p->rear)
    {
        cout<<"\nQueue Underflows..";
        return(0);
    }
    else
    {
        ++p->front;
        return(p->item[p->front]);
    }
}

void queue::status(queue *p)
{
    int i;
    for(i = p->front + 1; i <= p->rear; i++)
    {
        cout<<"\t"<<p->item[i];
    }
}

void main()
{
    queue *q, p, obj;
    q = &p; // Initialization of pointer
    int n, r, ch;
    clrscr();
    do
    {
        cout<<"\nEnter Your choice:";
        cout<<"\n1:Create\n2:Isempty\n3:Isfull\n4:Insert\n5:Remove\n6:Display\n7:Exit ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                obj.create(q);
                break;
            case 2:
                obj.isempty(q);
                break;
            case 3:
                obj.isfull(q);
                break;
            case 4:
                cout<<"\nEnter any element: ";
                cin>>n;
                obj.insert(q, n);
                break;
            case 5:
                r = obj.remove(q);
                cout<<"\nRemoved element = "<<r;
                break;
            case 6:
                obj.status(q);
                break;
            case 7:
                exit(0);
        }
    }while(ch != 7);
    getch();
}
