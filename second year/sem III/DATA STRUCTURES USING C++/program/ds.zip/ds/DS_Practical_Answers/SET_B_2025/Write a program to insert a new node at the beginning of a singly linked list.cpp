// Write a program to insert a new node at the beginning of a singly linked list.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *next;
public:
    node* create();
    void ins_beg(int);
    void display();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::ins_beg(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        list = p;
    }
    else
    {
        q = create();
        q->info = x;
        q->next = p;
        list = q;
    }
    cout<<"\nNode is inserted..";
}

void node::display()
{
    node *p;
    p = list;
    while(p != NULL)
    {
        cout<<"\t"<<p->info;
        p = p->next;
    }
}

void main()
{
    int n, ch, z;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice :";
        cout<<"\n1:Insert Beg\n2:Display\n3:Exit    ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_beg(n);
                break;
            case 2:
                obj.display();
                break;
            case 3:
                exit(2);
                break;
        }
    }while(ch != 3);
    getch();
}
