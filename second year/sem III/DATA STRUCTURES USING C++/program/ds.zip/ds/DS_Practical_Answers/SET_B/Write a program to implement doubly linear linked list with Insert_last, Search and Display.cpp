// Write a program to implement doubly linear linked list with Insert_last, Search and Display.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *next, *prev;
public:
    node* create();
    void ins_end(int);
    void display();
    void search(int);
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::search(int srch)
{
    int f = 0;
    node *p = list;
    while(p != NULL)
    {
        if(p->info == srch)
        {
            f = 1;
            break;
        }
        p = p->next;
    }
    if(f == 1)
        cout<<"\nNode is found";
    else
        cout<<"\nNode is not found ";
}

void node::ins_end(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        p->prev = NULL;
        list = p;
    }
    else
    {
        while(p->next != NULL)
        {
            p = p->next;
        }
        q = create();
        q->info = x;
        q->next = NULL;
        q->prev = p;
        p->next = q;
    }
    cout<<"\nNode is inserted..";
}

void node::display()
{
    node *p;
    p = list;
    while(p != NULL)
    {
        cout<<"\t"<<p->info;
        p = p->next;
    }
}

void main()
{
    int n, ch, z;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice :";
        cout<<"\n1:Insert Last\n2:Search\n3:Display\n4:Exit    ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_end(n);
                break;
            case 2:
                cout<<"\nEnter search val=";
                cin>>n;
                obj.search(n);
                break;
            case 3:
                obj.display();
                break;
            case 4:
                exit(2);
                break;
        }
    }while(ch != 4);
    getch();
}
