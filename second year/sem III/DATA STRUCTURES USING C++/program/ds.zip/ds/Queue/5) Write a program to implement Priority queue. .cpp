// Implementation of Priority Queue
#include<iostream.h>
#include<conio.h>
#include<process.h>
#define max 5

class queue
{
    int item[max], pri[max], front, rear;
public:
    void create(queue*);
    void insert(queue*, int, int);
    int remove(queue*);
    void display(queue*);
};

void queue::create(queue *q)
{
    q->front = q->rear = -1;
    cout<<"\nQueue is created...";
}

void queue::insert(queue *q, int x, int p)
{
    if(q->rear == max - 1)
    {
        cout<<"\nQueue Overflows...";
    }
    else
    {
        ++q->rear;
        q->item[q->rear] = x;
        q->pri[q->rear] = p;
        cout<<"\nElement is inserted...";
    }
}

int queue::remove(queue *q)
{
    int m, pos = 0, i, z;
    if(q->front == q->rear)
    {
        cout<<"\nQueue underflows...";
        return(0);
    }
    else
    {
        m = q->pri[0];
        for(i = q->front + 1; i <= q->rear; i++)
        {
            if(m < q->pri[i])
            {
                m = q->pri[i];
                pos = i;
            }
        }
        z = q->item[pos];
        for(i = pos; i <= q->rear; i++)
        {
            q->item[i] = q->item[i + 1];
            q->pri[i] = q->pri[i + 1];
        }
        --q->rear;
        return(z);
    }
}

void queue::display(queue *q)
{
    int i;
    cout<<"\nPriority: ";
    for(i = q->front + 1; i <= q->rear; i++)
    {
        cout<<"\t"<<q->pri[i];
    }
    cout<<"\nElements: ";
    for(i = q->front + 1; i <= q->rear; i++)
    {
        cout<<"\t"<<q->item[i];
    }
}

void main()
{
    clrscr();
    int ch, n, x, pr;
    queue obj, p, *q;
    q = &p;
    do
    {
        cout<<"\n1:Create\n2:Insert\n3:Remove\n4:Display\n5:Exit :";
        cin>>ch;
        switch(ch)
        {
            case 1:
                obj.create(q);
                break;
            case 2:
                cout<<"\nEnter ele= ";
                cin>>n;
                cout<<"\nEnter Pri= ";
                cin>>pr;
                obj.insert(q, n, pr);
                break;
            case 3:
                x = obj.remove(q);
                cout<<"\nRemoved Val="<<x;
                break;
            case 4:
                obj.display(q);
                break;
            case 5:
                exit(0);
        }
    }while(ch != 5);
    getch();
}