// Write a program to implement IRD (Input Restricted Deque)
#include<iostream.h>
#include<conio.h>
#include<process.h>
#define max 5

class ird
{
    int item[max], left, right;
public:
    void create(ird*);
    void insert(ird*, int);
    int rem_left(ird*);
    int rem_right(ird*);
    void display(ird*);
};

void ird::create(ird *q)
{
    q->left = q->right = -1;
    cout<<"\nIRD is Created....";
}

void ird::insert(ird *q, int x)
{
    if(q->right == max - 1)
    {
        cout<<"\nIRD overflows...";
    }
    else
    {
        ++q->right;
        q->item[q->right] = x;
        cout<<"\nElement is inserted...";
    }
}

int ird::rem_left(ird *q)
{
    if(q->right == q->left)
    {
        cout<<"\nIRD underflows...";
        return(0);
    }
    else
    {
        ++q->left;
        return(q->item[q->left]);
    }
}

int ird::rem_right(ird *q)
{
    if(q->right == q->left)
    {
        cout<<"\nIRD underflows...";
        return(0);
    }
    else
    {
        return(q->item[q->right--]);
    }
}

void ird::display(ird *q)
{
    int i;
    for(i = q->left + 1; i <= q->right; i++)
    {
        cout<<"\t"<<q->item[i];
    }
}

void main()
{
    ird *q, p, obj;
    q = &p; // Initialization of pointer
    int n, r, ch;
    clrscr();
    do
    {
        cout<<"\nEnter Your choice:";
        cout<<"\n1:Create\n2:Insert\n3:Remove Left\n4:Remove Right\n5:Display\n6:Exit ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                obj.create(q);
                break;
            case 2:
                cout<<"\nEnter any element: ";
                cin>>n;
                obj.insert(q, n);
                break;
            case 3:
                r = obj.rem_left(q);
                cout<<"\nRemoved element from left = "<<r;
                break;
            case 4:
                r = obj.rem_right(q);
                cout<<"\nRemoved element from right = "<<r;
                break;
            case 5:
                obj.display(q);
                break;
            case 6:
                exit(0);
        }
    }while(ch != 6);
    getch();
}