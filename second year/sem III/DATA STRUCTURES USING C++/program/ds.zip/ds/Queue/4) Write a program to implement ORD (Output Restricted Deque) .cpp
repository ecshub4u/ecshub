// Write a program to implement ORD (Output Restricted Deque)
#include<iostream.h>
#include<conio.h>
#include<process.h>
#define max 5

class ord
{
    int item[max], left, right;
public:
    void create(ord*);
    void ins_left(ord*, int);
    void ins_right(ord*, int);
    int rem_left(ord*);
    void display(ord*);
};

void ord::create(ord *q)
{
    q->left = q->right = -1;
    cout<<"\nORD is Created....";
}

void ord::ins_left(ord *q, int x)
{
    int i;
    if(q->right == max - 1)
    {
        cout<<"\nORD Overflows....";
    }
    else
    {
        for(i = q->right + 1; i >= q->left + 2; i--)
        {
            q->item[i] = q->item[i - 1];
        }
        q->item[q->left + 1] = x;
        ++q->right;
        cout<<"\nElement is inserted from left...";
    }
}

void ord::ins_right(ord *q, int x)
{
    if(q->right == max - 1)
    {
        cout<<"\nORD Overflows...";
    }
    else
    {
        ++q->right;
        q->item[q->right] = x;
        cout<<"\nelement is inserted from right side ...";
    }
}

int ord::rem_left(ord *q)
{
    if(q->right == q->left)
    {
        cout<<"\nORD underflows...";
        return(0);
    }
    else
    {
        ++q->left;
        return(q->item[q->left]);
    }
}

void ord::display(ord *q)
{
    int i;
    for(i = q->left + 1; i <= q->right; i++)
    {
        cout<<"\t"<<q->item[i];
    }
}

void main()
{
    ord *q, p, obj;
    q = &p; // Initialization of pointer
    int n, r, ch;
    clrscr();
    do
    {
        cout<<"\nEnter Your choice:";
        cout<<"\n1:Create\n2:Insert Left\n3:Insert Right\n4:Remove\n5:Display\n6:Exit ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                obj.create(q);
                break;
            case 2:
                cout<<"\nEnter any element: ";
                cin>>n;
                obj.ins_left(q, n);
                break;
            case 3:
                cout<<"\nEnter any element: ";
                cin>>n;
                obj.ins_right(q, n);
                break;
            case 4:
                r = obj.rem_left(q);
                cout<<"\nRemoved element = "<<r;
                break;
            case 5:
                obj.display(q);
                break;
            case 6:
                exit(0);
        }
    }while(ch != 6);
    getch();
}