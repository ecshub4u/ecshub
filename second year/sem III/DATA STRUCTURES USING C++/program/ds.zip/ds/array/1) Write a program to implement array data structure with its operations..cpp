// 1) Write a program to implement array data structure with its operations.
#include<iostream.h>
#include<conio.h>
#include<process.h>

#define n 10

int item[n];
int cnt = 0;

void insert(int);
void traverse();
void reverse();
int remove(int);

void main()
{
    int x, pos, z, ch;
    clrscr();
    do
    {
        cout << "\n\nEnter your choice= ";
        cout << "\n1:Insert\n2:Delete\n3:Display\n4:Reverse\n5:Exit\n";
        cin >> ch;
        switch(ch)
        {
            case 1:
                cout << "\nEnter val to insert= ";
                cin >> x;
                insert(x);
                break;

            case 2:
                cout << "\nEnter position of element to remove= ";
                cin >> pos;
                z = remove(pos);
                cout << "\nRemoved Element= " << z;
                break;

            case 3:
                cout << "\nArray Elements: ";
                traverse();
                break;

            case 4:
                cout << "\nReversed Array: ";
                reverse();
                break;

            case 5:
                exit(1);
        }
    } while(ch != 5);
    getch();
}

void insert(int x)
{
    if(cnt >= n)
    {
        cout << "\nArray is Full";
    }
    else
    {
        item[cnt] = x;
        cnt++;
    }
}

void traverse()
{
    int i;
    for(i = 0; i <= cnt - 1; i++)
    {
        cout << "\t" << item[i];
    }
}

void reverse()
{
    int i;
    for(i = cnt - 1; i >= 0; i--)
    {
        cout << "\t" << item[i];
    }
}

int remove(int pos)
{
    int i, z;
    if(pos < 0 || pos > cnt - 1)
    {
        cout << "\nDelete operation not performed";
        return 0;
    }
    else
    {
        z = item[pos];
        for(i = pos; i < cnt - 1; i++)
        {
            item[i] = item[i + 1];
        }
        cnt--;
        return(z);
    }
}