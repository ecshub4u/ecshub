// 3) Write a program that print only odd numbers in an array.
#include<iostream.h>
#include<conio.h>

void main()
{
    int a[20], n, i;
    clrscr();

    cout << "Enter total number of elements: ";
    cin >> n;

    cout << "\nEnter " << n << " elements:\n";
    for(i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    cout << "\nOdd numbers in the array are: ";
    for(i = 0; i < n; i++)
    {
        if(a[i] % 2 != 0)
        {
            cout << "\t" << a[i];
        }
    }

    getch();
}