// 7) Write a program to find multiplication of two matrices.
#include<iostream.h>
#include<conio.h>

void main()
{
    int a[10][10], b[10][10], c[10][10];
    int i, j, k, r, col;
    clrscr();

    cout << "Enter number of rows and columns: ";
    cin >> r >> col;

    cout << "\nEnter elements of 1st Matrix:\n";
    for(i = 0; i < r; i++)
    {
        for(j = 0; j < col; j++)
        {
            cin >> a[i][j];
        }
    }

    cout << "\nEnter elements of 2nd Matrix:\n";
    for(i = 0; i < r; i++)
    {
        for(j = 0; j < col; j++)
        {
            cin >> b[i][j];
        }
    }

    // Multiplication of two matrices
    for(i = 0; i < r; i++)
    {
        for(j = 0; j < col; j++)
        {
            c[i][j] = 0;
            for(k = 0; k < col; k++)
            {
                c[i][j] = c[i][j] + (a[i][k] * b[k][j]);
            }
        }
    }

    cout << "\nMultiplication of two matrices is:\n";
    for(i = 0; i < r; i++)
    {
        for(j = 0; j < col; j++)
        {
            cout << "\t" << c[i][j];
        }
        cout << "\n";
    }

    getch();
}