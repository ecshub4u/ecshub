// Write a program that counts total number of vowels present in string by using stack.
#include<iostream.h>
#include<conio.h>
#define max 50

class stack
{
public:
    int item[max], top;
    void create(stack*);
    void push(stack*, int);
    int pop(stack*);
};

void stack::create(stack *p)
{
    p->top = -1;
}

void stack::push(stack *p, int x)
{
    if(p->top == max - 1)
    {
        cout<<"\nStack overflows...";
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}

int stack::pop(stack *p)
{
    if(p->top == -1)
    {
        cout<<"\nStack underflows...";
        return(0);
    }
    else
    {
        return(p->item[p->top--]);
    }
}

void main()
{
    char str[50], ch;
    int i = 0, cnt = 0;
    clrscr();
    stack obj;
    stack *p, q;
    p = &q; // Initialization of pointer
    obj.create(p); // Stack create

    cout<<"\nEnter any string= ";
    cin>>str;

    while(str[i] != '\0')
    {
        obj.push(p, str[i]);
        i++;
    }

    while(p->top != -1)
    {
        ch = obj.pop(p);
        if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' ||
           ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
        {
            cnt++;
        }
    }

    cout<<"\nTotal vowels present in string= "<<cnt;
    getch();
}