// Write a program that demonstrate implementation of multiple stacks.
#include<iostream.h>
#include<conio.h>
#define max 50

class stack
{
public:
    int item[max], top;
    void create(stack*);
    void push(stack*, int);
    void display(stack*);
};

void stack::create(stack *p)
{
    p->top = -1;
}

void stack::push(stack *p, int x)
{
    if(p->top == max - 1)
    {
        cout<<"\nStack overflows..";
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}

void stack::display(stack *p)
{
    int i;
    for(i = p->top; i >= 0; i--)
    {
        cout<<"\n"<<p->item[i];
    }
}

void main()
{
    int n, no, i;
    clrscr();
    stack obj;
    stack *even, *odd, p, q;
    even = &p;
    odd = &q;
    
    obj.create(even); // even stack create
    obj.create(odd);  // odd stack create

    cout<<"\nHow many numbers you want to enter= ";
    cin>>n;

    for(i = 1; i <= n; i++)
    {
        cout<<"Enter number= ";
        cin>>no;
        if(no % 2 == 0)
        {
            obj.push(even, no);
        }
        else
        {
            obj.push(odd, no);
        }
    }

    cout<<"\nEven Stack elements:";
    obj.display(even);

    cout<<"\n\nOdd Stack elements:";
    obj.display(odd);

    getch();
}