// Write a program to calculate digit sum of entered number by using recursion.
#include<iostream.h>
#include<conio.h>

int dsum(int n)
{
    if(n == 0)
    {
        return(0);
    }
    else
    {
        return((n % 10) + dsum(n / 10));
    }
}

void main()
{
    int no, z;
    clrscr();
    cout<<"\nEnter any number= ";
    cin>>no;
    z = dsum(no); // call
    cout<<"\nDigit sum= "<<z;
    getch();
}