// 2) Write a menu program to implement stack by using linked list. (Dynamic implementation of stack)
#include<iostream.h>
#include<conio.h>
#include<process.h>

class node
{
    int info;
    node *next;
public:
    node* create();
    void push(int);
    int pop();
    void display();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::push(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        list = p;
    }
    else
    {
        q = create();
        q->info = x;
        q->next = p;
        list = q;
    }
    cout<<"\nElement is Pushed...";
}

int node::pop()
{
    int z;
    node *p;
    p = list;
    if(p == NULL)
    {
        cout<<"\nStack underflows..,.";
        return 0;
    }
    else if(p->next == NULL)
    {
        z = p->info;
        delete(p);
        list = NULL;
        return(z);
    }
    else
    {
        z = p->info;
        list = p->next;
        delete(p);
        return(z);
    }
}

void node::display()
{
    node *p;
    p = list;
    while(p != NULL)
    {
        cout<<"\n"<<p->info;
        p = p->next;
    }
}

void main()
{
    int ch, x, z;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice: ";
        cout<<"\n1:PUSH\n2:POP\n3:Display\n4:Exit   ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to push:  ";
                cin>>x;
                obj.push(x);
                break;
            case 2:
                z = obj.pop();
                cout<<"\nPopped val="<<z;
                break;
            case 3:
                obj.display();
                break;
            case 4:
                exit(1);
        }
    }while(ch != 4);
    getch();
}