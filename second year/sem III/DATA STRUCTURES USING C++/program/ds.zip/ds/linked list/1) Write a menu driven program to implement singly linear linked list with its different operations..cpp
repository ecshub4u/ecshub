// 1) Write a menu driven program to implement singly linear linked list with its different operations.
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *next;
public:
    node* create();
    void ins_beg(int);
    void ins_end(int);
    void ins_bet(int, int);
    int rem_beg();
    int rem_end();
    int rem_bet(int);
    void display();
    void count();
    void search(int);
    void reverse();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::count()
{
    int cnt = 0;
    node *p = list;
    while(p != NULL)
    {
        cnt = cnt + 1;
        p = p->next;
    }
    cout<<"\nTotal Number of Nodes in Linked list ="<<cnt;
}

void node::search(int srch)
{
    int f = 0;
    node *p = list;
    while(p != NULL)
    {
        if(p->info == srch)
        {
            f = 1;
            break;
        }
        p = p->next;
    }
    if(f == 1)
        cout<<"\nNode is found";
    else
        cout<<"\nNode is not found ";
}

void node::reverse()
{
    node *t1, *t2, *t3 = NULL;
    t1 = list;
    while(t1 != NULL)
    {
        t2 = t1->next;
        t1->next = t3;
        t3 = t1;
        t1 = t2;
    }
    list = t3;
    cout<<"\nLinked list is reversed...";
}

void node::ins_beg(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        list = p;
    }
    else
    {
        q = create();
        q->info = x;
        q->next = p;
        list = q;
    }
    cout<<"\nNode is inserted..";
}

void node::ins_end(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        list = p;
    }
    else
    {
        while(p->next != NULL)
        {
            p = p->next;
        }
        q = create();
        q->info = x;
        q->next = NULL;
        p->next = q;
    }
    cout<<"\nNode is inserted..";
}

void node::ins_bet(int after, int x)
{
    node *p, *q;
    p = list;
    if(p == NULL || p->next == NULL)
    {
        cout<<"\nInsert between is not possible ";
    }
    else
    {
        while(p->next != NULL)
        {
            if(after == p->info)
            {
                q = create();
                q->info = x;
                q->next = p->next;
                p->next = q;
            }
            p = p->next;
        }
        cout<<"\nNode is inserted..";
    }
}

int node::rem_beg()
{
    int n;
    node *p;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty ....";
        return(0);
    }
    else if(p->next == NULL)
    {
        n = p->info;
        delete p;
        list = NULL;
        return(n);
    }
    else
    {
        n = p->info;
        list = p->next;
        delete p;
        return(n);
    }
}

int node::rem_end()
{
    int n;
    node *p, *temp;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty ....";
        return(0);
    }
    else if(p->next == NULL)
    {
        n = p->info;
        delete p;
        list = NULL;
        return(n);
    }
    else
    {
        while(p->next->next != NULL)
        {
            p = p->next;
        }
        temp = p->next;
        n = temp->info;
        p->next = NULL;
        delete temp;
        return(n);
    }
}

int node::rem_bet(int after)
{
    int n;
    node *p, *temp;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty .... ";
        return(0);
    }
    else if(p->next == NULL || p->next->next == NULL)
    {
        cout<<"\nRemove between is not possible";
        return(0);
    }
    else
    {
        while(p->next != NULL)
        {
            if(p->info == after)
            {
                temp = p->next;
                n = temp->info;
                p->next = temp->next;
                delete temp;
                return(n);
            }
            p = p->next;
        }
        return(0);
    }
}

void node::display()
{
    node *p;
    p = list;
    while(p != NULL)
    {
        cout<<"\t"<<p->info;
        p = p->next;
    }
}

void main()
{
    int n, ch, z, af;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice :";
        cout<<"\n1:Insert Beg\n2:Insert End\n3:Insert Bet\n4:Remove Beg\n5:Remove End\n6:Remove Bet\n7:Display\n8:Count\n9:Search\n10:Reverse\n11:Exit    ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to Insert= ";
                cin>>n;
                obj.ins_beg(n);
                break;
            case 2:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_end(n);
                break;
            case 3:
                cout<<"\nAfter which node ?";
                cin>>af;
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_bet(af, n);
                break;
            case 4:
                z = obj.rem_beg();
                cout<<"\nRemoved node= "<<z;
                break;
            case 5:
                z = obj.rem_end();
                cout<<"\nRemoved node="<<z;
                break;
            case 6:
                cout<<"\nAfter which node ? ";
                cin>>af;
                z = obj.rem_bet(af);
                cout<<"\nRemoved node= "<<z;
                break;
            case 7:
                obj.display();
                break;
            case 8:
                obj.count();
                break;
            case 9:
                cout<<"\nEnter search val=";
                cin>>n;
                obj.search(n);
                break;
            case 10:
                obj.reverse();
                break;
            case 11:
                exit(2);
                break;
        }
    }while(ch != 11);
    getch();
}