// Write a program to implement linear search for sorted data
#include<iostream.h>
#include<conio.h>

void linear_sorted()
{
    int x[100], srch, i, j, k, f = 0, n;
    cout<<"\nHow many element you want? ";
    cin>>n;
    cout<<"Enter these numbers: ";
    for(i = 0; i <= n - 1; i++)
    {
        cin>>x[i];
    }
    cout<<"\nEnter search element: ";
    cin>>srch;
    
    // bubble sort logic
    for(i = 0; i <= n - 1; i++) // total number of elements
    {
        for(j = 0; j <= n - 2; j++) // total passes
        {
            if(x[j] > x[j + 1])
            {
                k = x[j];
                x[j] = x[j + 1];
                x[j + 1] = k;
            }
        }
    }
    
    cout<<"Sorted array= ";
    for(i = 0; i <= n - 1; i++)
    {
        cout<<"\t"<<x[i];
    }
    
    // logic for linear search
    for(i = 0; i <= n - 1; i++)
    {
        if(srch == x[i])
        {
            f = 1;
            break;
        }
    }
    
    if(f == 1)
    {
        cout<<"\nElement is found at position= "<<i;
    }
    else
    {
        cout<<"\nElement is not found";
    }
}

void main()
{
    clrscr();
    linear_sorted();
    getch();
}
