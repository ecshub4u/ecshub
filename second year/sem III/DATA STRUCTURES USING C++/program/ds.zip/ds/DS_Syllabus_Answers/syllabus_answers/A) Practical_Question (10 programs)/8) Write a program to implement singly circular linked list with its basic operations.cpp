// Write a program to implement singly circular linked list with its basic operations
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *next;
public:
    node* create();
    void ins_beg(int);
    void ins_end(int);
    void ins_bet(int, int);
    int rem_beg();
    int rem_end();
    int rem_bet(int);
    void display();
    void count();
    void search(int);
    void reverse();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::count()
{
    int cnt = 0;
    node *p = list;
    if(list == NULL)
    {
        cnt = 0;
    }
    else
    {
        do
        {
            cnt = cnt + 1;
            p = p->next;
        } while(p != list);
    }
    cout<<"\nTotal Number of Nodes in Linked list ="<<cnt;
}

void node::search(int srch)
{
    int f = 0;
    node *p = list;
    if(list != NULL)
    {
        do
        {
            if(p->info == srch)
            {
                f = 1;
                break;
            }
            p = p->next;
        } while(p != list);
    }
    if(f == 1)
        cout<<"\nNode is found";
    else
        cout<<"\nNode is not found ";
}

void node::reverse()
{
    if(list == NULL)
    {
        cout<<"\nLinked list is empty...";
        return;
    }
    node *t1, *t2, *t3 = list;
    t1 = list;
    do
    {
        t2 = t1->next;
        t1->next = t3;
        t3 = t1;
        t1 = t2;
    } while(t1 != list);
    list = t3;
    t1->next = t3;
    cout<<"\nLinked list is reversed...";
}

void node::ins_beg(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = p;
        list = p;
    }
    else
    {
        while(p->next != list)
        {
            p = p->next;
        }
        q = create();
        q->info = x;
        q->next = p->next;
        p->next = q;
        list = q;
    }
    cout<<"\nNode is inserted..";
}

void node::ins_end(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = p;
        list = p;
    }
    else
    {
        while(p->next != list)
        {
            p = p->next;
        }
        q = create();
        q->info = x;
        q->next = p->next;
        p->next = q;
    }
    cout<<"\nNode is inserted..";
}

void node::ins_bet(int after, int x)
{
    node *p, *q;
    p = list;
    if(p == NULL || p->next == p)
    {
        cout<<"\nInsert Between not possible";
    }
    else
    {
        while(p->next != list)
        {
            if(p->info == after)
            {
                q = create();
                q->info = x;
                q->next = p->next;
                p->next = q;
            }
            p = p->next;
        }
        cout<<"\nNode is inserted..";
    }
}

int node::rem_beg()
{
    node *p, *temp;
    int n;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty...";
        return(0);
    }
    else if(p->next == p)
    {
        n = p->info;
        delete p;
        list = NULL;
        return(n);
    }
    else
    {
        while(p->next != list)
        {
            p = p->next;
        }
        temp = p->next;
        n = temp->info;
        p->next = temp->next;
        list = temp->next;
        delete temp;
        return(n);
    }
}

int node::rem_end()
{
    node *p, *temp;
    int n;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty...";
        return(0);
    }
    else if(p->next == p)
    {
        n = p->info;
        delete p;
        list = NULL;
        return(n);
    }
    else
    {
        while(p->next->next != list)
        {
            p = p->next;
        }
        temp = p->next;
        n = temp->info;
        p->next = temp->next;
        delete temp;
        return(n);
    }
}

int node::rem_bet(int after)
{
    node *p, *temp;
    int n;
    p = list;
    if(p == NULL)
    {
        cout<<"\nLinked list is empty...";
        return(0);
    }
    else if(p->next == p || p->next->next == p)
    {
        cout<<"\nRemove between not possible";
        return(0);
    }
    else
    {
        while(p->next != list)
        {
            if(p->info == after)
            {
                temp = p->next;
                n = temp->info;
                p->next = temp->next;
                delete temp;
                return(n);
            }
            p = p->next;
        }
        return(0);
    }
}

void node::display()
{
    node *p;
    p = list;
    if(list != NULL)
    {
        do
        {
            cout<<"\t"<<p->info;
            p = p->next;
        } while(p != list);
    }
}

void main()
{
    int n, ch, z, af;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice :";
        cout<<"\n1:Insert Beg\n2:Insert End\n3:Insert Bet\n4:Remove Beg\n5:Remove End\n6:Remove Bet\n7:Display\n8:Count\n9:Search\n10:Reverse\n11:Exit    ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to Insert= ";
                cin>>n;
                obj.ins_beg(n);
                break;
            case 2:
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_end(n);
                break;
            case 3:
                cout<<"\nAfter which node ?";
                cin>>af;
                cout<<"\nEnter val to insert= ";
                cin>>n;
                obj.ins_bet(af, n);
                break;
            case 4:
                z = obj.rem_beg();
                cout<<"\nRemoved node= "<<z;
                break;
            case 5:
                z = obj.rem_end();
                cout<<"\nRemoved node="<<z;
                break;
            case 6:
                cout<<"\nAfter which node ? ";
                cin>>af;
                z = obj.rem_bet(af);
                cout<<"\nRemoved node= "<<z;
                break;
            case 7:
                obj.display();
                break;
            case 8:
                obj.count();
                break;
            case 9:
                cout<<"\nEnter search val=";
                cin>>n;
                obj.search(n);
                break;
            case 10:
                obj.reverse();
                break;
            case 11:
                exit(2);
                break;
        }
    }while(ch != 11);
    getch();
}
