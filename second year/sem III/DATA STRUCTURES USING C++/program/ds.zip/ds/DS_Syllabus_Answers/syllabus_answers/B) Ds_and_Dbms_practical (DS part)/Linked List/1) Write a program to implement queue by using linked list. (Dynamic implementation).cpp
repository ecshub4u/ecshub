// Write a program to implement queue by using linked list. (Dynamic implementation)
#include<iostream.h>
#include<conio.h>
#include<process.h>

class node
{
    int info;
    node *next;
public:
    node* create();
    void insert(int);
    int remove();
    void display();
}*list;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::insert(int x)
{
    node *p, *q;
    p = list;
    if(p == NULL)
    {
        p = create();
        p->info = x;
        p->next = NULL;
        list = p;
    }
    else
    {
        while(p->next != NULL)
        {
            p = p->next;
        }
        q = create();
        q->info = x;
        q->next = NULL;
        p->next = q;
    }
    cout<<"\nElement is Inserted...";
}

int node::remove()
{
    int z;
    node *p;
    p = list;
    if(p == NULL)
    {
        cout<<"\nQueue underflows...";
        return 0;
    }
    else if(p->next == NULL)
    {
        z = p->info;
        delete(p);
        list = NULL;
        return(z);
    }
    else
    {
        z = p->info;
        list = p->next;
        delete(p);
        return(z);
    }
}

void node::display()
{
    node *p;
    p = list;
    while(p != NULL)
    {
        cout<<"\t"<<p->info;
        p = p->next;
    }
}

void main()
{
    int ch, x, z;
    clrscr();
    node obj;
    do
    {
        cout<<"\nEnter your choice: ";
        cout<<"\n1:Insert\n2:Remove\n3:Display\n4:Exit   ";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\nEnter val to insert:  ";
                cin>>x;
                obj.insert(x);
                break;
            case 2:
                z = obj.remove();
                cout<<"\nRemoved val="<<z;
                break;
            case 3:
                obj.display();
                break;
            case 4:
                exit(1);
        }
    }while(ch != 4);
    getch();
}
