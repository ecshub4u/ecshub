// Write a program to check the validity of an expression using stack
#include<iostream.h>
#include<conio.h>
#define max 50

class stack
{
public:
    int item[max], top;
    void create(stack*);
    void push(stack*, int);
    int pop(stack*);
};

void stack::create(stack *p)
{
    p->top = -1;
}

void stack::push(stack *p, int x)
{
    if(p->top == max - 1)
    {
        cout<<"\nStack overflows..";
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}

int stack::pop(stack *p)
{
    if(p->top == -1)
    {
        cout<<"\nStack underflows..";
        return(0);
    }
    else
    {
        return(p->item[p->top--]);
    }
}

void main()
{
    char exp[50], ch;
    int i = 0, t = 0;
    clrscr();
    stack obj;
    stack *p, q;
    p = &q;          // Ini. of ptr
    obj.create(p);   // stack create

    cout<<"\nEnter any expression: ";
    cin>>exp;

    while(exp[i] != '\0')
    {
        if(exp[i] == '(' || exp[i] == '{' || exp[i] == '[')
        {
            obj.push(p, exp[i]);
        }
        else if(exp[i] == ')' || exp[i] == '}' || exp[i] == ']')
        {
            if(p->top == -1)
            {
                t = 1;
                break;
            }
            ch = obj.pop(p);
            if((exp[i] == ')' && ch != '(') ||
               (exp[i] == '}' && ch != '{') ||
               (exp[i] == ']' && ch != '['))
            {
                t = 1;
                break;
            }
        }
        i++;
    }

    if(p->top == -1 && t == 0)
    {
        cout<<"\nExpression is Valid";
    }
    else
    {
        cout<<"\nExpression is Invalid";
    }

    getch();
}
