// Write a program to implement BST with Insert Node, Count Leaf nodes, Count Non-Leaf nodes and Count Total nodes
#include<iostream.h>
#include<process.h>
#include<conio.h>

class node
{
    int info;
    node *left, *right;
public:
    node* create();
    void insert(int);
    int count_leaf(node*);
    int count_nonleaf(node*);
    int count_total(node*);
}*root;

node* node::create()
{
    node *z;
    z = new node;
    return(z);
}

void node::insert(int x)
{
    node *n, *temp;
    n = create();
    n->left = NULL;
    n->info = x;
    n->right = NULL;
    if(root == NULL)
    {
        root = n;
        cout<<"\nNode inserted...";
    }
    else
    {
        temp = root;
        while(temp != NULL)
        {
            if(n->info < temp->info)
            {
                if(temp->left == NULL)
                {
                    temp->left = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->left;
                }
            }
            else if(n->info > temp->info)
            {
                if(temp->right == NULL)
                {
                    temp->right = n;
                    cout<<"\n Node is inserted..";
                    break;
                }
                else
                {
                    temp = temp->right;
                }
            }
            else
            {
                cout<<"\nNode should not repeated...";
                break;
            }
        }
    }
}

int node::count_leaf(node *p)
{
    if(p == NULL)
    {
        return(0);
    }
    else if(p->left == NULL && p->right == NULL)
    {
        cout<<"\t"<<p->info;
        return(1);
    }
    else
    {
        return(count_leaf(p->left) + count_leaf(p->right));
    }
}

int node::count_nonleaf(node *p)
{
    if(p == NULL)
    {
        return(0);
    }
    else if(p->left == NULL && p->right == NULL)
    {
        return(0);
    }
    else
    {
        return(count_nonleaf(p->left) + count_nonleaf(p->right) + 1);
    }
}

int node::count_total(node *p)
{
    if(p == NULL)
    {
        return(0);
    }
    else if(p->left == NULL && p->right == NULL)
    {
        return(1);
    }
    else
    {
        return(count_total(p->left) + count_total(p->right) + 1);
    }
}

void main()
{
    clrscr();
    node obj;
    int ch, n, z;
    do
    {
        cout<<"\nEnter your choice= ";
        cout<<"\n1:Insert\n2:Count Leaf\n3:Count Non-Leaf\n4:Count Total\n5:Exit..";
        cin>>ch;
        switch(ch)
        {
            case 1:
                cout<<"\n Enter val to insert=";
                cin>>n;
                obj.insert(n); //call
                break;
            case 2:
                z = obj.count_leaf(root);
                cout<<"\nTotal Leaf nodes="<<z;
                break;
            case 3:
                z = obj.count_nonleaf(root);
                cout<<"\nTotal Non-Leaf nodes="<<z;
                break;
            case 4:
                z = obj.count_total(root);
                cout<<"\nTotal nodes="<<z;
                break;
            case 5:
                exit(1);
        }
    }while(ch != 5);
    getch();
}
