// Write a program to implement selection sort method
#include<iostream.h>
#include<conio.h>

void selection()
{
    int i, j, k, pos, min, x[50], n;
    cout<<"\nHow many number you want to sort? ";
    cin>>n;
    cout<<"\nEnter these elements: ";
    for(i = 0; i <= n - 1; i++)
    {
        cin>>x[i];
    }
    for(i = 0; i <= n - 1; i++)
    {
        min = x[i];
        for(j = i; j <= n - 1; j++)
        {
            if(min > x[j])
            {
                min = x[j];
                pos = j;
            }
        }
        if(x[i] != min)
        {
            k = x[i];
            x[i] = x[pos];
            x[pos] = k;
        }
    }
    cout<<"\nSorted data=> ";
    for(i = 0; i <= n - 1; i++)
    {
        cout<<"\t"<<x[i];
    }
}

void main()
{
    clrscr();
    selection();
    getch();
}
