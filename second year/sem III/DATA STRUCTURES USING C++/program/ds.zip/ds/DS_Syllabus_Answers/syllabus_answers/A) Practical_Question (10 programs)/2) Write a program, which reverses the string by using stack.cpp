// Write a program, which reverses the string by using stack
#include<iostream.h>
#include<string.h>
#include<conio.h>
#define   max   50
class	stack
{
    public:
    int  item[max],top;
    void  create(stack*);
    void  push(stack*,int);
    int   pop(stack*);
};
void    stack::create(stack   *p)
{
     p->top=-1;
}
void   stack::push(stack *p,int   x)
{
     if(p->top==max-1)   //full
     {
	cout<<"\nStack overflows...";
     }
     else
     {
	 ++p->top;
	 p->item[p->top]=x;
     }
}

int    stack::pop(stack   *p)
{
     if(p->top==-1)   //empty
     {
       cout<<"\nStack underflows..";
       return(0);
     }
     else
     {
	return(p->item[p->top--]);
     }
}

void    main()
{
    char    str[50],rev[50];
    int     i=0,j=0;
    stack   obj;
    stack   *p,q;
    p=&q;  //Ini. of ptr
    obj.create(p);   //stack create
    clrscr();
    cout<<"\nEnter any string= ";
    cin>>str;
    while(str[i]!='\0')
    {
	 obj.push(p,str[i]);
	 i++;
    }
    while(p->top!=-1)
    {
	rev[j]=obj.pop(p);
	j++;
    }
    rev[j]='\0';   //mannual end
    cout<<"\nReverse="<<rev;
    getch();
}
