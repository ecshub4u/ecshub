// Write a program to convert decimal number into binary number by using stack
#include<iostream.h>
#include<conio.h>
#define   max   50
class	stack
{
    public:
    int  item[max],top;
    void  create(stack*);
    void  push(stack*,int);
    int   pop(stack*);
};
void    stack::create(stack   *p)
{
     p->top=-1;
}
void   stack::push(stack *p,int   x)
{
     if(p->top==max-1)   //full
     {
	cout<<"\nStack overflows...";
     }
     else
     {
	 ++p->top;
	 p->item[p->top]=x;
     }
}

int    stack::pop(stack   *p)
{
     if(p->top==-1)   //empty
     {
       cout<<"\nStack underflows..";
       return(0);
     }
     else
     {
	return(p->item[p->top--]);
     }
}

void    main()
{
    int     no,rem,z;
    stack   obj;
    stack   *p,q;
    p=&q;  //Ini. of ptr
    obj.create(p);   //stack create
    clrscr();
    cout<<"\nEnter any decimal number= ";
    cin>>no;
    while(no>0)
    {
	 rem=no%2;
	 obj.push(p,rem);
	 no=no/2;
    }
    cout<<"\nBinary number=";
    while(p->top!=-1)
    {
	z=obj.pop(p);
	cout<<z;
    }
    getch();
}
