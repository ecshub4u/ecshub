// Write a program to find face value of entered number by using recursion
#include<iostream.h>
#include<conio.h>

void faceval(int n)
{
    if(n > 0)
    {
        faceval(n / 10);
        cout<<"\n"<<(n % 10);
    }
}

void main()
{
    int no;
    clrscr();
    cout<<"\nEnter any number= ";
    cin>>no;
    cout<<"\nFace value of digits:";
    faceval(no); // call
    getch();
}
