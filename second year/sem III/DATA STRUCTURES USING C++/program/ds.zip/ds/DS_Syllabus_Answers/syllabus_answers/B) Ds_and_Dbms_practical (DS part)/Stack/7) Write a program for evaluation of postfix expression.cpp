// Write a program for evaluation of postfix expression
#include<iostream.h>
#include<conio.h>
#define max 50

class stack
{
public:
    int item[max], top;
    void create(stack*);
    void push(stack*, int);
    int pop(stack*);
};

void stack::create(stack *p)
{
    p->top = -1;
}

void stack::push(stack *p, int x)
{
    if(p->top == max - 1)
    {
        cout<<"\nStack overflows..";
    }
    else
    {
        ++p->top;
        p->item[p->top] = x;
    }
}

int stack::pop(stack *p)
{
    if(p->top == -1)
    {
        cout<<"\nStack underflows...";
        return(0);
    }
    else
    {
        return(p->item[p->top--]);
    }
}

void main()
{
    char exp[50];
    int i = 0, op2, op1, val;
    clrscr();
    stack obj;
    stack *p, q;
    p = &q;          // Ini. of ptr
    obj.create(p);   // stack create

    cout<<"\nEnter postfix exp: ";
    cin>>exp;

    while(exp[i] != '\0')
    {
        if(exp[i] == '+' || exp[i] == '-' || exp[i] == '*' || exp[i] == '/')
        {
            op2 = obj.pop(p);
            op1 = obj.pop(p);
            switch(exp[i])
            {
                case '+':
                    val = op1 + op2;
                    obj.push(p, val);
                    break;
                case '-':
                    val = op1 - op2;
                    obj.push(p, val);
                    break;
                case '*':
                    val = op1 * op2;
                    obj.push(p, val);
                    break;
                case '/':
                    val = op1 / op2;
                    obj.push(p, val);
                    break;
            }
        }
        else
        {
            obj.push(p, exp[i] - 48);
        }
        i++;
    }

    val = obj.pop(p);
    cout<<"\nEval of Postexp= "<<val;
    getch();
}
