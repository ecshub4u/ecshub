// Write a program to calculate the factorial of the entered number by using recursion
#include<iostream.h>
#include<conio.h>

int fact(int n)
{
    if(n == 0 || n == 1)
    {
        return(1);
    }
    else
    {
        return(n * fact(n - 1));
    }
}

void main()
{
    int no, z;
    clrscr();
    cout<<"\nEnter any number= ";
    cin>>no;
    z = fact(no); // call
    cout<<"\nFactorial= "<<z;
    getch();
}
